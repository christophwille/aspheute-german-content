using System;
using System.IO;
using System.Data;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using CustomControls;



namespace learncontrols
{


	public class FixedHeightGrid : System.Web.UI.WebControls.DataGrid
	{

		private bool _mergePaddingColumns;
		private TableItemStyle _paddingItemStyle = new TableItemStyle();


		public FixedHeightGrid()
		{
			this.ShowFooter=false;
			this.ShowHeader=true;
			this.AllowPaging=true;
		}



		public bool MergePaddingColumns
		{
			get
			{
				return _mergePaddingColumns;
			}
			set
			{
				_mergePaddingColumns = value;
			}
		}

		
		public TableItemStyle PaddingItemStyle
		{
			get
			{
				return _paddingItemStyle;
			}
			set
			{
				_paddingItemStyle = value;
			}
		}


		protected override void OnPreRender(EventArgs e)
		{
			AddPaddingItems();
		}

		private void AddPaddingItems()
		{
			int indexCount;
			int indexStop = this.PageSize;
			int indexStart = 1;
			if(this.AllowPaging==true)
			{
				indexStart++;
				indexStop++;
			}
			Table myTable = (Table)this.Controls[0];
			for(indexCount=indexStart+this.Items.Count;indexCount<=indexStop;indexCount++)
			{
				myTable.Controls.AddAt(indexCount,PaddingItem());
			}
		}

		private DataGridItem PaddingItem()
		{
			DataGridItem myItem = new DataGridItem(0,0,ListItemType.Item);
			Table myTable = (Table)this.Controls[0];
			int numberOfColumns = myTable.Rows[1].Cells.Count;
			if(this.MergePaddingColumns==true)
			{			
				TableCell myCell = new TableCell();
				myCell.ColumnSpan = numberOfColumns;		
				myItem.Cells.Add(myCell);
			}
			else
			{
				for(int indexCount=1;indexCount<=numberOfColumns;indexCount++)
				{
					TableCell myCell = new TableCell();
					myItem.Cells.Add(myCell);
				}
			}				
			if(this.PaddingItemStyle.CssClass!=null)
				{
					myItem.ApplyStyle(this.PaddingItemStyle);
				}
			return myItem;
		}
	}


	public class BoundColumn : System.Web.UI.WebControls.BoundColumn
	{

	}

	public class ButtonColumn : System.Web.UI.WebControls.ButtonColumn
	{

	}

	public class EditCommandColumn : System.Web.UI.WebControls.EditCommandColumn
	{

	}

	public class HyperLinkColumn : System.Web.UI.WebControls.HyperLinkColumn
	{

	}

	public class TemplateColumn : System.Web.UI.WebControls.TemplateColumn
	{

	}



}
