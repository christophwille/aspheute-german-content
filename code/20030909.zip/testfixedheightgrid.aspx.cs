using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace learncontrols
{
	/// <summary>
	/// Zusammendfassende Beschreibung f�r aspxgrid1.
	/// </summary>
	public class learngrid : System.Web.UI.Page

	{
		protected System.Web.UI.WebControls.CheckBox CHBShowHeader;
		protected System.Web.UI.WebControls.CheckBox CHBShowFooter;
		protected System.Web.UI.WebControls.CheckBox CHBAllowPaging;
		protected System.Web.UI.WebControls.CheckBox CHBMergePaddingColumns;
		protected System.Web.UI.WebControls.CheckBox CHBPaddingStyle;
		protected System.Web.UI.WebControls.TextBox TBXRowsCount;
		protected System.Web.UI.WebControls.Button BTNSubtract;
		protected System.Web.UI.WebControls.Button BTNAdd;
		protected System.Web.UI.WebControls.Table TBLPagerOptions;
		protected System.Web.UI.WebControls.RadioButtonList RALPagerOptions;
		protected System.Web.UI.WebControls.Label LBLDescription;
		protected System.Web.UI.WebControls.Label LBLPagingInfo;

		protected learncontrols.FixedHeightGrid mygrid;

		private void Page_Load(object sender, System.EventArgs e)
		{
			mygrid.DataSource = ReadDataFromXML();
			mygrid.DataBind();
			LBLDescription.Visible=false;
			if(!IsPostBack)
			{
				CHBShowHeader.Checked=mygrid.ShowHeader;
				CHBShowFooter.Checked=mygrid.ShowFooter;
				CHBAllowPaging.Checked=mygrid.AllowPaging;
				CHBMergePaddingColumns.Checked=mygrid.MergePaddingColumns;
				TBXRowsCount.Text=mygrid.PageSize.ToString();
				if(mygrid.PagerStyle.Position==PagerPosition.TopAndBottom)
				{
					RALPagerOptions.SelectedIndex=0;
				}
				else if(mygrid.PagerStyle.Position==PagerPosition.Top)
				{
					RALPagerOptions.SelectedIndex=1;
				}
				else if(mygrid.PagerStyle.Position==PagerPosition.Bottom)
				{
					RALPagerOptions.SelectedIndex=2;
				}
				TBLPagerOptions.Visible=CHBAllowPaging.Checked;
				if(mygrid.PaddingItemStyle.CssClass==null)
				{
					CHBPaddingStyle.Checked=true;
				}
				else
				{
					CHBPaddingStyle.Checked=false;
				}
				LBLDescription.Visible=true;
				mygrid.DataBind();
			}
		}

		private DataSet ReadDataFromXML()
		{
			DataSet _ds = new DataSet();
			StreamReader sr = new StreamReader(Server.MapPath("data.xml"));
			_ds.ReadXml(sr);
			sr.Close();
			return _ds;
		}


		public void CHBShowHeader_CheckedChanged(object sender, System.EventArgs e)
		{
			mygrid.ShowHeader=CHBShowHeader.Checked;
		}

		public void CHBShowFooter_CheckedChanged(object sender, System.EventArgs e)
		{
			mygrid.ShowFooter=CHBShowFooter.Checked;
		}

		public void CHBAllowPaging_CheckedChanged(object sender, System.EventArgs e)
		{
			mygrid.AllowPaging=CHBAllowPaging.Checked;
			TBLPagerOptions.Visible=CHBAllowPaging.Checked;
			mygrid.DataBind();
		}

		public void CHBMergePaddingColumns_CheckedChanged(object sender, System.EventArgs e)
		{
			mygrid.MergePaddingColumns=CHBMergePaddingColumns.Checked;
			mygrid.DataBind();
		}

		public void CHBPaddingStyle_CheckedChanged(object sender, System.EventArgs e)
		{
			if(CHBPaddingStyle.Checked==true)
			{
				mygrid.PaddingItemStyle=mygrid.ItemStyle;
			}
			else
			{
				mygrid.PaddingItemStyle.CssClass="padding";
			}
			mygrid.DataBind();
		}


		private void BTNAdd_Click(object sender, System.EventArgs e)
		{
			mygrid.PageSize++;
			TBXRowsCount.Text=mygrid.PageSize.ToString();
			mygrid.DataBind();
			if(int.Parse(TBXRowsCount.Text)>1)
			{
				BTNSubtract.Enabled=true;
			}
		}

		private void BTNSubtract_Click(object sender, System.EventArgs e)
		{
			mygrid.PageSize--;
			TBXRowsCount.Text=mygrid.PageSize.ToString();
			mygrid.DataBind();
			if(int.Parse(TBXRowsCount.Text)==1)
			{
				BTNSubtract.Enabled=false;
			}
		}

		public void Grid_Paging(object sender, DataGridPageChangedEventArgs e)
		{
			mygrid.DataSource=ReadDataFromXML();
			mygrid.CurrentPageIndex = e.NewPageIndex;
			if(mygrid.CurrentPageIndex>0)
			{
				BTNSubtract.Enabled=false;
				BTNAdd.Enabled=false;
				TBXRowsCount.Enabled=false;
				LBLPagingInfo.Visible=true;
			}
			else
			{
				BTNSubtract.Enabled=true;
				BTNAdd.Enabled=true;
				TBXRowsCount.Enabled=true;
				LBLPagingInfo.Visible=false;
			}

			mygrid.DataBind();
		}

		public void RALPagerOptions_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(RALPagerOptions.SelectedIndex==0)
			{
				mygrid.PagerStyle.Position=PagerPosition.TopAndBottom;
			}
			else if(RALPagerOptions.SelectedIndex==1)
			{
				mygrid.PagerStyle.Position=PagerPosition.Top;
			}
			else if(RALPagerOptions.SelectedIndex==2)
			{
				mygrid.PagerStyle.Position=PagerPosition.Bottom;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: Dieser Aufruf ist f�r den ASP.NET Web Form-Designer erforderlich.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{    
			this.CHBShowHeader.CheckedChanged += new System.EventHandler(this.CHBShowHeader_CheckedChanged);
			this.BTNSubtract.Click += new System.EventHandler(this.BTNSubtract_Click);
			this.BTNAdd.Click += new System.EventHandler(this.BTNAdd_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
