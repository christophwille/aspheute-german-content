using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

using DotNetGerman;

namespace DataViewExSample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class DemoForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnRunTest;
		private System.Windows.Forms.DataGrid dg;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DemoForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnRunTest = new System.Windows.Forms.Button();
			this.dg = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
			this.SuspendLayout();
			// 
			// btnRunTest
			// 
			this.btnRunTest.Location = new System.Drawing.Point(8, 8);
			this.btnRunTest.Name = "btnRunTest";
			this.btnRunTest.TabIndex = 0;
			this.btnRunTest.Text = "Run Test";
			this.btnRunTest.Click += new System.EventHandler(this.btnRunTest_Click);
			// 
			// dg
			// 
			this.dg.DataMember = "";
			this.dg.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dg.Location = new System.Drawing.Point(8, 40);
			this.dg.Name = "dg";
			this.dg.Size = new System.Drawing.Size(632, 240);
			this.dg.TabIndex = 1;
			// 
			// DemoForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(648, 285);
			this.Controls.Add(this.dg);
			this.Controls.Add(this.btnRunTest);
			this.Name = "DemoForm";
			this.Text = "Demoform";
			((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new DemoForm());
		}

		private void btnRunTest_Click(object sender, System.EventArgs e)
		{
			SqlConnection conn = new SqlConnection("data source=(local)\\NetSDK;initial catalog=Northwind; integrated security=SSPI");
			SqlDataAdapter da = new SqlDataAdapter("select * from Customers", conn);
			DataSet ds = new DataSet("Demo");
			da.Fill(ds, "Customers");
			
			DataViewEx demoFilter = new DataViewEx(ds.Tables[0]);
			demoFilter.RowFilter = "City='Buenos Aires'";

			DataTable table = demoFilter.ToTable(true, new string[] {"ContactTitle", "CompanyName", "ContactName"});
			// DataTable table = demoFilter.ToTable(true, new string[] {"ContactTitle"});
			// DataTable table = demoFilter.ToTable();
			
			dg.DataSource = table;
		}
	}
}
