#if !defined(AFX_SIMPLEZIP_H__81357501_0721_4D8E_B47A_2663103B73D0__INCLUDED_)
#define AFX_SIMPLEZIP_H__81357501_0721_4D8E_B47A_2663103B73D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SimpleZip.h : header file
//

// CODE ADDITION
#include "..\UnZip\ZipFunc\ZipArchive.h"
// END CODE ADDITION

/////////////////////////////////////////////////////////////////////////////
// CSimpleZip command target

class CSimpleZip : public CCmdTarget
{
	DECLARE_DYNCREATE(CSimpleZip)

	CSimpleZip();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimpleZip)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSimpleZip();
	
	// CODE ADDITION
	CZipArchive m_zip;
	// END OF CODE ADDITION

	// Generated message map functions
	//{{AFX_MSG(CSimpleZip)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CSimpleZip)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CSimpleZip)
	afx_msg BOOL Open(LPCTSTR lpszZipFilename);
	afx_msg BOOL Close();
	afx_msg BOOL Unzip(LPCTSTR lpszFilename, LPCTSTR lspzTargetDirectory);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLEZIP_H__81357501_0721_4D8E_B47A_2663103B73D0__INCLUDED_)
