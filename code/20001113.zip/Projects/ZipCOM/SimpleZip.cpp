// SimpleZip.cpp : implementation file
//

#include "stdafx.h"
#include "ZipCOM.h"
#include "SimpleZip.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimpleZip

IMPLEMENT_DYNCREATE(CSimpleZip, CCmdTarget)

CSimpleZip::CSimpleZip()
{
	EnableAutomation();
	
	// To keep the application running as long as an OLE automation 
	//	object is active, the constructor calls AfxOleLockApp.
	
	AfxOleLockApp();
}

CSimpleZip::~CSimpleZip()
{
	// To terminate the application when all objects created with
	// 	with OLE automation, the destructor calls AfxOleUnlockApp.
	
	AfxOleUnlockApp();
}


void CSimpleZip::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	Close();
	CCmdTarget::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(CSimpleZip, CCmdTarget)
	//{{AFX_MSG_MAP(CSimpleZip)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CSimpleZip, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CSimpleZip)
	DISP_FUNCTION(CSimpleZip, "Open", Open, VT_BOOL, VTS_BSTR)
	DISP_FUNCTION(CSimpleZip, "Close", Close, VT_BOOL, VTS_NONE)
	DISP_FUNCTION(CSimpleZip, "Unzip", Unzip, VT_BOOL, VTS_BSTR VTS_BSTR)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ISimpleZip to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {C150D411-2EAA-465C-9F7D-87B6D62698A7}
static const IID IID_ISimpleZip =
{ 0xc150d411, 0x2eaa, 0x465c, { 0x9f, 0x7d, 0x87, 0xb6, 0xd6, 0x26, 0x98, 0xa7 } };

BEGIN_INTERFACE_MAP(CSimpleZip, CCmdTarget)
	INTERFACE_PART(CSimpleZip, IID_ISimpleZip, Dispatch)
END_INTERFACE_MAP()

// {7FE06690-022D-453B-A2B1-D9FBC1261685}
IMPLEMENT_OLECREATE(CSimpleZip, "ZipCOM.SimpleZip", 0x7fe06690, 0x22d, 0x453b, 0xa2, 0xb1, 0xd9, 0xfb, 0xc1, 0x26, 0x16, 0x85)

/////////////////////////////////////////////////////////////////////////////
// CSimpleZip message handlers

BOOL CSimpleZip::Open(LPCTSTR lpszZipFilename) 
{
	m_zip.Open(lpszZipFilename, CZipArchive::open, 0 );
	return TRUE;
}

BOOL CSimpleZip::Close() 
{
	m_zip.Close();
	return TRUE;
}

BOOL CSimpleZip::Unzip(LPCTSTR lpszFilename, LPCTSTR lspzTargetDirectory) 
{
	int nIndex = m_zip.FindFile(lpszFilename,false);
	if (-1 == nIndex) return FALSE;

	bool bResult = m_zip.ExtractFile(nIndex,lspzTargetDirectory);

	if (true == bResult) return TRUE;

	return FALSE;
}
