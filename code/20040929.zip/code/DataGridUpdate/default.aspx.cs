using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DotNetFu.DataGridUpdate
{
	/// <summary>
	/// Zusammenfassung f�r _default.
	/// </summary>
	public class _default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
	
		private void Page_Load(object sender, System.EventArgs e) {
			if(!Page.IsPostBack) {
				DataGrid1.DataSource = this.ReadDataFromDB();
				DataGrid1.DataBind();
			}

		}
		
		#region Methode nach dem DataBinding - Schritt 1 im Artikel
		private void DataGrid1_ItemDataBound(object sender, DataGridItemEventArgs e) {
			if(	(e.Item.ItemType == ListItemType.AlternatingItem) ||
				(e.Item.ItemType == ListItemType.Item)) {
					LinkButton lbtEdit = (LinkButton)e.Item.Cells[2].Controls[0];
					lbtEdit.CommandArgument = 
						((DataRowView)e.Item.DataItem)["CustomerID"].ToString();
				}
		}
		#endregion

		#region Methode zur Behandlung des Bearbeiten-Buttons - Schritt 2 im Artikel
		private void DataGrid1_EditCommand(object source, DataGridCommandEventArgs e) {
			DataGrid1.EditItemIndex = e.Item.ItemIndex;
			DataGrid1.SelectedIndex = e.Item.ItemIndex;

			DataGrid1.DataSource = this.ReadDataFromDB();
			DataGrid1.DataBind();			
			LinkButton lbtUpdate = 
				(LinkButton)this.DataGrid1.Items[e.Item.ItemIndex].Cells[2].Controls[0];
			lbtUpdate.CommandArgument = e.CommandArgument.ToString();
		}
		#endregion

		#region Methode zur Behandlung des Speichern-Buttons - Schritt 3 im Artikel
		private void DataGrid1_UpdateCommand(object source, DataGridCommandEventArgs e) {
			string companyName	= ((TextBox)e.Item.Cells[0].Controls[0]).Text;
			string address		= ((TextBox)e.Item.Cells[1].Controls[0]).Text;
			string customerID	= e.CommandArgument.ToString();
			this.UpdateCustomer(customerID, companyName, address);
			
			DataGrid1.SelectedIndex = -1;
			DataGrid1.EditItemIndex = -1;
			DataGrid1.DataSource = this.ReadDataFromDB();
			DataGrid1.DataBind();
		}
		#endregion

		#region Methode zur Behandlung des Abbrechen-Buttons
		private void DataGrid1_CancelCommand(object source, DataGridCommandEventArgs e) {
			DataGrid1.EditItemIndex = -1;
			DataGrid1.SelectedIndex = -1;
			DataGrid1.DataSource = this.ReadDataFromDB();
			DataGrid1.DataBind();
		}
		#endregion
		
		#region Daten aus der Datenbank lesen
		private DataSet ReadDataFromDB() {
			OleDbConnection MyNWConn = 
				new OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;Data Source=" + 
									Server.MapPath("../data/Nwind.mdb"));
			DataSet MyDataSet = new DataSet();
			OleDbDataAdapter oCommand = new OleDbDataAdapter();
			OleDbCommand oledbcmd = new OleDbCommand();
			oledbcmd.CommandType = CommandType.Text;
			oledbcmd.CommandText = "SELECT TOP 10 * FROM CUSTOMERS";
			oledbcmd.Connection = MyNWConn;
			oCommand.SelectCommand = oledbcmd;
			oCommand.Fill(MyDataSet,"Orders");
			MyNWConn.Close();
			return MyDataSet;
		}
		#endregion
		
		#region Daten in die Datenbank schreiben
		private void UpdateCustomer(string CustomerID, string CompanyName, string Address) {
			OleDbConnection MyNWConn = 
				new OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;Data Source=" + 
									Server.MapPath("../data/Nwind.mdb"));
			MyNWConn.Open();
			DataSet MyDataSet = new DataSet();
			OleDbCommand oledbcmd = new OleDbCommand();
			oledbcmd.CommandType = CommandType.StoredProcedure;
			oledbcmd.CommandText = "[UpdateCustomer]";
			oledbcmd.Parameters.Add("@CompanyName",CompanyName);
			oledbcmd.Parameters.Add("@Address", Address);
			oledbcmd.Parameters.Add("@CustomerID", CustomerID);
			oledbcmd.Connection = MyNWConn;
			oledbcmd.ExecuteNonQuery();
			MyNWConn.Close();
		}
		#endregion	
	
		#region Vom Web Form-Designer generierter Code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: Dieser Aufruf ist f�r den ASP.NET Web Form-Designer erforderlich.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
			DataGrid1.EditCommand += new DataGridCommandEventHandler(DataGrid1_EditCommand);
			DataGrid1.ItemDataBound += new DataGridItemEventHandler(DataGrid1_ItemDataBound);
			DataGrid1.CancelCommand += new DataGridCommandEventHandler(DataGrid1_CancelCommand);
			DataGrid1.UpdateCommand += new DataGridCommandEventHandler(DataGrid1_UpdateCommand);
		}
		#endregion	
	}
}
