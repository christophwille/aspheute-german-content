using System;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;
using System.IO;

class MainClass
{
	public static void Main()
	{
		string strURL = "http://prognoza.hr/jadran_e.html";
		string strContent,strErrCode,strTitle,strHeading1,strHeading2,strHeading3,strHeading4;
		DateTime dtGrabTime, dtForecastTimestamp;
        bool bSuccess;
        
        ScrapPage MyScrapPage = new ScrapPage();
        MyScrapPage.ScrapIt(strURL, out strContent, out strErrCode,out dtGrabTime);
        
        
        if("" == strErrCode)
        {
            bSuccess = true;
        }
        else
        {
            bSuccess = false;
        }
        
        
        CleanseContent MyCleanseContent = new CleanseContent();
		MyCleanseContent.StripHtmlTags(strContent, out strTitle, out strHeading1, out strHeading2, out strHeading3, out strHeading4, out dtForecastTimestamp);
		
        Write2DB MyWrite2DB = new Write2DB();
        MyWrite2DB.WriteIt(dtGrabTime, bSuccess, strTitle,strHeading1,strHeading2,strHeading3,strHeading4,strErrCode, dtForecastTimestamp);
        
	}
}

class ScrapPage
{
	public void ScrapIt(string strUrl, out string strContent, out string strErrCode,out DateTime dtGrabTime)
	{
        strErrCode ="";
        WebRequest WebReq = WebRequest.Create(strUrl);
      	WebResponse WebResp = WebReq.GetResponse();
    	StringBuilder strBuildContent = new StringBuilder(); 
		dtGrabTime = DateTime.Now;
		
      	try
        {
            StreamReader MyStrmR = new StreamReader(WebResp.GetResponseStream(), Encoding.ASCII);
             
            
                      
          	while (-1 != MyStrmR.Peek())
          	{
                strBuildContent.Append(MyStrmR.ReadLine());
          	}
        }
        catch (Exception e)
        {
        strErrCode = e.ToString();
        }
      	strContent = strBuildContent.ToString();
	}
}

class CleanseContent
{

 	public void StripHtmlTags(string strContent, out string strTitle, out string strHeading1, out string strHeading2, out string strHeading3, out string strHeading4, out DateTime dtForecastTimestamp)
 	{
 		string strRet,strNoWh;
 		string DateExtract,TimeExtract;
 		int nYear,nMonth,nDay,nHour,nMin;
 		
 		Regex rexStripHtml = new Regex("<([^!>]([^>]|\n)*)>", RegexOptions.IgnoreCase);
 		//Regex rexStripHtml = new Regex("<(.|\n)+?>", RegexOptions.IgnoreCase);
 		Regex rexStripWhSpace = new Regex(" * ", RegexOptions.IgnoreCase);
 		
 		strRet = rexStripHtml.Replace(strContent, "");
 		
 		strNoWh = rexStripWhSpace.Replace(strRet, " ");
 		
 		int idxHeading1 = strNoWh.IndexOf("WARNUNG:");
 		int idxHeading2 = strNoWh.IndexOf("DIE LAGE:");
 		int idxHeading3 = strNoWh.IndexOf("WETTERVORHERSAGE FUER DIE ADRIA FUER DIE NAECHSTEN 12 STUNDEN :");
 		int idxHeading4 = strNoWh.IndexOf("WETTERAUSSICHT FUER DIE ADRIA FUER DIE WEITEREN 12 STUNDEN:");
 		
 		strTitle = strNoWh.Substring(1,idxHeading1-1);
 		strTitle = strTitle.Trim();
 		
 		int idxDate = strTitle.IndexOf("VOM ");
 		int idxTime = strTitle.IndexOf("UM ");
 		DateExtract = strTitle.Substring(idxDate+4,10).Trim();
 		TimeExtract = strTitle.Substring(idxTime+3,4).Trim();
 		
 		nYear = Convert.ToInt32(DateExtract.Substring(6,4));
 		nMonth = Convert.ToInt32(DateExtract.Substring(3,2));
 		nDay = Convert.ToInt32(DateExtract.Substring(0,2));
 		nHour = Convert.ToInt32(TimeExtract.Substring(0,2));
 		nMin = Convert.ToInt32(TimeExtract.Substring(2,2));
 		
        dtForecastTimestamp = new DateTime(nYear,nMonth,nDay,nHour,nMin,00);
 		//dtForecastTimestamp = new DateTime(2001,09,09,09,09,00);
 		
 		strHeading1 = strNoWh.Substring(idxHeading1,idxHeading2-idxHeading1);
 		strHeading1 = strHeading1.Trim();
 		
 		strHeading2 = strNoWh.Substring(idxHeading2,idxHeading3-idxHeading2);
 		strHeading2 = strHeading2.Trim();
 		
 		strHeading3 = strNoWh.Substring(idxHeading3,idxHeading4-idxHeading3);
 		strHeading3 = strHeading3.Trim();
 		
 		strHeading4 = strNoWh.Substring(idxHeading4,strNoWh.Length-idxHeading4);
 		strHeading4 = strHeading4.Trim();
 		
 		/*Console.WriteLine(strNoWh);
 		Console.WriteLine(strTitle + "\n\n");
 		Console.WriteLine(strHeading1 + "\n\n");
 		Console.WriteLine(strHeading2 + "\n\n");
 		Console.WriteLine(strHeading3 + "\n\n");
 		Console.WriteLine(strHeading4 + "\n\n");
 		*/
 		//Console.WriteLine(dtForecastTimestamp.ToString());
 		//Console.WriteLine("Date {0}; Time: {1}", DateExtract,TimeExtract);
 	}
}

class Write2DB
{
    public void WriteIt(DateTime dtGrabTime, bool bSuccess, string strTitle, string strHeading1, string strHeading2, string strHeading3,string strHeading4, string strErrCode, DateTime dtForecastTimestamp)
    {
    string strConn = "server=(local)\\NetSDK;database=ScrapAppImproved;Trusted_Connection=yes";
    string insertCmd = "insert into tContent (GrabTime, Success, Title, Heading1, Heading2, Heading3, Heading4, ErrCode, ForecastTimestamp) values (@GrabTime,@Success, @Title, @Heading1, @Heading2, @Heading3, @Heading4, @ErrCode,@ForecastTimestamp)";
    
    SqlConnection MySqlConnection = new SqlConnection(strConn);
    SqlCommand MyCmd = new SqlCommand(insertCmd, MySqlConnection);

    MyCmd.Parameters.Add(new SqlParameter("@GrabTime", SqlDbType.DateTime, 8));
    MyCmd.Parameters["@GrabTime"].Value = dtGrabTime;
    MyCmd.Parameters.Add(new SqlParameter("@Success", SqlDbType.Bit, 1));
    MyCmd.Parameters["@Success"].Value = bSuccess;
    MyCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar,255));
    MyCmd.Parameters["@Title"].Value = strTitle;
    MyCmd.Parameters.Add(new SqlParameter("@Heading1", SqlDbType.NVarChar,1500));
    MyCmd.Parameters["@Heading1"].Value = strHeading1;
    MyCmd.Parameters.Add(new SqlParameter("@Heading2", SqlDbType.NVarChar,1500));
    MyCmd.Parameters["@Heading2"].Value = strHeading2;
    MyCmd.Parameters.Add(new SqlParameter("@Heading3", SqlDbType.NVarChar,1500));
    MyCmd.Parameters["@Heading3"].Value = strHeading3;
    MyCmd.Parameters.Add(new SqlParameter("@Heading4", SqlDbType.NVarChar,1500));
    MyCmd.Parameters["@Heading4"].Value = strHeading4;
    MyCmd.Parameters.Add(new SqlParameter("@ErrCode", SqlDbType.NVarChar, 255));
    MyCmd.Parameters["@ErrCode"].Value = strErrCode;
    MyCmd.Parameters.Add(new SqlParameter("@ForecastTimestamp", SqlDbType.DateTime, 8));
    MyCmd.Parameters["@ForecastTimestamp"].Value = dtForecastTimestamp;
    MyCmd.Connection.Open();
    MyCmd.ExecuteNonQuery();
    MyCmd.Connection.Close();
    }	
}
