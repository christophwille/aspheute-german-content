using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace XHTMLASPNET112
{
	/// <summary>
	/// Zusammenfassung f�r _default.
	/// </summary>
	public class _default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Repeater Repeater1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			this.Repeater1.DataSource = this.ReadDataFromDB();
			this.Repeater1.DataBind();
		}

		private DataSet ReadDataFromDB() {
			OleDbConnection MyNWConn = 
				new OleDbConnection(
					"PROVIDER=Microsoft.Jet.OLEDB.4.0;Data Source=" + 
					Server.MapPath("data/Nwind.mdb"));
			DataSet MyDataSet = new DataSet();
			OleDbDataAdapter oCommand = new OleDbDataAdapter();
			OleDbCommand oledbcmd = new OleDbCommand();
			oledbcmd.CommandType = CommandType.Text;
			oledbcmd.CommandText = "Select TOP 10 * FROM Customers";
			oledbcmd.Connection = MyNWConn;
			oCommand.SelectCommand = oledbcmd;
			oCommand.Fill(MyDataSet,"Customers");
			MyNWConn.Close();
			return MyDataSet;
		}


		#region Vom Web Form-Designer generierter Code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: Dieser Aufruf ist f�r den ASP.NET Web Form-Designer erforderlich.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
