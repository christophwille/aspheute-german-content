using System;
using System.Web;

namespace XHTMLASPNET11
{
    public class XHtmlModule : IHttpModule
    {
        //-----------------------------------------------------------------------------------------
        public void Init (HttpApplication app)
        {
            app.ReleaseRequestState         += new EventHandler(InstallResponseFilter);
        }


        /// <summary>
        /// Use this event to wire a page filter.
        /// </summary>
        private void InstallResponseFilter(object sender, EventArgs e) 
        {
            HttpResponse response = HttpContext.Current.Response;

            if(response.ContentType == "text/html") 
                response.Filter = new XHtmlPageFilter (response.Filter);      
        }

		public void Dispose() {
		}
    }
}
