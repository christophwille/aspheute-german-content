using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DotNetFu.DataGridMouseOver
{
	/// <summary>
	/// Zusammenfassung f�r _default.
	/// </summary>
	public class _default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
			{
				DataGrid1.DataSource = this.ReadDataFromDB();
				DataGrid1.DataBind();
			}

		}


		private DataSet ReadDataFromDB()
		{
			OleDbConnection MyNWConn = 
				new OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("../data/Nwind.mdb"));
			DataSet MyDataSet = new DataSet();
			OleDbDataAdapter oCommand = new OleDbDataAdapter();
			OleDbCommand oledbcmd = new OleDbCommand();
			oledbcmd.CommandType = CommandType.StoredProcedure;
			oledbcmd.CommandText = "[Product Sales for 1995]";
			oledbcmd.Connection = MyNWConn;
			oCommand.SelectCommand = oledbcmd;
			oCommand.Fill(MyDataSet,"Orders");
			MyNWConn.Close();
			return MyDataSet;
		}

		#region Vom Web Form-Designer generierter Code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: Dieser Aufruf ist f�r den ASP.NET Web Form-Designer erforderlich.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
			this.DataGrid1.ItemDataBound += new DataGridItemEventHandler(ItemDataBound);
			this.DataGrid1.EditCommand += new DataGridCommandEventHandler(DataGrid1_EditCommand);
			this.DataGrid1.CancelCommand += new DataGridCommandEventHandler(DataGrid1_CancelCommand);
			this.DataGrid1.PageIndexChanged += new DataGridPageChangedEventHandler(PageIndexChanged);

		}
		#endregion

		// Paging implementieren
		private void PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			DataGrid1.CurrentPageIndex = e.NewPageIndex;
			DataGrid1.DataSource = ReadDataFromDB();
			DataGrid1.DataBind();
		}

		// Hover implementieren
		private void ItemDataBound(object sender, DataGridItemEventArgs e)
		{
			if((e.Item.ItemType==ListItemType.Item) || 
				(e.Item.ItemType==ListItemType.AlternatingItem))
			{
				//MouseOver HighLighting
				e.Item.Attributes.Add("onmouseover","changein(this)");
				e.Item.Attributes.Add("onmouseout","changeout(this)");
			}
		}

		//EditColumn zur Demonstration der Spaltenunabh�ngigkeit
		private void DataGrid1_EditCommand(object source, DataGridCommandEventArgs e)
		{
			this.DataGrid1.EditItemIndex = e.Item.ItemIndex;
			this.DataGrid1.SelectedIndex = e.Item.ItemIndex;
			this.DataGrid1.DataSource = ReadDataFromDB();
			this.DataGrid1.DataBind();
		}

		private void DataGrid1_CancelCommand(object source, DataGridCommandEventArgs e)
		{
			this.DataGrid1.EditItemIndex = -1;
			this.DataGrid1.SelectedIndex = -1;
			this.DataGrid1.DataSource = this.ReadDataFromDB();
			this.DataGrid1.DataBind();
		}
	}
}
