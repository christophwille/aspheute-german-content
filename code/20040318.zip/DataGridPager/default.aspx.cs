using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DotNetFu.DataGridPager
{
	/// <summary>
	/// Zusammenfassung f�r _default.
	/// </summary>
	public class _default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		public double lumpSum;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
			{
				DataGrid1.DataSource = this.ReadDataFromDB();
				DataGrid1.DataBind();
			}

		}


		private DataSet ReadDataFromDB()
		{
			OleDbConnection MyNWConn = 
				new OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("../data/Nwind.mdb"));
			DataSet MyDataSet = new DataSet();
			OleDbDataAdapter oCommand = new OleDbDataAdapter();
			OleDbCommand oledbcmd = new OleDbCommand();
			oledbcmd.CommandType = CommandType.StoredProcedure;
			oledbcmd.CommandText = "[Product Sales for 1995]";
			oledbcmd.Connection = MyNWConn;
			oCommand.SelectCommand = oledbcmd;
			oCommand.Fill(MyDataSet,"Orders");
			MyNWConn.Close();
			return MyDataSet;
		}

		#region Vom Web Form-Designer generierter Code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: Dieser Aufruf ist f�r den ASP.NET Web Form-Designer erforderlich.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DataGrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.ItemCreated);
			this.DataGrid1.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.PageIndexChanged);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.ItemDataBound);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		// Paging implementieren
		private void PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			DataGrid1.CurrentPageIndex = e.NewPageIndex;
			DataGrid1.DataSource = ReadDataFromDB();
			DataGrid1.DataBind();
		}

		// Pager erweitern
		private void ItemCreated(object sender, DataGridItemEventArgs e)
		{
			if(e.Item.ItemType==ListItemType.Pager)
			{
				Label lblPager = new Label();
				lblPager.Text = "Seite&nbsp;" + lblPager.Text;
				e.Item.Controls[0].Controls.AddAt(0,lblPager);
			}
		}

		// �bertr�ge implementieren
		private void ItemDataBound(object sender, DataGridItemEventArgs e)
		{
			if((e.Item.ItemType==ListItemType.Item)||(e.Item.ItemType==ListItemType.AlternatingItem))
			{
				lumpSum = lumpSum + double.Parse((this.ReadDataFromDB().Tables[0].Rows[e.Item.DataSetIndex][2].ToString()));
			}

			if(e.Item.ItemType==ListItemType.Footer)
			{
				e.Item.Cells[2].HorizontalAlign = HorizontalAlign.Right;
				e.Item.Cells[2].Text = "�bertrag:&nbsp;" + string.Format("{0:c}",lumpSum);
				DataSet dsSales = this.ReadDataFromDB();
				int lastPageIndex = dsSales.Tables[0].Rows.Count/DataGrid1.PageSize;
				if(dsSales.Tables[0].Rows.Count%DataGrid1.PageSize==0)
					lastPageIndex--;
				if(lastPageIndex==DataGrid1.CurrentPageIndex)
				{
					double totalLumpSum = 0;
					foreach(DataRow dr in this.ReadDataFromDB().Tables[0].Rows)
					{
						totalLumpSum += double.Parse(dr["ProductSales"].ToString());
					}
					e.Item.Cells[2].Text += "<br>Endsumme:&nbsp;" + string.Format("{0:c}",totalLumpSum);
				}
			}
		}
	}
}
