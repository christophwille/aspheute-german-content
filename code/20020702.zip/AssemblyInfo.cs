using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("ImageInfo")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("AlphaSierraPapa")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("(c) 2002 Christoph Wille")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("ImageInfo.key")]
