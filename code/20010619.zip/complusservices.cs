using System;
using System.EnterpriseServices;
using System.Reflection;

// This is the name that will appear in the COM+ catalog
[assembly: ApplicationName("MyComponent")]

// Strong name for assembly.
[assembly: AssemblyKeyFile("MyComponent.snk")]

namespace AspHeute
{
	[Transaction(TransactionOption.Required)]
	public class MyClass : ServicedComponent 
	{
	    [AutoComplete]
	    public String TransactedMethod(int amount) 
	    {
	        return "A-OK";
	    }
	    
	    public void VoteOK()
	    {
	    	ContextUtil.SetComplete();
	    }
	    
	    public void VoteNo()
	    {
	    	ContextUtil.SetAbort();
	    }
	}
}
