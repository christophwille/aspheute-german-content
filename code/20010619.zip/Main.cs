// project created on 6/14/2001 at 5:53 PM
using System;
using AspHeute;

class MainClass
{
	public static void Main(string[] args)
	{
		MyClass var = new MyClass();
		Console.WriteLine(var.TransactedMethod(10));
	}
}
