if exists (select * from dbo.sysobjects where id = object_id(N'[Categories]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [Categories]
GO

CREATE TABLE [Categories] (
	[CategoryID] [int] IDENTITY (1, 1) NOT NULL ,
	[CategoryName] [nvarchar] (15) NOT NULL ,
	[Description] [ntext] NULL ,
	[Picture] [image] NULL ,
	CONSTRAINT [PK_Categories] PRIMARY KEY  CLUSTERED 
	(
		[CategoryID]
	)  ON [PRIMARY] 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


