using System;
using SecurityEnhance;

public class MainClass
{
public static void Main()
{
  FileUtilities fu = new FileUtilities();
  int Win32ErrorCode = 0;
  FileType f = fu.GetFileType("c:\\COM1", ref Win32ErrorCode);
  Console.WriteLine(f.ToString() + " " + Win32ErrorCode.ToString());
}
}