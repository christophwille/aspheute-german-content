#include "windows.h"

#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;

namespace SecurityEnhance
{
__value public enum FileType {undefined=-1, unknown=0, disk=1, character=2, pipe=3};

__gc public class FileUtilities
{
public:
   FileUtilities(){}
	
public:
   FileType GetFileType(System::String *sFileName, System::Int32 *Win32ErrorCode)
   {
	wchar_t __nogc* pszFileName = static_cast<wchar_t*>(Marshal::StringToHGlobalUni(sFileName).ToPointer());
	FileType theType = FileType::undefined;
	*Win32ErrorCode = 0;

	// open the file for generic reading
	HANDLE hFile = ::CreateFileW(pszFileName, 
					GENERIC_READ,
					FILE_SHARE_READ | FILE_SHARE_WRITE, 
					NULL, 
					OPEN_EXISTING, 
					0, 
					NULL );

	if (INVALID_HANDLE_VALUE == hFile)
	{
		DWORD dwError = ::GetLastError();
		*Win32ErrorCode = (long)dwError;
	}
	else
	{
		DWORD dwFileType = ::GetFileType(hFile);
		switch (dwFileType)
		{
		case FILE_TYPE_UNKNOWN: theType = FileType::unknown; break;
		case FILE_TYPE_DISK: theType = FileType::disk; break;
		case FILE_TYPE_CHAR: theType = FileType::character; break;
		case FILE_TYPE_PIPE: theType = FileType::pipe; break;
		default: theType = FileType::undefined;
		}
		::CloseHandle(hFile);
	}
	Marshal::FreeHGlobal(pszFileName);
	return theType;
   }
};
};
