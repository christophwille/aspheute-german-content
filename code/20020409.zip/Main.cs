using System;
using System.IO;
using System.Security;

class MainClass
{
	public static void Main(string[] args)
	{
		if (args.Length != 2)
		{
			Console.WriteLine("Usage: rename source destination");
			return;
		}
		
		string strExistingFile = args[0];
		string strNewFilename = args[1];
		bool bRenameSucceeded = false;
		
		try
		{
			File.Move(strExistingFile, strNewFilename);
			bRenameSucceeded = true;
		}
		catch(FileNotFoundException fe)
		{
			Console.WriteLine("Source file does not exist");
		}
		catch(IOException ioe)
		{
			Console.WriteLine("Destination not acceptable");
		}
		catch(SecurityException se)
		{
			Console.WriteLine("You do not have permission for this operation");
		}
		catch(Exception e)
		{
			Console.WriteLine("File rename failed, reason: " + e.ToString());
		}
		if (bRenameSucceeded)
		{
			Console.WriteLine("Rename completed successfully");
		}
	}
}
