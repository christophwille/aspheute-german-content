using System;
using System.Web.Services;

namespace AspHeute 
{
	public class SampleService : WebService
	{
		[WebMethod]
		public string SayHello(string strName) 
		{ 
			return "Hello " + strName + " from the assembly"; 
		}
	}
}

