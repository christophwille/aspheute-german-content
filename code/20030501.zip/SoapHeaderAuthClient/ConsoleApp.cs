using System;

namespace SoapHeaderAuthClient
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class ConsoleAppWsClient
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// create an instance of the authentication header class
			localhost.ServiceAuthHeader sah = new localhost.ServiceAuthHeader();
			sah.Username = "test";
			sah.Password = "test";

			// create a new service instance
			localhost.Service1 svc = new localhost.Service1();
			
			// set the value of the header
			svc.ServiceAuthHeaderValue = sah;

			string strResult = svc.SoapHeaderAuthSampleMethod();
			Console.WriteLine(strResult);
		}
	}
}
