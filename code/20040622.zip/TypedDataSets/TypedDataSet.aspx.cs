using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace TypedDataSets
{
	/// <summary>
	/// Zusammenfassung f�r TypedDataSet.
	/// </summary>
	public class TypedDataSet : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Verbindung zur DB definieren
			OleDbConnection MyNWConn = 
				new OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath("Nwind.mdb"));
			// DataSet erzeugen
			CustomersDataSet MyDataSet = new CustomersDataSet();

			// OleDbDataApter und OleDbCommand erzeugen
			OleDbDataAdapter oCommand	= new OleDbDataAdapter();
			OleDbCommand oledbcmd		= new OleDbCommand();

			// SQL-String definieren
			oledbcmd.CommandType 	= CommandType.Text;
			oledbcmd.CommandText 	= "SELECT * FROM Customers";

			// Connection und Stored Procedure zuweisen
			oledbcmd.Connection		= MyNWConn;
			oCommand.SelectCommand	= oledbcmd;

			// DataSet bef�llen
			oCommand.Fill(MyDataSet, "Customers");

			// Connection schlie�en
			MyNWConn.Close();


			// Daten aus dem DataSet ausgeben
			foreach(CustomersDataSet.CustomersRow dr in MyDataSet.Customers)
			{
				if(!dr.IsCompanyNameNull())
				{
					Response.Write(dr.CompanyName + "<br>");
				}
			}
		}

		#region Vom Web Form-Designer generierter Code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: Dieser Aufruf ist f�r den ASP.NET Web Form-Designer erforderlich.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
