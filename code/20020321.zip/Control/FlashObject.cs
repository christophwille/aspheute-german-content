/*
 * Copyright 2001 Paul D. Murphy
 * 
 * Comments:
 *		This is the RC3 build of a
 *		FlashObject Web Control
 * More Information:
 *		This code can be used freely, just give
 *		credit where credit is due.
 */

namespace Dots.WebControls
{
	using System;
	using System.Drawing;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.ComponentModel;

	/// <summary>
	///    Summary description for FlashObject.
	/// </summary>
	[DefaultProperty("VersionNumber"),
	ToolboxData("<{0}:FlashObject runat=server></{0}:FlashObject>")]
	public class FlashObject : System.Web.UI.Control
	{
		// Class Constants
		private const System.String _ClassID5 = "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000";
		private const System.String _CodeBase5 = "http://active.macromedia.com/flash5/cabs/swflash.cab";
		private const System.String _PlugInSpace5 = "http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash";
		// End Class Constants
		// Member Variables
		private Dots.WebControls.FlashObject.VersionNumberEnumeration _VersionNumber = Dots.WebControls.FlashObject.VersionNumberEnumeration.Flash5;
		private System.String _FileSource;
		private System.Boolean _SWLiveConnect = false;
		private System.Boolean _Play = true;
		private System.Boolean _Loop = true;
		private Dots.WebControls.FlashObject.QualityEnumeration _Quality = Dots.WebControls.FlashObject.QualityEnumeration.High;
		private System.Drawing.Color _BGColor;
		private Dots.WebControls.FlashObject.ScaleEnumeration _Scale = Dots.WebControls.FlashObject.ScaleEnumeration.ShowAll;
		private Dots.WebControls.FlashObject.AlignmentEnumerations _Align = Dots.WebControls.FlashObject.AlignmentEnumerations.Center;
		private Dots.WebControls.FlashObject.AlignmentEnumerations _SAlign = Dots.WebControls.FlashObject.AlignmentEnumerations.Center;
		private System.String _Base;
		private System.Boolean _Menu = true;
		private System.Web.UI.WebControls.Unit _Width;
		private System.Web.UI.WebControls.Unit _Height;
		private Dots.WebControls.FlashObject.WModeEnumeration _WMode = Dots.WebControls.FlashObject.WModeEnumeration.Transparent;
		// End Member Variables
		// Enumerations
		/// <summary>
		///		Specifies the version of the flash player
		///		to render.
		/// </summary>
		public enum VersionNumberEnumeration
		{
			/// <summary>
			///		Flash 4 Player
			/// </summary>
			Flash4 = 0,
			/// <summary>
			///		Flash 5 Player
			/// </summary>
			Flash5 = 1
		}
		/// <summary>
		///		Specifies the level of anti-aliasing to be used during playback of your
		///		movie. Because anti-aliasing requires a faster processor to smooth each frame of
		///		the movie before it is rendered on the viewer's screen, choose a value based on
		///		whether speed or appearance is your top priority.
		/// </summary>
		public enum QualityEnumeration
		{
			/// <summary>
			/// Low favors playback speed over appearance and never uses anti-aliasing.
			/// </summary>
			Low = 0,
			/// <summary>
			/// Medium applies some anti-aliasing and does not smooth bitmaps. It produces a
			/// better quality than the Low setting, but lower quality than the High setting.
			/// </summary>
			Medium = 1,
			/// <summary>
			/// High favors appearance over playback speed and always applies anti-aliasing. If
			/// the movie does not contain animation, bitmaps are smoothed; if the movie has
			/// animation, bitmaps are not smoothed.
			/// </summary>
			High = 2,
			/// <summary>
			/// Autolow emphasizes speed at first but improves appearance whenever possible.
			/// Playback begins with anti-aliasing turned off. If the Flash Player detects that
			/// the processor can handle it, anti-aliasing is turned on.
			/// </summary>
			AutoLow = 3,
			/// <summary>
			/// Autohigh emphasizes playback speed and appearance equally at first but
			/// sacrifices appearance for playback speed if necessary. Playback begins with anti-aliasing
			/// turned on. If the actual frame rate drops below the specified frame rate,
			/// anti-aliasing is turned off to improve playback speed.
			/// </summary>
			AutoHigh = 4,
			/// <summary>
			/// Best provides the best display quality and does not consider playback speed. All
			/// output is anti-aliased and all bitmaps are smoothed.
			/// </summary>
			Best = 5
		}
		/// <summary>
		///		Defines how the movie is placed within the browser window when
		///		WIDTH and HEIGHT values are percentages.
		/// </summary>
		public enum ScaleEnumeration
		{
			/// <summary>
			/// Makes the entire movie visible in the specified area without
			/// distortion, while maintaining the original aspect ratio of the movie. Borders
			/// may appear on two sides of the movie.
			/// </summary>
			ShowAll = 0,
			/// <summary>
			/// No Border scales the movie to fill the specified area, without distortion
			/// but possibly with some cropping, while maintaining the original aspect ratio
			/// of the movie.
			/// </summary>
			NoBorder = 1,
			/// <summary>
			/// Exact Fit makes the entire movie visible in the specified area without trying to
			/// preserve the original aspect ratio. Distortion may occur.
			/// </summary>
			ExactFit = 2
		}	
		/// <summary>
		/// Specifies the ALIGN attribute for the OBJECT , EMBED , and IMG tags and determines
		/// how the Flash movie window is positioned within the browser window.
		/// </summary>
		public enum AlignmentEnumerations
		{
			/// <summary>
			/// Left, Right, Top, and Bottom align the movie along the corresponding edge of
			/// the browser window and crop the remaining three sides as needed.
			/// </summary>
			Left = 0,
			/// <summary>
			/// Left, Right, Top, and Bottom align the movie along the corresponding edge of
			/// the browser window and crop the remaining three sides as needed.
			/// </summary>
			Right = 1,
			/// <summary>
			/// Left, Right, Top, and Bottom align the movie along the corresponding edge of
			/// the browser window and crop the remaining three sides as needed.
			/// </summary>
			Top = 2,
			/// <summary>
			/// Left, Right, Top, and Bottom align the movie along the corresponding edge of
			/// the browser window and crop the remaining three sides as needed.
			/// </summary>
			Bottom = 3,
			/// <summary>
			/// (SAlign Only)
			/// TL and TR align the movie to the top left and top right corner, respectively,
			/// of the browser window and crop the bottom and remaining right or left side
			/// as needed.
			/// </summary>
			TopLeft = 4,
			/// <summary>
			/// (SAlign Only)
			/// TL and TR align the movie to the top left and top right corner, respectively,
			/// of the browser window and crop the bottom and remaining right or left side
			/// as needed.
			/// </summary>
			TopRight = 5,
			/// <summary>
			/// (SAlign Only)
			/// BL and BR align the movie to the top left and top right corner, respectively,
			/// of the browser window and crop the bottom and remaining right or left side
			/// as needed.
			/// </summary>
			BottomLeft = 6,
			/// <summary>
			/// (SAlign Only)
			/// BL and BR align the movie to the top left and top right corner, respectively,
			/// of the browser window and crop the bottom and remaining right or left side
			/// as needed.
			/// </summary>
			BottomRight = 7,
			/// <summary>
			/// (Default Value)
			/// Centers the movie in the browser window and crops edges if the
			/// browser window is smaller than the movie.
			/// </summary>
			Center = 8
		}
		/// <summary>
		/// Lets you take advantage of the transparent movie, absolute
		/// positioning, and layering capabilities available in Internet Explorer 4.0. This tag
		/// works only in Windows with the Flash ActiveX control.
		/// </summary>
		public enum WModeEnumeration
		{
			/// <summary>
			/// plays the movie in its own rectangular window on a Web page.
			/// </summary>
			Window = 0,
			/// <summary>
			/// makes the movie hide everything behind it on the page.
			/// </summary>
			Opaque = 1,
			/// <summary>
			/// makes the background of the HTML page show through all the
			/// transparent portions of the movie, and may slow animation performance.
			/// </summary>
			Transparent = 2
		}
		// End Enumerations
		// Properties
		///<summary>
		/// Sets the version of the Flash Player to render
		///</summary>
		[
		Browsable(true),
		Category("Flash"),
		Description("Specifies the version of the flash player to render."), 
		DefaultValue(Dots.WebControls.FlashObject.VersionNumberEnumeration.Flash5),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public Dots.WebControls.FlashObject.VersionNumberEnumeration VersionNumber
		{
			get
			{
				return this._VersionNumber;
			}
			set
			{
				this._VersionNumber = value;
			}
		}
		///<summary>
		/// Sets the File Source for the Flash Object
		/// </summary>
		[
		Browsable(true),
		Category("Flash"),
		Description("Sets the File Source for the Flash Object."),
		Editor(typeof(System.Web.UI.Design.UrlEditor), typeof(System.Drawing.Design.UITypeEditor)),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public String FileSource
		{
			get
			{
				return this._FileSource;
			}
			set
			{
				this._FileSource = value;
			}
		}
		///<summary>
		/// Specifies whether the browser should start Java when loading the Flash player for the first time.
		/// </summary>
		[
		Browsable(true),
		Category("Control"),
		DefaultValue(false),
		Description("Specifies whether the browser should start Java when loading the Flash player for the first time."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public System.Boolean SWLiveConnect
		{
			get
			{
				return this._SWLiveConnect;
			}
			set
			{
				this._SWLiveConnect = value;
			}
		}
		///<summary>
		/// Specifies whether the movie begins playing immediatly on loading in the browser.
		/// </summary>
		[
		Browsable(true),
		Category("Control"),
		DefaultValue(true),
		Description("Specifies whether the movie begins playing immediately on loading in the browser."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public System.Boolean Play
		{
			get
			{
				return this._Play;
			}
			set
			{
				this._Play = value;
			}
		}
		///<summary>
		/// Specifies whether the movie repeats indefinitely or stops when it reaches the last frame.
		/// </summary>
		[
		Browsable(true),
		Category("Control"),
		DefaultValue(true),
		Description("Specifies whether the movie repeats indefinitely or stops when it reaches the last frame."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public System.Boolean Loop
		{
			get
			{
				return this._Loop;
			}
			set
			{
				this._Loop = value;
			}
		}
		///<summary>
		/// Specifies the level of anti-aliasing to be used during playback of the movie.
		/// </summary>
		[
		Browsable(true),
		Category("Appearance"),
		DefaultValue(Dots.WebControls.FlashObject.QualityEnumeration.High),
		Description("Specifies the level of anti-aliasing to be used during playback of the movie."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public Dots.WebControls.FlashObject.QualityEnumeration Quality
		{
			get
			{
				return this._Quality;
			}
			set
			{
				this._Quality = value;
			}
		}
		/// <summary>
		///  Specifies the background color of the movie.
		/// </summary>
		[
		Browsable(true),
		Category("Appearance"),
		Description("Specifies the background color of the movie."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public System.Drawing.Color BackColor
		{
			get
			{
				return this._BGColor;
			}
			set
			{
				this._BGColor = value;
			}
		}
		/// <summary>
		///  Defines how the movie is placed within the browser when Width and Height
		///  values are percentages
		/// </summary>
		[
		Browsable(true),
		Category("Layout"),
		DefaultValue(Dots.WebControls.FlashObject.ScaleEnumeration.ShowAll),
		Description("Defines how the movie is placed within the browser when Width and Height values are percentages."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public Dots.WebControls.FlashObject.ScaleEnumeration Scale
		{
			get
			{
				return this._Scale;
			}
			set
			{
				this._Scale = value;
			}
		}
		/// <summary>
		///  Specifies the Align attribute for the Object or Embed tags and determines
		///  how the Flash movie will be position in the browser
		///  </summary>
		[
		Browsable(true),
		Category("Layout"),
		DefaultValue(Dots.WebControls.FlashObject.AlignmentEnumerations.Center),
		Description("Specifies the Align attribute for the Object or Embed tags and determines how the Flash movie will be position in the browser."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public Dots.WebControls.FlashObject.AlignmentEnumerations Align
		{
			get
			{
				return this._Align;
			}
			set
			{
				this._Align = value;
			}
		}
		/// <summary>
		/// Specifies where a scaled Flash movie is positioned within the defined Width and Height settings
		/// </summary>
		[
		Browsable(true),
		Category("Layout"),
		DefaultValue(Dots.WebControls.FlashObject.AlignmentEnumerations.Center),
		Description("Specifies where a scaled Flash movie is positioned within the defined Width and Height settings."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public Dots.WebControls.FlashObject.AlignmentEnumerations SAlign
		{
			get
			{
				return this._SAlign;
			}
			set
			{
				this._SAlign = value;
			}
		}
		/// <summary>
		/// Specifies the base directory or URL used to resolve all relative path statements in the Flash movie
		/// </summary>
		[
		Browsable(true),
		Category("Control"),
		Description("Specifies the base directory or URL used to resolve all relative path statements in the Flash movie."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public System.String Base
		{
			get
			{
				return this._Base;
			}
			set
			{
				this._Base = value;
			}
		}
		/// <summary>
		/// Specifies what type of menu is displayed when the user right-clicks
		/// </summary>
		[
		Browsable(true),
		Category("Control"),
		DefaultValue(true),
		Description("Specifies what type of menu is displayed when the user right-clicks."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public System.Boolean Menu
		{
			get
			{
				return this._Menu;
			}
			set
			{
				this._Menu = value;
			}
		}
		/// <summary>
		/// Lets you take advantage of the transparent movie, absolute positioning, and layering
		/// capabilites of IE 4
		/// </summary>
		[
		Browsable(true),
		Category("Layout"),
		Description("Lets you take advantage of the transparent movie, absolute positioning, and layering capabilites of IE 4."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public Dots.WebControls.FlashObject.WModeEnumeration WMode
		{
			get
			{
				return this._WMode;
			}
			set
			{
				this._WMode = value;
			}
		}
		/// <summary>
		///  Specifies the width of the Flash movie
		///  </summary>
		[
		Browsable(true),
		Category("Layout"),
		Description("Specifies the width of the Flash movie."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public System.Web.UI.WebControls.Unit Width
		{
			get
			{
				return this._Width;
			}
			set
			{
				this._Width = value;
			}
		}
		/// <summary>
		///  Specifies the height of the Flash movie
		///  </summary>
		[
		Browsable(true),
		Category("Layout"),
		Description("Specifies the height of the Flash movie."),
		DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)
		]
		public System.Web.UI.WebControls.Unit Height
		{
			get
			{
				return this._Height;
			}
			set
			{
				this._Height = value;
			}
		}
		// End Properties
		/// <summary> 
		///    Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			System.String netscapeAttributes = "";

			output.WriteLine(" ");
			// Write the opening Object tag
			output.Write("<object classid=\"" +
				_ClassID5.ToString() + "\" ");

			// Is the width set?
			System.Boolean IsWidthSet = true;
			if(this._Width.Value.Equals(0.0)){ IsWidthSet = false; }

			// If so Write the width
			if(IsWidthSet)
			{
				output.Write("width=\"" +
					this._Width.ToString() +
					"\" ");
				netscapeAttributes += " width=\"" +
					this._Width.ToString() +
					"\" ";

			}

			// Is the height set?
			System.Boolean IsHeightSet = true;
			if(this._Height.Value.Equals(0.0)){ IsHeightSet = false;}

			// If so Write the height
			if(IsHeightSet)
			{
				output.Write("height=\"" +
					this._Height.ToString() +
					"\" ");
				netscapeAttributes += " height=\"" +
					this._Height.ToString() +
					"\" ";
			}

			// Write the code base
			output.Write("codebase=\"" +
				_CodeBase5.ToString() + "\"");

			// Close the beinging Object tag
			output.Write(">");
			output.WriteLine(" ");
			// Write the parameters
			// Align Property
			switch(this._Align)
			{
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Left:
					this.RenderParam("Align", "Left", output);
					netscapeAttributes += "Align=\"L\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Right:
					this.RenderParam("Align", "Right", output);
					netscapeAttributes += "Align=\"R\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Top:
					this.RenderParam("Align", "Top", output);
					netscapeAttributes += "Align=\"T\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Bottom:
					this.RenderParam("Align", "Bottom", output);
					netscapeAttributes += "Align=\"B\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Center:
					this.RenderParam("Align", "Center", output);
					netscapeAttributes += "Align=\"Center\"";
					break;
				default:
					this.RenderParam("Align","Center", output);
					netscapeAttributes += "Align=\"Center\"";
					output.WriteLine("<!-- The option you selected is not valid for this property, the default value of center has been used --></!-->");
					break;
			}
			// BackColor Property
			// Is it set?
			System.Boolean IsBGColorSet = false;
			if(!this._BGColor.IsEmpty){ IsBGColorSet = true;}
			// Write the parameter
			if(IsBGColorSet)
			{
				this.RenderParam("BGColor",this._BGColor.ToArgb().ToString(), output);
				netscapeAttributes += " BGColor=\"" + this._BGColor.ToArgb().ToString() + "\"";
			}
			// Base Property
			// Is it set?
			System.Boolean IsBaseSet = true;
			if(this._Base == null | this._Base == ""){ IsBaseSet = false; }
			// Write the paramter
			if(IsBaseSet)
			{
				this.RenderParam("Base", this._Base, output);
				netscapeAttributes += " Base=\"" + this._Base + "\"";
			}
			// File Source
			// Is it set?
			System.Boolean IsSrcSet = true;
			if(this._FileSource == null | this._FileSource == ""){IsSrcSet = false;}
			// Write the paramter
			if(IsSrcSet)
			{
				this.RenderParam("Movie", this._FileSource.ToString(), output);
				netscapeAttributes += " Src=\"" + this._FileSource.ToString() + "\"";
			}
			// Loop Property
			switch(this._Loop)
			{
				case true:
					this.RenderParam("Loop", "True", output);
					netscapeAttributes += " Loop=\"True\"";
					break;
				case false:
					this.RenderParam("Loop", "False", output);
					netscapeAttributes += " Loop=\"False\"";
					break;
			}
			// Menu Property
			switch(this._Menu)
			{
				case true:
					this.RenderParam("Menu", "True", output);
					netscapeAttributes += " Menu=\"True\"";
					break;
				case false:
					this.RenderParam("Menu", "False", output);
					netscapeAttributes += " Menu=\"False\"";
					break;
			}
			// Play Property
			switch(this._Play)
			{
				case true:
					this.RenderParam("Play", "True", output);
					netscapeAttributes += " Play=\"True\"";
					break;
				case false:
					this.RenderParam("Play", "False", output);
					netscapeAttributes += " Play=\"False\"";
					break;
			}
			// Quality Property
			switch(this._Quality)
			{
				case Dots.WebControls.FlashObject.QualityEnumeration.Low:
					this.RenderParam("Quality", "Low", output);
					netscapeAttributes += " Quality=\"Low\"";
					break;
				case Dots.WebControls.FlashObject.QualityEnumeration.High:
					this.RenderParam("Quality", "High", output);
					netscapeAttributes += " Quality=\"High\"";
					break;
				case Dots.WebControls.FlashObject.QualityEnumeration.AutoLow:
					this.RenderParam("Quality", "Autolow", output);
					netscapeAttributes += " Quality=\"AutoLow\"";
					break;
				case Dots.WebControls.FlashObject.QualityEnumeration.AutoHigh:
					this.RenderParam("Quality", "Autohigh", output);
					netscapeAttributes += " Quality=\"AutoHigh\"";
					break;
				case Dots.WebControls.FlashObject.QualityEnumeration.Best:
					this.RenderParam("Quality", "Best", output);
					netscapeAttributes += " Quality=\"Best\"";
					break;
				case Dots.WebControls.FlashObject.QualityEnumeration.Medium:
					this.RenderParam("Quality", "Medium", output);
					netscapeAttributes += " Quality=\"Medium\"";
					break;
			}
			// SAlign Property
			switch(this._SAlign)
			{
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Left:
					this.RenderParam("SAlign", "Left", output);
					netscapeAttributes += " SAlign=\"L\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Right:
					this.RenderParam("SAlign", "Right", output);
					netscapeAttributes += " SAlign=\"R\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Top:
					this.RenderParam("SAlign", "Top", output);
					netscapeAttributes += " SAlign=\"T\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Bottom:
					this.RenderParam("SAlign", "Bottom", output);
					netscapeAttributes += " SAlign=\"B\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.Center:
					this.RenderParam("SAlign", "Center", output);
					netscapeAttributes += " SAlign=\"Center\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.BottomLeft:
					this.RenderParam("SAlign", "BottomLeft", output);
					netscapeAttributes += " SAlign=\"BL\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.BottomRight:
					this.RenderParam("SAlign", "BottomRight", output);
					netscapeAttributes += " SAlign=\"BR\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.TopLeft:
					this.RenderParam("SAlign", "TopLeft", output);
					netscapeAttributes += " SAlign=\"TL\"";
					break;
				case Dots.WebControls.FlashObject.AlignmentEnumerations.TopRight:
					this.RenderParam("SAlign", "TopRight", output);
					netscapeAttributes += " SAlign=\"TR\"";
					break;
			}
			// Scale Property
			switch(this._Scale)
			{
				case Dots.WebControls.FlashObject.ScaleEnumeration.ShowAll:
					this.RenderParam("Scale", "Showall", output);
					netscapeAttributes += " Scale=\"Showall\"";
					break;
				case Dots.WebControls.FlashObject.ScaleEnumeration.NoBorder:
					this.RenderParam("Scale", "NoBorder", output);
					netscapeAttributes += " Scale=\"NoBorder\"";
					break;
				case Dots.WebControls.FlashObject.ScaleEnumeration.ExactFit:
					this.RenderParam("Scape", "ExactFit", output);
					netscapeAttributes += " Scale=\"ExactFit\"";
					break;
			}
			// SWLiveConnect Property
			switch(this._SWLiveConnect)
			{
				case true:
					this.RenderParam("SWLiveConnect", "True", output);
					netscapeAttributes += " SWLiveConnect=\"True\"";
					break;
				case false:
					this.RenderParam("SWLiveConnect", "False", output);
					netscapeAttributes += " SWLiveConnect=\"False\"";
					break;
			}
			// WMode Property
			switch(this._WMode)
			{
				case Dots.WebControls.FlashObject.WModeEnumeration.Window:
					this.RenderParam("WMode", "Window", output);
					netscapeAttributes += " WMode=\"Window\"";
					break;
				case Dots.WebControls.FlashObject.WModeEnumeration.Opaque:
					this.RenderParam("WMode", "Opaque", output);
					netscapeAttributes += " WMode=\"Opaque\"";
					break;
				case Dots.WebControls.FlashObject.WModeEnumeration.Transparent:
					this.RenderParam("WMode", "Transparent", output);
					netscapeAttributes += " WMode=\"Transparent\"";
					break;
			}
			// Write the NetScape Embed Code HERE!!
			output.WriteLine(" ");
			output.WriteLine("<Embed PluginSpace=\"" + _PlugInSpace5 + "\" " +	netscapeAttributes + "></Embed>");
			output.WriteLine(" ");

			// Write the end Object tag
			output.WriteLine("</Object>");
		}

		/// <summary>
		///  Renders a param child tag for the IE Object Tag
		/// </summary>
		/// <param name="NAME">The Attribute name</param>
		/// <param name="VALUE">The Attribute value</param>
		/// <param name="OUTPUT">The HtmlTextWriter to write with</param>
		private void RenderParam(
			System.String NAME,
			System.String VALUE,
			HtmlTextWriter OUTPUT
			)
		{
			OUTPUT.Indent++;
			OUTPUT.WriteLine("<param name=\"" + NAME + "\" " + "value=\"" + VALUE + "\">");
			OUTPUT.Indent--;
		}       
	}
}
