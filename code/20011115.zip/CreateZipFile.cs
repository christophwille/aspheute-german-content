using System;
using System.IO;

using ICSharpCode.SharpZipLib.Zip;

class MainClass
{
  public static void Main(string[] args)
  {
    // alle Dateien im angegebenen Ordner werden komprimiert
    string[] aFilenames = Directory.GetFiles(args[0]);
    
    // der Name der Zipdatei ist der zweite Parameter im Aufruf
    ZipOutputStream s = new ZipOutputStream(File.Create(args[1]));
    
    // Komprimierungslevel setzen: 0 [keine] - 9 [st�rkste]
    s.SetLevel(5); 
    
    for (int i=0; i < aFilenames.Length; i++)
    {
      FileStream fs = File.OpenRead(aFilenames[i]);
      
      // im Normalfall allokiert man die Buffer im voraus
      // hier aus Klarheitsgr�nden pro Datei einmal
      byte[] buffer = new byte[fs.Length];
      fs.Read(buffer, 0, buffer.Length);

      // und jetzt schreiben wir einen ZipEntry & die Daten      
      ZipEntry entry = new ZipEntry(aFilenames[i]);
      s.PutNextEntry(entry);
      s.Write(buffer, 0, buffer.Length);
    }
    
    s.Finish();
    s.Close();
  }
}
