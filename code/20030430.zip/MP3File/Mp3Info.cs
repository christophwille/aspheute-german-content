using System; 
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;

namespace Mp3
{	
	/// <summary>
	/// Diese Klasse kapselt den lesenden Zugriff auf die 
	/// ID3v1/Id3v1.1-Infos aus MP3-Dateien.
	/// Informationen �ber die genaue Spezifikation
	/// des ID3-Standards finden sich auf
	/// http://www.id3.org/.
	/// Die Genre-Liste entstammt dem Dokument zur
	/// Spezifikation des IDv1-Standards unter
	/// http://www.id3.org/id3v2-00.txt, Anhang A3.
	/// </summary>
	/// <remarks>
	/// Autor: Bj�rn Waide (b.waide@fme.de)
	/// Copyright: fme AG
	/// Anschrift:  fme AG - Petzvalstra�e 38 - 38104 Braunschweig
	/// Telefon: 0531 / 238 54-0
	/// Erstellt: 02/2003
	/// </remarks>
	public class Mp3Info
	{
		#region Private Variablen-Deklarationen

		private String m_filename;
		private bool   m_containsID3Information;

		#region Genre-Array
		/// <summary>
		/// Dieses Array dient der Zuordnung des Genre-Bytes aus
		/// den Dateiinformationen zu einem Klarnamen. Es enth�lt
		/// die Genrenamen im Wortlaut der Spezifikation plus WinAmp-
		/// Erweiterungen, einzusehen unter http://www.id3.org/id3v2-00.txt,
		/// Abschnitt A3.
		/// </summary>
		private static String[] m_genreArray = {
											"Blues",
											"Classic Rock",
											"Country",
											"Dance",
											"Disco",
											"Funk",
											"Grunge",
											"Hip-Hop",
											"Jazz",
											"Metal",
											"New Age",
											"Oldies",
											"Other",
											"Pop",
											"R&B",
											"Rap",
											"Reggae",
											"Rock",
											"Techno",
											"Industrial",
											"Alternative",
											"Ska",
											"Death Metal",
											"Pranks",
											"Soundtrack",
											"Euro-Techno",
											"Ambient",
											"Trip-Hop",
											"Vocal",
											"Jazz+Funk",
											"Fusion",
											"Trance",
											"Classical",
											"Instrumental",
											"Acid",
											"House",
											"Game",
											"Sound Clip",
											"Gospel",
											"Noise",
											"Alternative Rock",
											"Bass",
											"Soul",
											"Punk",
											"Space",
											"Meditative",
											"Instrumental Pop",
											"Instrumental Rock",
											"Ethnic",
											"Gothic",
											"Darkwave",
											"Techno-Industrial",
											"Electronic",
											"Pop-Folk",
											"Eurodance",
											"Dream",
											"Southern Rock",
											"Comedy",
											"Cult",
											"Gangsta",
											"Top 40",
											"Christian Rap",
											"Pop/Funk",
											"Jungle",
											"Native US",
											"Cabaret",
											"New Wave",
											"Psychadelic",
											"Rave",
											"Showtunes",
											"Trailer",
											"Lo-Fi",
											"Tribal",
											"Acid Punk",
											"Acid Jazz",
											"Polka",
											"Retro",
											"Musical",
											"Rock & Roll",
											"Hard Rock",
											"Folk",
											"Folk-Rock",
											"National Folk",
											"Swing",
											"Fast Fusion",
											"Bebob",
											"Latin",
											"Revival",
											"Celtic",
											"Bluegrass",
											"Avantgarde",
											"Gothic Rock",
											"Progressive Rock",
											"Psychedelic Rock",
											"Symphonic Rock",
											"Slow Rock",
											"Big Band",
											"Chorus",
											"Easy Listening",
											"Acoustic",
											"Humour",
											"Speech",
											"Chanson",
											"Opera",
											"Chamber Music",
											"Sonata",
											"Symphony",
											"Booty Bass",
											"Primus",
											"Porn Groove",
											"Satire",
											"Slow Jam",
											"Club",
											"Tango",
											"Samba",
											"Folklore",
											"Ballad",
											"Power Ballad",
											"Rhytmic Soul",
											"Freestyle",
											"Duet",
											"Punk Rock",
											"Drum Solo",
											"Acapella",
											"Euro-House",
											"Dance Hall",
										};
		#endregion

		#region Infomationen aus ID3v1
		private String	m_title;
		private String	m_artist;
		private String	m_album;
		private int		m_year;
		private String	m_comment;
		private byte	m_genre;
		private byte	m_track;
		#endregion

		#endregion


		#region Property-Definitionen

		/// <summary>
		/// Dateiname des einzulesenden MP3-Files.
		/// </summary>
		public String Filename
		{
			get
			{
				return m_filename;
			}
		}


		/// <summary>
		/// Gibt an, ob die Datei ID3v1-Informationen beinhaltet. Dieses Attribut
		/// ist ReadOnly.
		/// </summary>
		public bool ContainsID3v1Information
		{
			get
			{
				return this.m_containsID3Information;
			}
		}


		/// <summary>
		/// Name des Werkes aus den ID3v1-Informationen.
		/// </summary>
		public String Title
		{
			get
			{
				return m_title;
			}
		}


		/// <summary>
		/// Name des K�nstler aus den ID3v1-Informationen.
		/// </summary>
		public String Artist
		{
			get
			{
				return m_artist;
			}
		}


		/// <summary>
		/// Name des Albums aus den ID3v1-Informationen.
		/// </summary>
		public String Album
		{
			get
			{
				return m_album;
			}
		}


		/// <summary>
		/// Erscheinungsjahr aus den ID3v1-Informationen.
		/// </summary>
		public int Year
		{
			get
			{
				return m_year;
			}
		}


		/// <summary>
		/// Kommentar aus den ID3v1-Informationen.
		/// </summary>
		public String Comment
		{
			get
			{
				return m_comment;
			}
		}


		/// <summary>
		/// Genre aus den ID3v1-Informationen.
		/// </summary>
		public String Genre
		{
			//Intern wird im File nur ein Byte-Wert als Genre-Info
			//gespeichert. Die �bersetzung in Klarnamen erfolgt mit einer
			//internen Hash-Tabelle.
			get
			{
				return GetGenre(m_genre);
			}
		}


		/// <summary>
		/// CD-Track-Nummer aus den ID3v1-Informationen.
		/// </summary>
		public byte Track
		{
			get
			{
				return m_track;
			}
		}
		#endregion


		/// <summary>
		/// Liest die angegebene Datei ein und speichert, so vorhanden, die
		/// ID3v1-Titelinformationen in den Properties der Instanz dieser Klasse.
		/// </summary>
		/// <param name="filename">Der vollst�ndige Pfad der einzulesenden Datei</param>
		public void Read(String filename)
		{
			if (File.Exists(filename))
			{
				this.m_filename = filename;
			}
			else
			{
				throw new ArgumentException("File not found.");
			}

			Stream s = null;
			try
			{
				FileInfo file = new FileInfo(this.Filename);
				s = file.OpenRead();
				Read(s);
			}
			finally
			{
				s.Close();
			}
		}//Read


		/// <summary>
		/// Liest den angegebenen Stream ein und speichert, so vorhanden, die
		/// ID3v1-Titelinformationen in den Properties der Instanz dieser Klasse.
		/// </summary>
		/// <param name="s">Der lesbare Stream der einzulesenden Datei.</param>
		public void Read(Stream s)
		{
			m_containsID3Information = ReadId3v1Info(s);
		}//Read


		/// <summary>
		/// Liest die ID3v1 Informationen aus der mp3-Datei ein.
		/// </summary>
		/// <returns>True, wenn ID3v1-Informationen eingelesen wurden, false sonst.</returns>
		private bool ReadId3v1Info(Stream s)
		{
			//Die Datei mu� mindestens 128 Byte gro� sein
			if (s.Length < 128)
			{
				return false;
			}//if

			//Die letzten 128 Byte der Datei enthalten die ID3v1-Tags.
			//Diese werden hier eingelesen
			byte[] bytes = new byte[128];
			s.Seek(-128, SeekOrigin.End);
			int numBytesToRead = 128;
			int numBytesRead = 0;
			while (numBytesToRead > 0) 
			{
				//Read liefert eine Zahl zwischen 0 und numBytesToRead
				int n = s.Read(bytes, numBytesRead, numBytesToRead);

				//Bei R�ckgabe von 0 ist das Ende des Abschnitts erreicht.
				if (n==0)
				{
					break;
				}//if
				numBytesRead += n;
				numBytesToRead -= n;
			}//while
    
			//Nun werden die eingelesenen 128 Byte nach ID3v1-Infos gescannt.
			return ParseId3v1Info(bytes);
		}//ReadID3v1Info


		/// <summary>
		/// Parsed die ID3v1 Informationen aus dem �bergebenen Byte-Array.
		/// </summary>
		/// <remarks>
		/// Die Definition der ID3v1 Titelinformationen stammen von
		/// http://www.id3.org/id3v1.html.
		/// </remarks>
		/// <returns>True, wenn ID3v1-Informationen eingelesen wurden, false sonst.</returns>
		private bool ParseId3v1Info(byte[] bytes)
		{
			//Besitzt die Datei �berhaupt einen ID3v1 Abschnitt?
			//Dieser mu� mit "TAG" beginnen
			String tag = ConvertByteToString(bytes, 0, 2);
			if (tag != "TAG")
			{
				return false;
			}//if

			m_title  = ConvertByteToString(bytes, 3, 32);
			m_artist = ConvertByteToString(bytes, 33, 62);
			m_album  = ConvertByteToString(bytes, 63, 92);

			try
			{
				m_year = Int32.Parse(ConvertByteToString(bytes, 93, 96));
			} 
			catch (FormatException)
			{
				m_year = 0;
			}//end try/catch

			//Es existiert eine Erweiterung des ID3v1-Standard als ID3v1.1
			//Bei ID3v1.1 wird das letzte Byte des Kommentar-Feldes zur Speicherung
			//der Track-Nummer verwendet. Das vorletzte Byte mu� dabei 0 sein.
			byte flag = bytes[125];
			if (flag == 0)
			{ 
				//ID3v1.1
				m_comment = ConvertByteToString(bytes, 97, 124);
				m_track = bytes[126];
			} 
			else 
			{
				//ID3v1, keine Track-Informationen
				m_comment = ConvertByteToString(bytes, 97, 126);
				m_track = 0;
			}//end if flag

			m_genre = bytes[127];
 
			return true;
		}//ParseId3v1Info


		/// <summary>
		/// Gibt ein �bergebenes Byte-Array als String zur�ck.
		/// Dabei wird nur der Ausschnitt von pos1 bis pos2 ber�cksichtigt
		/// </summary>
		/// <param name="bytes">Zu konvertierendes Byte-Array</param>
		/// <param name="pos1">Position, ab der konvertiert werden soll.</param>
		/// <param name="pos2">Position, bis zu der konvertiert werden soll.</param>
		/// <returns></returns>
		private static String ConvertByteToString(byte[] bytes, int pos1, int pos2)
		{
    
			//pos2 mu� gr��er oder gleich pos1 sein und
			//pos2 darf L�nge des Arrays nicht �berschreiten
			if ((pos1 > pos2) || (pos2 > bytes.Length - 1))
			{
				throw new ArgumentException("Aruments out of range");
			}
    
			//L�nge des zu betrachtenden Ausschnittes
			int length = pos2 - pos1 + 1;
    
			//neues Char-Array anlegen der L�nge length
			Char[] chars = new Char[length];
    
			//packe alle Bytes von pos1 bis pos2 als
			//Char konvertiert in Array chars
			for (int i=0; i<length; i++)
			{
				chars[i] = Convert.ToChar(bytes[i+pos1]);
			}//end for
    
			//konvertiere Char-Array in String und gebe es zur�ck
			return new String(chars);
		}//ConvertByteToString


		/// <summary>
		/// Liefert das Genre als Klarname aus einer internen Liste.
		/// </summary>
		/// <param name="genreNr">Die im MP3-File gespeicherte Genre-Nr.</param>
		/// <returns>Klarnamen des Genres oder 'Unknown'.</returns>
		private static String GetGenre(int genreNr)
		{
			if (m_genreArray.Length > genreNr)
			{
				return m_genreArray[genreNr];
			}
			else
			{
				return "Unknown";
			}
		}//GetGenre


		/// <summary>
		/// Liefert die String-Repr�sentation des MP3-Files.
		/// </summary>
		/// <returns>String-Repr�sentation des MP3-Files.</returns>
		public override String ToString()
		{
			String result	=    "Filename: " + this.Filename;
			result			+= "\nTitle   : " + this.Title;
			result			+= "\nArtist  : " + this.Artist;
 			result			+= "\nAlbum   : " + this.Album;
			result			+= "\nYear    : " + this.Year;
			result			+= "\nComment : " + this.Comment;
			result			+= "\nGenre   : " + this.Genre;
			result			+= "\nTrack   : " + this.Track;

			return result;
		}//ToString Array
	}//Mp3Info
}//Mp3
