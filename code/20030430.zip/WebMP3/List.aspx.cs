using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Mp3;

namespace Mp3
{
	/// <summary>
	/// Diese Klasse zeigt in einem DataGrid alle in einem bestimmten Verzeichnis
	/// liegenden MP3-Dateien mit den ID3v1-Titelinformationen an. Sie verwendet
	/// dazu die Funktionalit�ten der Klasse Mp3Info.
	/// Die Seite demonstiert zudem das Binden eines Controls an eine Collection.
	/// </summary>
	public class List : System.Web.UI.Page
	{
		private const string MP3_DIRECTORY = @"C:\MP3\";
		private const string MP3_SEARCH_PATTERN = "*.mp3";

		/// <summary>
		/// DataGrid der Web-Seite stellt die Titelinformationen dar.
		/// </summary>
		protected System.Web.UI.WebControls.DataGrid Mp3Grid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				BindData();
			}//if
		}//Page_Load


		/// <summary>
		/// 
		/// </summary>
		protected void BindData()
		{
			//Besorge Array aller MP3-Dateien aus dem angegebenen Verzeichnis
			string[] allFiles = Directory.GetFiles(MP3_DIRECTORY, MP3_SEARCH_PATTERN);
			ArrayList list = new ArrayList();

			//Erzeuge eine ArrayList mit Objekten vom Typ MP3File
			//aus den Dateien des Arrays.
			for (int i = 0; i < allFiles.Length; i++)
			{
				try
				{			
					Mp3Info mp3Info = new Mp3Info();
					mp3Info.Read(allFiles[i]);

					list.Add(mp3Info);
				}
				catch(Exception e)
				{
					Console.WriteLine("Error: " + e.ToString());
				}
			}//for

			//Binde ArrayList an DataGrid
			Mp3Grid.DataSource = list;
			Mp3Grid.DataBind();
		}


		#region Web Form Designer generated code
		/// <summary>
		/// Auto-Generierte Initialisierungs-Methode
		/// </summary>
		/// <param name="e"></param>
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
