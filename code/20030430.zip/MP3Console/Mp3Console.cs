using System;
using System.IO;

namespace Mp3
{
	/// <summary>
	/// Diese Klasse nutzt die M�glichkeiten der Klasse Mp3Info, um alle MP3
	/// Dateien eines Verzeichnisses mit Ihren ID3v1-Titelinformationen
	/// an der Konsole auszugeben.
	/// </summary>
	public class Mp3Console
	{
		/// <summary>
		/// Einstiegs-Methode. Als Parameter werden der einzulesende Pfadname
		/// und optional ein Suchpattern der Form "*.mp3" erwartet.
		/// </summary>
		[STAThread]
		static public void Main(string[] args)
		{
			String search = "*.mp3";
			if (args.Length < 1)
			{
				Console.WriteLine("Angabe eines Pfadnamens erforderlich!");
				return;
			} 
			else 
			{
				if (args.Length >= 2)
				{
					search = args[1];
				}//if
			}//if
        
			try 
			{
				ShowFiles(args[0], search);     
			} 
			catch (ArgumentException e)
			{
				Console.WriteLine("Error: " + e.Message);
			} 
			catch (Exception e)
			{
				Console.WriteLine("Error: " + e.Message);
			}//try/catch
		}//Main



		/// <summary>
		/// Liest alle im Pfad enthaltenen Dateien, die dem Suchmuster entsprechen,
		/// ein und gibt Dateiname plus evtl. vorhandener ID3v1-Tags auf der Konsole
		/// aus.
		/// </summary>
		/// <param name="path">Absoluter Pfad des einzulesenden Verzeichnisses.</param>
		/// <param name="search">Suchpattern f�r die Dateinamen.</param>
		private static void ShowFiles(String path, String search)
		{
			string[] allFiles = Directory.GetFiles(path, search);
			Mp3Info mp3Info = new Mp3Info();

			for (int i = 0; i < allFiles.Length; i++)
			{
				try
				{
					mp3Info.Read(allFiles[i]);
					if (mp3Info.ContainsID3v1Information)
					{
						Console.WriteLine("\n{0}\n", mp3Info.ToString());
					}
					else
					{
						Console.WriteLine("File '{0}' does not contain ID3v1 information.", allFiles[i]);
					}
				}
				catch(Exception e)
				{
					Console.WriteLine("Error: " + e.ToString());
				}
			}//for
		}//ShowFiles
	}
}
