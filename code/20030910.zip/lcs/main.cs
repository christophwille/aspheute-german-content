using System;
using Algorithms;

class MainClass
{
	[STAThread]
	static void Main(string[] args)
	{
		LCS lcs = new LCS();

		string[] sourceFiles = new string[] {
			@"AssemblyInfo1.cs"
											   };
		string[] destinationFiles = new string[] {
			@"AssemblyInfo2.cs"
											};
		
		lcs.CompareSet(sourceFiles, destinationFiles);
	}
}
