// Portions (c) Mike Kr�ger, mike@icsharpcode.net
// LCS algorithm described: http://www.cs.sunysb.edu/~algorith/files/longest-common-substring.shtml
using System;
using System.IO;
using System.Text;

namespace Algorithms
{
	public class LCS
	{
		private string ReadFile(string fileName)
		{
			StreamReader sr = File.OpenText(fileName);
			string content = sr.ReadToEnd();
			sr.Close();
		
			// filter out whitespaces
			StringBuilder newContent = new StringBuilder();
			for (int i = 0; i < content.Length; ++i) 
			{
				if (!Char.IsWhiteSpace(content[i])) 
				{
					newContent.Append(content[i]);
				}
			}
			return newContent.ToString();
		}
	
		private int[,] table;

		private int Compute(ref string src, ref string dst, int srcOffset, int dstOffset)
		{
			if (srcOffset >= src.Length || dstOffset >= dst.Length) 
			{
				return 0;
			}
		
			if (table[srcOffset, dstOffset] == -1) 
			{
				if (Char.ToUpper(src[srcOffset]) == Char.ToUpper(dst[dstOffset])) 
				{
					table[srcOffset, dstOffset] = 1 + Compute(ref src, ref dst, srcOffset + 1, dstOffset + 1);
				} 
				else 
				{
					table[srcOffset, dstOffset] =  Math.Max(Compute(ref src, ref dst, srcOffset, dstOffset + 1), 
						Compute(ref src, ref dst, srcOffset + 1, dstOffset));
				}
			}
		
			return table[srcOffset, dstOffset];
		}
	
		public void Compare(string srcFile, string dstFile)
		{
			string src = ReadFile(srcFile);
			string dst = ReadFile(dstFile);
		
			table = new int[src.Length, dst.Length];
			for (int i =0; i < src.Length; ++i) 
			{
				for (int j =0; j < dst.Length; ++j) 
				{
					table[i, j] = -1;
				}
			}
			Console.WriteLine("source: {0}, destination: {1}", Path.GetFileName(srcFile), Path.GetFileName(dstFile));
			Console.WriteLine("source length: {0}, destination length: {1}", src.Length, dst.Length);
			int lcs = Compute(ref src, ref dst, 0, 0);
			Console.WriteLine("LCS match: {0}/{1}%", lcs, (lcs * 100) / dst.Length);
		}
	
		public void CompareSet(string[] src, string[] dst)
		{
			for (int i = 0; i < src.Length; ++i) 
			{
				if (src[i] != null && dst[i] != null) 
				{
					Compare(src[i], dst[i]);
				} 
				else 
				{
					Console.WriteLine("{0} file not found: no mach to {1} found", (src[i] == null ? "src" : "dst"), 
						Path.GetFileName(src[i] != null ? src[i] : dst[i]));
				}
			}
		}
	}
}
