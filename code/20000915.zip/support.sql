if exists (select * from sysobjects where id = object_id(N'[dbo].[Support]') and 
 OBJECTPROPERTY(id, N'IsUserTable') = 1) drop table [dbo].[Support]
GO

CREATE TABLE [dbo].[Support] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Name] [varchar] (50) NULL ,
	[EMail] [varchar] (64) NULL ,
	[Programm] [varchar] (255) NULL ,
	[Problem] [text] NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Support] WITH NOCHECK ADD 
	CONSTRAINT [PK_Support] PRIMARY KEY  NONCLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO
