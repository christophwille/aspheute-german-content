using System;

namespace DotNetHeute
	{
	public class HelloWorld
	{
		public void SayHello()
		{
			Console.WriteLine("Hello World!");
		}
	}
}
