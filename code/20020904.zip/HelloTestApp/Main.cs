using System;
using DotNetHeute;

class MainClass
{
	public static void Main(string[] args)
	{
		HelloWorld hw = new HelloWorld();
		hw.SayHello();
	}
}
