Imports System

Class AddSamp

    Shared Sub Main(ByVal args() As String)
        Dim A As Double

        A = Convert.ToDouble(args(0)) + Convert.ToDouble(args(1))
        Console.WriteLine("Add-Result is: " + A.ToString())
    End Sub
End Class
