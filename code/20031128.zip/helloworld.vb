Imports System

Class MainApp
    Public Shared Sub Main()
        Console.WriteLine("Hello World")
    End Sub

End Class
