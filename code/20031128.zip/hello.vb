Imports System

Class MyApp

    Shared UsrName As String

    Public Shared Sub Main()
        Console.Write("Please enter your name: ")
        UsrName = Console.ReadLine()
        Console.WriteLine("Hello " + UsrName + "! You accessed the program at " + System.DateTime.Now + ".")
    End Sub

End Class
