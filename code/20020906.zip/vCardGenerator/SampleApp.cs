using System;
using System.IO;
using AspHeute.Utilities;

public class SampleApp {
	public static void Main() {
		vCardGenerator vcg = new vCardGenerator();
		vcg.FullName = "Christoph Wille";
		vcg.HomeAddress = "Vordernbergerstrasse 27/8;Leoben;AT;8700;Austria";
		vcg.PreferedInternetEmailAddress = "christophw@icsharpcode.net";
		vcg.CellTelVoice = "+43 4711 42";
		
		string strVCard = vcg.Generate();
		FileInfo fi = new FileInfo("sample.vcf");
		StreamWriter sw = fi.CreateText();
		sw.Write(strVCard);
		sw.Flush();
		sw.Close();
	}
}
