using System;
using System.Collections;
using System.Text;

namespace AspHeute.Utilities {
public class vCardGenerator {
	Hashtable Elements;
	
	public vCardGenerator() {
		Elements = new Hashtable();
	}
	
	private void SetProperty(string strElement, string strValue) {
		if (Elements.ContainsKey(strElement)) {
			Elements[strElement] = strValue;
		} else {
			Elements.Add(strElement, strValue);
		}
	}
	
	private string GetProperty(string strElement) {
		if (Elements.ContainsKey(strElement)) {
			return Elements[strElement].ToString();
		}
		
		return "";
	}
	
	public string Generate() {
		StringBuilder stb = new StringBuilder();
		stb.Append("BEGIN:VCARD\r\n");
		stb.Append("VERSION:2.1\r\n");
		
		foreach (DictionaryEntry de in Elements)
		{
			stb.Append(de.Key);
			stb.Append(de.Value);
			stb.Append("\r\n");
		}
		
		stb.Append("END:VCARD\r\n");
		return stb.ToString();
	}
	
	public string FullName {
		get { return GetProperty("FN:"); }
		set { SetProperty("FN:", value); }
	}
	
	public string HomeTelVoice {
		get { return GetProperty("TEL;HOME;VOICE:"); }
		set { SetProperty("TEL;HOME;VOICE:", value); }
	}
	
	public string HomeTelFax {
		get { return GetProperty("TEL;HOME;FAX:"); }
		set { SetProperty("TEL;HOME;FAX:", value); }
	}
	
	public string CellTelVoice {
		get { return GetProperty("TEL;CELL;VOICE:"); }
		set { SetProperty("TEL;CELL;VOICE:", value); }
	}
	
	public string HomeAddress {
		get { return GetProperty("ADR;HOME:;;:"); }
		set { SetProperty("ADR;HOME:;;", value); }
	}
	
	public string PreferedInternetEmailAddress {
		get { return GetProperty("EMAIL;PREF;INTERNET:"); }
		set { SetProperty("EMAIL;PREF;INTERNET:", value); }
	}
	
	
}
}
