using ICSharpCode.SharpUnit;

[TestSuite("Euro Test Suite")]
public class TestEuro {
 [TestMethod("Testet die Funktion auf korrekte Umrechnung")]
 public void TestGetEuroAmount() {
   Euro euro = new Euro();
 	Assertion.AssertEquals(euro.GetEuroAmount(1.955f), 1f, 0.001f);
 }
}
