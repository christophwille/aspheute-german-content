public class Euro {
	public double GetEuroAmount(double dm) {
		return (dm / 1.955f);
	}
}
