using System;
using DotNetHeute.Perso;

class MainClass
{
	public static void Main(string[] args)
	{
		Personalausweisnummer perso = new Personalausweisnummer();
		try {
			perso.ErstwohnsitzKennzahl = "1000";  // vierstellig
			perso.Zaehlnummer = "10000";  // fünfstellig
			perso.Geburtsdatum = "730729";  // Jahr, Monat, Tag
			perso.Ablaufdatum = "050101";  // Jahr, Monat Tag
		}
		catch(Exception e) {
			Console.WriteLine("Daten inkorrekt: ");
			Console.WriteLine(e.Message);
		}
		
		byte a, b, c, d;
		bool bOk = perso.PruefsummenBerechnung(out a, out b, out c, out d);
		if (bOk) {
			Console.WriteLine("a: {0} b: {1} c: {2} d: {3}",a, b, c, d);
		}
		else {
			Console.WriteLine("Berechnung der Prüfsummen konnte nicht durchgeführt werden.");
		}
		
	}
}
