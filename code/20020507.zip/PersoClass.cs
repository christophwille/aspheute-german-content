using System;

namespace DotNetHeute.Perso
{
public enum Persodaten {
	ErstwohnsitzKennzahl = 1,
	Zaehlnummer = 2,
	Geburtsdatum = 4,
	Ablaufdatum = 8
}

public class Personalausweisnummer
{
	private int[] abErstwohnsitzKennzahl;
	private int[] abZaehlnummer;
	private int[] abGeburtsdatum;
	private int[] abAblaufdatum;
	private int ValidData;

	
	public Personalausweisnummer()
	{
		abErstwohnsitzKennzahl = new int[4];
		abZaehlnummer = new int[5];
		abGeburtsdatum = new int[6];
		abAblaufdatum = new int[6];
		ValidData = 0;
	}
	
	public string ErstwohnsitzKennzahl {
		set {
			ValidData &= ~((int)Persodaten.ErstwohnsitzKennzahl);
			if (value.Length != 4) {
				throw new ArgumentException("Erstwohnsitz Kennzahl muß 4 Ziffern lang sein");
			}
			try {
				for (int i=0; i <= 3; i++) {
					abErstwohnsitzKennzahl[i] = Int32.Parse(value[i].ToString());
				}
			}
			catch(Exception e) {
				throw e;
			}
			ValidData |= ((int)Persodaten.ErstwohnsitzKennzahl);
		}
	}
	
	public string Zaehlnummer {
		set {
			ValidData &= ~((int)Persodaten.Zaehlnummer);
			if (value.Length != 5) {
				throw new ArgumentException("Zählnummer muß fünfstellig sein");
			}
			try {
				for (int i=0; i <= 4; i++) {
					abZaehlnummer[i] = Int32.Parse(value[i].ToString());
				}
			}
			catch(Exception e) {
				throw e;
			}
			ValidData |= ((int)Persodaten.Zaehlnummer);
		}
	}	

	public string Geburtsdatum {
		set {
			ValidData &= ~((int)Persodaten.Geburtsdatum);
			if (value.Length != 6) {
				throw new ArgumentException("Geburtsdatum muß sechsstellig sein");
			}
			try {
				for (int i=0; i <= 5; i++) {
					abGeburtsdatum[i] = Int32.Parse(value[i].ToString());
				}
			}
			catch(Exception e) {
				throw e;
			}
			ValidData |= ((int)Persodaten.Geburtsdatum);
		}
	}	
	
	public string Ablaufdatum {
		set {
			ValidData &= ~((int)Persodaten.Ablaufdatum);
			if (value.Length != 6) {
				throw new ArgumentException("Ablaufdatum muß sechsstellig sein");
			}
			try {
				for (int i=0; i <= 5; i++) {
					abAblaufdatum[i] = Int32.Parse(value[i].ToString());
				}
			}
			catch(Exception e) {
				throw e;
			}
			ValidData |= ((int)Persodaten.Ablaufdatum);
		}
	}

	public bool IsDataValid()
	{
		int nValidIf = ((int)Persodaten.ErstwohnsitzKennzahl) | ((int)Persodaten.Zaehlnummer) |
			((int)Persodaten.Geburtsdatum) | ((int)Persodaten.Ablaufdatum);
		
		return (nValidIf == ValidData);
	}

	public bool PruefsummenBerechnung(out byte PruefsummeAZiffer, out byte PruefsummeBZiffer, 
	                                  out byte PruefsummeCZiffer, out byte PruefsummeDZiffer)
	{
		PruefsummeAZiffer = PruefsummeBZiffer = PruefsummeCZiffer = PruefsummeDZiffer = 0;
		if (!IsDataValid()) return false;
		
		int PruefsummeA;
		PruefsummeA = (abErstwohnsitzKennzahl[0] * 7) +
			(abErstwohnsitzKennzahl[1] * 3) +
			(abErstwohnsitzKennzahl[2]* 1) +
			(abErstwohnsitzKennzahl[3] * 7) +
			(abZaehlnummer[0] * 3) +
			(abZaehlnummer[1] * 1) +
			(abZaehlnummer[2] * 7) +
			(abZaehlnummer[3] * 3) +
			(abZaehlnummer[4] * 1);
		string strPruefsummeA = Convert.ToString(PruefsummeA);
		PruefsummeAZiffer = Convert.ToByte(strPruefsummeA.Substring(strPruefsummeA.Length - 1));
		
		int PruefsummeB;
		PruefsummeB = (abGeburtsdatum[0] * 7) +
			(abGeburtsdatum[1] * 3) +
			(abGeburtsdatum[2] * 1) +
			(abGeburtsdatum[3] * 7) +
			(abGeburtsdatum[4] * 3) +
			(abGeburtsdatum[5] * 1);
		string strPruefsummeB = Convert.ToString(PruefsummeB);
		PruefsummeBZiffer = Convert.ToByte(strPruefsummeB.Substring(strPruefsummeB.Length - 1));
	
		int PruefsummeC;
		PruefsummeC = (abAblaufdatum[0] * 7) +
			(abAblaufdatum[1] * 3) +
			(abAblaufdatum[2] * 1) +
			(abAblaufdatum[3] * 7) +
			(abAblaufdatum[4] * 3) +
			(abAblaufdatum[5] * 1);
		string strPruefsummeC = Convert.ToString(PruefsummeC);
		PruefsummeCZiffer = Convert.ToByte(strPruefsummeC.Substring(strPruefsummeC.Length - 1));
		
		int PruefsummeD;
		PruefsummeD = (abErstwohnsitzKennzahl[0] * 7) +
			(abErstwohnsitzKennzahl[1] * 3) +
			(abErstwohnsitzKennzahl[2]* 1) +
			(abErstwohnsitzKennzahl[3] * 7) +
			(abZaehlnummer[0] * 3) +
			(abZaehlnummer[1] * 1) +
			(abZaehlnummer[2] * 7) +
			(abZaehlnummer[3] * 3) +
			(abZaehlnummer[4] * 1) +
			(PruefsummeAZiffer * 7) +
			(abGeburtsdatum[0] * 3) +
			(abGeburtsdatum[1] * 1) +
			(abGeburtsdatum[2] * 7) +
			(abGeburtsdatum[3] * 3) +
			(abGeburtsdatum[4] * 1) +
			(abGeburtsdatum[5] * 7) + 
			(PruefsummeBZiffer * 3) +
			(abAblaufdatum[0] * 1) +
			(abAblaufdatum[1] * 7) +
			(abAblaufdatum[2] * 3) +
			(abAblaufdatum[3] * 1) +
			(abAblaufdatum[4] * 7) +
			(abAblaufdatum[5] * 3) +
			(PruefsummeCZiffer * 1);
		string strPruefsummeD = Convert.ToString(PruefsummeD);
		PruefsummeDZiffer = Convert.ToByte(strPruefsummeD.Substring(strPruefsummeD.Length - 1));
		
		return true;
	}
}
} // end namespace
