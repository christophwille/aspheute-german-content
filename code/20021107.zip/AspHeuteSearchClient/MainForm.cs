using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Diagnostics;

namespace AspHeuteSearchClient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class SearchForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtKeyword;
		private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.ListView lvResults;
		private System.Windows.Forms.ColumnHeader colDocTitle;
		private System.Windows.Forms.TextBox txtSummary;
		private System.Windows.Forms.TextBox txtUrl;
		private System.Windows.Forms.Button btnViewArticle;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SearchForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtKeyword = new System.Windows.Forms.TextBox();
			this.btnSearch = new System.Windows.Forms.Button();
			this.lvResults = new System.Windows.Forms.ListView();
			this.colDocTitle = new System.Windows.Forms.ColumnHeader();
			this.txtSummary = new System.Windows.Forms.TextBox();
			this.txtUrl = new System.Windows.Forms.TextBox();
			this.btnViewArticle = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Search keyword:";
			// 
			// txtKeyword
			// 
			this.txtKeyword.Location = new System.Drawing.Point(104, 16);
			this.txtKeyword.Name = "txtKeyword";
			this.txtKeyword.Size = new System.Drawing.Size(176, 20);
			this.txtKeyword.TabIndex = 1;
			this.txtKeyword.Text = "aspheute";
			// 
			// btnSearch
			// 
			this.btnSearch.Location = new System.Drawing.Point(288, 16);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.TabIndex = 2;
			this.btnSearch.Text = "Search!";
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			// 
			// lvResults
			// 
			this.lvResults.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.colDocTitle});
			this.lvResults.FullRowSelect = true;
			this.lvResults.GridLines = true;
			this.lvResults.Location = new System.Drawing.Point(16, 48);
			this.lvResults.Name = "lvResults";
			this.lvResults.Size = new System.Drawing.Size(416, 184);
			this.lvResults.TabIndex = 3;
			this.lvResults.View = System.Windows.Forms.View.Details;
			this.lvResults.SelectedIndexChanged += new System.EventHandler(this.lvResults_SelectedIndexChanged);
			// 
			// colDocTitle
			// 
			this.colDocTitle.Text = "Document Title";
			this.colDocTitle.Width = 390;
			// 
			// txtSummary
			// 
			this.txtSummary.Location = new System.Drawing.Point(16, 240);
			this.txtSummary.Multiline = true;
			this.txtSummary.Name = "txtSummary";
			this.txtSummary.ReadOnly = true;
			this.txtSummary.Size = new System.Drawing.Size(416, 88);
			this.txtSummary.TabIndex = 4;
			this.txtSummary.Text = "";
			// 
			// txtUrl
			// 
			this.txtUrl.Location = new System.Drawing.Point(96, 336);
			this.txtUrl.Name = "txtUrl";
			this.txtUrl.Size = new System.Drawing.Size(48, 20);
			this.txtUrl.TabIndex = 5;
			this.txtUrl.TabStop = false;
			this.txtUrl.Text = "URL";
			this.txtUrl.Visible = false;
			// 
			// btnViewArticle
			// 
			this.btnViewArticle.Location = new System.Drawing.Point(16, 336);
			this.btnViewArticle.Name = "btnViewArticle";
			this.btnViewArticle.TabIndex = 6;
			this.btnViewArticle.Text = "View Article!";
			this.btnViewArticle.Click += new System.EventHandler(this.btnViewArticle_Click);
			// 
			// SearchForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(448, 365);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnViewArticle,
																		  this.txtUrl,
																		  this.txtSummary,
																		  this.lvResults,
																		  this.btnSearch,
																		  this.txtKeyword,
																		  this.label1});
			this.Name = "SearchForm";
			this.Text = "Search AspHeute.com";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new SearchForm());
		}

		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			string strKeyword = txtKeyword.Text;
			AspHeute.AspHeuteSearch ahs = new AspHeute.AspHeuteSearch();
			DataSet ds = ahs.KeywordSearch(strKeyword, 50);
			DataTable dt = ds.Tables[0];

			lvResults.BeginUpdate();
			txtUrl.Text = "";
			lvResults.Items.Clear();
			foreach (DataRow dr in dt.Rows)
			{
				ListViewItem lvi = new ListViewItem();

				// Vpath,DocTitle,Characterization,Rank -> order of columns in table
				lvi.Text = dr[1].ToString(); 
				lvi.SubItems.Add(dr[0].ToString());
				lvi.SubItems.Add(dr[2].ToString());
				lvResults.Items.Add(lvi);
			}
			lvResults.EndUpdate();

			MessageBox.Show("Search is complete - " + 
				dt.Rows.Count.ToString() + 
				" results returned from search",
				"Search AspHeute.com");
	}

		private void lvResults_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (lvResults.SelectedItems.Count == 0) return;
			ListViewItem lvi = lvResults.SelectedItems[0];
			txtSummary.Text = lvi.SubItems[2].Text;	// show summary text
			txtUrl.Text = lvi.SubItems[1].Text;			// define hyperlink of document
	}

		private void btnViewArticle_Click(object sender, System.EventArgs e)
		{
			if (txtUrl.Text != "")
				Process.Start("http://www.aspheute.com" + txtUrl.Text);
		}
}
}
