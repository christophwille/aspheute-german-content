using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

using System.Data;
using System.Data.OleDb;

namespace Suche
{
	[WebService(Namespace="http://microsoft.com/webservices/")]
	public class AspHeuteSearch : System.Web.Services.WebService
	{
		private static string CiCatalog = "aspheute.com";
		private static string CiScope = "/artikel/";
		private static string CiFlags = "SHALLOW";  // "DEEP" not needed in CiScope

		public AspHeuteSearch()
		{
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		public DataSet KeywordSearch(string Keyword, int MaxResults)
		{
			if (MaxResults < 5 || MaxResults > 250)
				throw new ArgumentOutOfRangeException("MaxResults", MaxResults, "Range is 5-250");

			if (Keyword.Length < 3)
				throw new ArgumentOutOfRangeException("Keyword", Keyword, "Minimum length of search keyword is 3 characters");

			return PerformQuery("@ALL " + Keyword, MaxResults);
		}
		
		[WebMethod]
		public DataSet IXAdvancedQuery(string Query, int MaxResults)
		{
			if (MaxResults < 5 || MaxResults > 250)
				throw new ArgumentOutOfRangeException("MaxResults", MaxResults, "Range is 5-250");

			return PerformQuery(Query, MaxResults);
		}

		private DataSet PerformQuery(string strQuery, int nMaxResults)
		{
			Cisso.CissoQueryClass cqc = new Cisso.CissoQueryClass();
			cqc.Catalog = CiCatalog;
			cqc.MaxRecords = nMaxResults;
			cqc.CiScope = CiScope;
			cqc.CiFlags = CiFlags; 
			cqc.Query = strQuery;
			cqc.Columns = "Vpath,DocTitle,Characterization,Rank";
			cqc.SortBy = "Rank[d]";

			ADODB.Recordset rsIX = (ADODB.Recordset)cqc.CreateRecordset("nonsequential");

			OleDbDataAdapter daConvertToDataset = new OleDbDataAdapter();
			DataSet myDS = new DataSet();
			daConvertToDataset.Fill(myDS, rsIX, "IXResults");
			return myDS;
		}
	}
}
