using System;
using System.Web; 
using System.Collections.Specialized;

public class RefererCheckModule: IHttpModule
{
	protected StringCollection AllowedHosts;

	public RefererCheckModule()
	{
		// do init here (XML or database would be more appropriate)
		AllowedHosts = new StringCollection();
		AllowedHosts.Add("sleeper");
		AllowedHosts.Add("localhost");
	}

	public void Init(HttpApplication theApp)
	{
		theApp.BeginRequest += (new EventHandler(this.Application_BeginRequest));
	}

	public void Dispose()
	{
		// we have nothing to dispose (yet)
	}

	private void Application_BeginRequest(object source, EventArgs e) 
	{
		if (null == source) return;

		HttpApplication theApp = (HttpApplication)source;
		HttpContext context = theApp.Context;
		Uri urlref = context.Request.UrlReferrer;
		if (null == urlref) return; // assume local
		string strReferer = urlref.Host;
		
		bool bFound = AllowedHosts.Contains(strReferer.ToLower());
		if (!bFound)
		{
			context.Response.Redirect("/AspHeute/LinkingHostNotAllowed.htm", true);
			// and log the referer (to a database table)
		}
	}

}

