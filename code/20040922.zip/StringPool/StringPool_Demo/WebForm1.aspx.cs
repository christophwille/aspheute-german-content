using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using MultiKulti;

namespace StringPool_Demo
{
	/// <summary>
	/// Zusammenfassung f�r WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblOut;
		protected System.Web.UI.WebControls.Button btn;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
		}

		#region Vom Web Form-Designer generierter Code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: Dieser Aufruf ist f�r den ASP.NET Web Form-Designer erforderlich.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btn.Click += new System.EventHandler(this.btn_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btn_Click(object sender, System.EventArgs e) {
		
			// Setze Beschriftung f�r Label mithilfe der StringPool-Klasse
			lblOut.Text = StringPool.GetInstance().GetString("Administration", "CommitButton", "D");
		}
	}
}