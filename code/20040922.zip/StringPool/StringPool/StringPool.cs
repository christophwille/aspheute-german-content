using System;
using System.Collections;
using System.Collections.Specialized;
using System.Configuration;
using System.Xml;
using System.Web;
using System.Web.Caching;

namespace MultiKulti
{
	/// <summary>
	/// Managed den sprachgesteuerten Zugriff auf das StringPool-XML-File
	/// </summary>
	public class StringPool
	{
		#region Variables

		private static Cache stCache = new Cache();
		private Hashtable regions=new Hashtable();
		
		// Konstanten
		const string CONFIG_DEFAULTLANGUAGE = "DefaultLanguage";
		const string CONFIG_FILENAME = "XmlFile";
		const string CACHE_KEY = "StringPool";
		const string XML_ROOTNODE = "StringPool/Region";

		#endregion


		#region Property: DefaultLanguage

		/// <summary>
		/// Standardsprache (aus Config-Datei)
		/// </summary>
		public static string DefaultLanguage
		{
			get { return ConfigurationSettings.AppSettings[CONFIG_DEFAULTLANGUAGE]; }
		}

		#endregion

		#region Property: SourceFile

		/// <summary>
		/// Physischer Pfad zur Xml-Datei (aus Config-Datei)
		/// </summary>
		public static string SourceFile
		{
			get { return ConfigurationSettings.AppSettings[CONFIG_FILENAME]; }
		}

		#endregion


		#region Constructor

		/// <summary>
		/// Privater Konstruktor
		/// </summary>
		private StringPool()
		{
		}

		#endregion


		#region Methods: GetInstance (Singleton-Pattern)

		/// <summary>
		/// Liefert eine Instanz von StringPool (Singleton)
		/// </summary>
		/// <returns></returns>
		public static StringPool GetInstance() {

			// Erstelle Cache-Objekt je nach Plattform (Web- / Winform)
			Cache myCache;
			if(HttpContext.Current == null)
				myCache = HttpRuntime.Cache;
			else
				myCache = HttpContext.Current.Cache;
			
			// Pr�fe ob Cache leer ist
			if(myCache[CACHE_KEY] == null) {
				
				// Erstelle StringPool-Instanz und lade Strings
				StringPool st = new StringPool();
				st.LoadStrings();
				
				// Cache neu f�llen
				myCache.Insert(
					CACHE_KEY, st, new CacheDependency(SourceFile));
			}

			// Gebe StringPool-Objekt aus Cache zur�ck
			return (StringPool)myCache[CACHE_KEY];
		}

		#endregion

		#region Methods: LoadSourceFile

		/// <summary>
		/// L�dt die XML-Source-Datei in ein XmlDocument-Objekt
		/// </summary>
		/// <param name="file">Pfad zur Source-Datei</param>
		/// <returns>XmlDocument</returns>
		private XmlDocument LoadSourceFile(string file)
		{
			// Load the xml-file in a xml-document
			XmlDocument xDoc = new XmlDocument();
			
			try 
			{
				xDoc.Load(file);
			} 
			catch (System.IO.FileNotFoundException) 
			{ 
				throw new Exception("Xml-File "+file+" wurde nicht gefunden");
			} 
			catch (System.Exception ex) 
			{
				throw new Exception("Allgemeiner Fehler beim Laden von "+file+": " + ex.Message);
			}

			return xDoc;
		}

		#endregion

		#region Methods: LoadStrings

		/// <summary>
		/// L�dt die Strings aus dem XmlFile in das Datenmodell mit den verschachtelten Dictionaries
		/// </summary>
		public void LoadStrings() 
		{
			// Regions-Hashtable leeren
			regions.Clear();

			// XML-File laden
			XmlDocument xDoc = LoadSourceFile(SourceFile);
			
			// XML-Daten lesen
			try {
				// Durch Region-Nodes iterieren
				foreach(XmlNode regionNode in xDoc.SelectNodes(XML_ROOTNODE)) {

					Hashtable strs = new Hashtable();
				
					// Durch Text-Nodes in aktuellem Region-Node iterieren
					foreach(XmlNode textNode in regionNode.ChildNodes) {
					
						StringDictionary texts = new StringDictionary();

						// Durch Text-Elemente iterieren und diese in eine Hashtable speichern
						foreach(XmlNode txt in textNode.ChildNodes)
							texts.Add(txt.Name, txt.InnerText);
					
						// StringDictionary mit Text-Elementen in �bergeordnetes HashTable-Item speichern
						strs.Add(textNode.Attributes["key"].Value, texts);
					}

					this.regions.Add(regionNode.Attributes["name"].Value, strs);
				}
			} catch (System.Exception ex) {
				throw new Exception("Fehler beim einlesen des Xml-Files"+SourceFile+": " + ex.Message);
			}
		}

		#endregion

		#region Methods: GetString

		/// <summary>
		/// Liefert den gew�nschten String abh�ngig vom Key in der gew�nschhten Sprache
		/// </summary>
		/// <param name="region">Bestimmt den Namen der gesuchten Region</param>
		/// <param name="key">Key des String-Eintrags</param>
		/// <param name="language">Sprache</param>
		/// <returns>String</returns>
		public string GetString(string region, string key, string language) 
		{
			string text = null;
			
			// Lese Text mit den gegebenen Parametern region, key und language
			try
			{
				// Pr�fen ob Regions vorhanden sind
				if(regions.Count > 0)
				{
					//  Pr�fen ob angeforderte Region vorhanden ist
					if(regions[region] != null) 
					{
						// Pr�fen ob gew�hlte Sprache vorhanden ist;
						// ansonsten wird die Default-Sprache verwendet
						if( ((StringDictionary)((Hashtable)regions[region])[key]).ContainsKey(language.ToString()) ) 
							text = ((StringDictionary)((Hashtable)regions[region])[key])[language];
						else
							text = ((StringDictionary)((Hashtable)regions[region])[key])[DefaultLanguage];

						return text;

					} 
					else
					
						// Region nicht vorhanden
						throw new Exception(string.Format(
							"Region {0} ist nicht vorhanden", region));
				} else
					return "";
			}
			// Fehlerbehandlung
			catch (System.Exception ex)
			{
				throw new Exception("Folgende Parameter ergaben kein Ergebnis im aktuellen Objekt:" +
					"Region: " + region + " " +
					"Key: " + key  + " " +
					"Language: " + language +
					"Fehlermeldung: " + ex.Message);
			}
			
		}

		public string GetString(string region, string key)
		{
			return GetString(region, key, DefaultLanguage);
		}

		#endregion
	}
}
