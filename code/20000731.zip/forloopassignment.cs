using System;

class BeispielArrays
{
  public static void Main()
  {
	int[] arTestSDim = new int[4];
	for (int n=0; n < 4; n++)
	{
		arTestSDim[n] = n;
	}
  }
}