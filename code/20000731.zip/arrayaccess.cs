using System;

class BeispielArrays
{
  public static void Main()
  {
	int[] arTestSDim = {0, 1, 2, 3};
	int n = arTestSDim[3];
  }
}