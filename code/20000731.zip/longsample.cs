using System;

class BeispielArrays
{
  public static void Main()
  {
    // Eindimensionales Array
    int[] arTestSDim = new int[10];
     
    // Mehrdimensionales Array
    int[,] arTestMDim = new int[4,5];

    // Array von Arrays (Jagged Array)
    byte[][] arTestJagAr = new byte[4][];
        
    // Erstellen eines Jagged Arrays
    for (int n = 0; n < arTestJagAr.Length; n++)
    {
      arTestJagAr[n] = new byte[n+2];
    }
        
    // Ausgabe der L�nge jeder Reihe<br>
    for (int n = 0; n < arTestJagAr.Length; n++)
    {
      Console.WriteLine("Die Laenge der Reihe {0} ist {1}", 
        n, arTestJagAr[n].Length);
    }
  }
}