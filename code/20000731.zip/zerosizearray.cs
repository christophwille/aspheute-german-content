using System;

public class TestApp
{
 public static void Main()
 {
  int[] nTest;
  nTest = new int[0];
 }
}