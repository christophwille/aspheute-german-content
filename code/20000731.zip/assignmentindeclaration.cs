using System;

class BeispielArrays
{
  public static void Main()
  {
	int[] arTestSDim = {0, 1, 2, 3};
  }
}