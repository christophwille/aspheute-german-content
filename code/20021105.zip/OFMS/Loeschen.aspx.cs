using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace OFMS
{
	/// <summary>
	/// Summary description for Loeschen.
	/// </summary>
	/// 


	public class LoeschenForm : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Sicherheitsabfrage;
		protected System.Web.UI.WebControls.Button DateiLoeschen;
		protected System.Web.UI.WebControls.Label lblTest;
		protected System.Web.UI.WebControls.Button DateiNichtLoeschen;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Die WebForm Loeschen.aspx besitzt kein User Interface.
			// Beim Laden definieren den virtuellen und den 
			// physischen Pfad der zu l�schenden Datei.
			string virtuellerPfad = Request.Params["Dateiname"];
			
			// check ob der virtuellePfad g�ltig ist
			// dh. kein Dateipfad
			if (virtuellerPfad.IndexOf(":") > 0)
			{
				Response.Redirect("OFMS.aspx?Verzeichnis=/");
			}

			string Dateipfad = Server.MapPath(virtuellerPfad);

			// wir m�chten nun checken, ob es sich �berhaupt um 
			// eine Datei handelt
			if (!System.IO.File.Exists(Dateipfad))
			{
				// Wenn das File nicht existiert, linken
				// wir einfach auf die Startseite
				this.Ursprungsverzeichnis();
			}

			// und zeigt ihn im Label Sicherheitsabfrage an
			Sicherheitsabfrage.Text += "Wollen Sie die Datei ";
			Sicherheitsabfrage.Text += Dateipfad.ToString() + " [" + virtuellerPfad.ToString() + "]";
			Sicherheitsabfrage.Text += " wirklich l�schen?";
			Sicherheitsabfrage.Visible = true;
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DateiLoeschen.Click += new System.EventHandler(this.DateiLoeschen_Click);
			this.DateiNichtLoeschen.Click += new System.EventHandler(this.DateiNichtLoeschen_Click);
			this.ID = "LoeschenForm";
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void DateiLoeschen_Click(object sender, System.EventArgs e)
		{
			string virtuellerPfad = Request.Params["Dateiname"];
			string Dateipfad = Server.MapPath(virtuellerPfad);

			// es wird die Datei aus dem Dateipfad extrahiert
			// und gel�scht.
			System.IO.FileInfo Datei = new System.IO.FileInfo(Dateipfad);
			Datei.Delete();
			
			// zur�ck zum Ursprungsverzeichnis
			this.Ursprungsverzeichnis();
		}

		private void DateiNichtLoeschen_Click(object sender, System.EventArgs e)
		{
			// go home ...
			this.Ursprungsverzeichnis();
		}

		private void Ursprungsverzeichnis()
		{
			// in dieser Funktion wird zum Ursprungsverzeichnis
			// gelinkt, von welchem wir aus die Datei
			// zu l�schen versuchten. Da wir diese Funktionalit�t
			// in dieser CodeBehindForm 3 mal ben�tigen, lagen wir
			// sie aus.

			// physischen Pfad der zu l�schenden Datei
			string virtuellerPfad = Request.Params["Dateiname"];
			string Dateipfad = Server.MapPath(virtuellerPfad);

			// der virtuelle Pfad wird von unn�tzen Slashs gereinigt
			int letzterSlash = virtuellerPfad.LastIndexOf("/");
			
			string Ort = virtuellerPfad.Substring(0,letzterSlash);
			if (Ort.Length == 0)
			{
				// Rootverzeichnis
				Ort = "/";
			}
			
			// Schlussendlich wird auf das Ursprungsverzeichnis gelinkt.
			Response.Redirect("OFMS.aspx?Verzeichnis=" + Ort);
		}

	}
}
