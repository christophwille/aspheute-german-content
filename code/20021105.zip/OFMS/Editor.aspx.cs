using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;

namespace OFMS
{
	/// <summary>
	/// Summary description for Editor.
	/// </summary>
	public class EditorForm : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox DateiSpeichernUnter;
		protected System.Web.UI.WebControls.Button DateiSpeichern;
		protected System.Web.UI.WebControls.Button ZurueckZuOFMS;
		protected System.Web.UI.WebControls.Label StatusMessage;
		protected System.Web.UI.WebControls.TextBox DateiInhalt;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
         if (!Page.IsPostBack)
			{
				// wir definieren den Dateipfad aus dem Querystring
				string Dateipfad = Request.Params["Dateiname"];

				// Sollte der Dateipfad nicht null sein ...
				if (Dateipfad != null)
				{
					// und auch der Parameter "erzeugen" weder null noch false sein ...
					if (Request.Params["erzeugen"] == null || Request.Params["erzeugen"] == "false")
					{
						try
						{
							// erzeugen wir einen StreamReader, welcher die Datei (Dateipfad) einliest ...
							StreamReader sr = new StreamReader(File.Open(Server.MapPath(Dateipfad),FileMode.Open));

							// und in die Textbox DateiInhalt vollst�ndig einliest.
							DateiInhalt.Text = sr.ReadToEnd();

							// Anschlie�end schlie�en wir den StreamReader.
							sr.Close();
						}
						catch (Exception ex)
						{
							StatusMessage.Text = ex.Message;
							StatusMessage.Visible = true;
						}
					}

					// in die Textbox DateiSpeichernUnter schreiben wir den virtuellen Dateipfad
					// um die Datei anschliessend speichern zu k�nnnen.
					DateiSpeichernUnter.Text = Dateipfad;
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ID = "EditorForm";

		}
		#endregion

		private void DateiSpeichern_Click(object sender, System.EventArgs e)
		{
			// es soll der Inhalt des Textfeldes DateiInhalt
			// gespeichert werden.
			try
			{
				// als Zielpfad wird der in der Textbox angegebene, logische
				// Pfad angegeben
				string DateiPfad = DateiSpeichernUnter.Text;
				if (!DateiPfad.StartsWith("/"))
				{
					DateiPfad = "/" + DateiPfad;
				}
				// wir erzeugen einen StreamWriter
				// und �bergeben ihm als Wert eine neue Datei (File.CreateText)
				// welcher wir als Zielpfad unseren gemappten DateiPfad mitgeben
				StreamWriter DateiStreamWriter = File.CreateText(Server.MapPath(DateiPfad));
				
				// wir schreiben den Inhalt der Textbox in das File ...
				DateiStreamWriter.Write(DateiInhalt.Text);

				// ... und schlie�en es.
				DateiStreamWriter.Close();
				StatusMessage.Text = "Datei wurde erfolgreich gespeichert!";
			}
			catch (Exception ex)
			{
				StatusMessage.Text = ex.Message;
			}
			// auf jedem Fall geben wir eine (Erfolgs)Nachricht aus
			StatusMessage.Visible = true;
		}

		private void ZurueckZuOFMS_Click(object sender, System.EventArgs e)
		{
			string Dateiname = Request.Params["Dateiname"];
			if (Dateiname != null && Dateiname != "/")
			{
				int letzterSlash = Dateiname.LastIndexOf("/");
				string VerzeichnisPfad = Dateiname.Substring(0,letzterSlash + 1);
				Response.Redirect("OFMS.aspx?Verzeichnis=" + VerzeichnisPfad);
			}
			else
			{
				Response.Redirect("OFMS.aspx");
			}
		}
	}
}
