vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Sep 2002 00:15:17 -0000
vti_extenderversion:SR|4.0.2.5322
