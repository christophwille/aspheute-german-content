using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;

namespace OFMS
{
	/// <summary>
	/// Summary description for OFMS.
	/// </summary>
	public class Main : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button DateiNeu;
		protected System.Web.UI.WebControls.Label Physicher_und_Logischer_Pfad;
		protected System.Web.UI.WebControls.Table DateienUndVerzeichnisse;
		protected System.Web.UI.WebControls.Button Upload;
		protected System.Web.UI.HtmlControls.HtmlInputFile DateiUpload;
		protected System.Web.UI.WebControls.Label StatusMessage;
		protected System.Web.UI.WebControls.TextBox DateiNameNeu;
	
		private string VerzeichnisPfad;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				// wir holen aus dem QueryString das Verzeichnis, welches zu scannen ist
				// und testen den Pfad auf Inhalt
				VerzeichnisPfad = Request.Params["Verzeichnis"];

				if (VerzeichnisPfad == null || VerzeichnisPfad == "/" || VerzeichnisPfad.IndexOf(":") > 0)
				{
					VerzeichnisPfad = Request.ApplicationPath.ToString();
				}

					// ... und wenn der VerzeichnisPfad nicht "/" ist, aber mit "/" endet, dann
					// entfernen wir es

				else if (VerzeichnisPfad.EndsWith("/"))
				{
					VerzeichnisPfad = VerzeichnisPfad.Substring(0,VerzeichnisPfad.Length - 1);
				}

				// ausserdem schreiben wir den physischen und virtuellen Pfad
				Physicher_und_Logischer_Pfad.Text = "Virtueller Pfad: " + VerzeichnisPfad +
					"<br>Physischer Pfad: " + Server.MapPath(VerzeichnisPfad);

				// ... jetzt k�nnen wir das Verzeichnis scannen
				TabelleDateienUndVerzeichnisseFuellen();
			}
		}


		private void TabelleDateienUndVerzeichnisseFuellen()
		{
			string Ort = "";

			// Es werden Definitionen f�r 
			// * �ber- und untergeordnete Verzeichnisse
			// * untergeordnete Dateien
			// * Icons zur Dateibezeichnung
			// * Gr��e der Datei
			// * Editierung und L�schen
			// * erzeugt und ver�ndert Zeitstempel
			// * das Dateispezifische Icon
			DirectoryInfo ueberVerzeichnis;
			DirectoryInfo[] unterVerzeichnisse;
			FileInfo[] unterDateien;
			TableCell ZelleIcon;
			TableCell ZelleDownload;
			HyperLink LinkDownload;
			TableCell ZelleEdit;
			HyperLink LinkEdit;
			TableCell ZelleLoeschen;
			HyperLink LinkLoeschen;
			TableCell ZelleGroesse;
			TableCell ZelleErzeugt;
			TableCell ZelleVeraendert;
			System.Web.UI.WebControls.Image DateiIcon;

			// es wird versucht, das �bergeordnete Verzeichnis und die untergeordneten
			// Dateien auszulesen
			// bei einem Fehler wird die Fehlermeldung in den Label StatusMessage
			// geschrieben
			try
			{
				ueberVerzeichnis = new DirectoryInfo(Server.MapPath(VerzeichnisPfad));

				// es werden alle Unterverzeichnisse und Dateien geholt
				unterVerzeichnisse = ueberVerzeichnis.GetDirectories();
				unterDateien = ueberVerzeichnis.GetFiles();
			}
			catch (Exception ex)
			{
				StatusMessage.Text = ex.Message;
				StatusMessage.Visible = true;
				return;
			}

			// es werden eine Zeile, eine Zelle mit Hyperlinks und ein Hyperlink
			// definiert. Die Zeile ben�tigen wir, um f�r die Verzeichnisse und
			// Dateien im jeweiligen Verzeichnis eine Zeile zur Tabelle hinzuzuf�gen.
			// Die LinkZelle wird einen Hyperlink auf ein untergeordnetes Verzeichnis
			// bzw. auf eine Datei enthalten.
			TableRow Zeile;
			TableCell ZelleLink;
			HyperLink Link;

			// Auch die Styles werden dynamisch hinzugef�gt.
			// Daf�r verwenden wir die Klasse Style aus dem Namespace
			// System.Web.UI.WebControls
			Style StyleVerzeichnisse = new Style();
			StyleVerzeichnisse.BackColor = Color.Gainsboro;
			StyleVerzeichnisse.Font.Name = "Verdana";
			StyleVerzeichnisse.Font.Bold = true;
			StyleVerzeichnisse.Font.Underline = false;
			StyleVerzeichnisse.Font.Size = 8;
			StyleVerzeichnisse.ForeColor = Color.Black;

			Style StyleDateien = new Style();
			StyleDateien.BackColor = Color.Beige;
			StyleDateien.Font.Name = "Verdana";
			StyleDateien.Font.Bold = true;
			StyleDateien.Font.Underline = false;
			StyleDateien.Font.Size = 8;
			StyleDateien.ForeColor = Color.Black;

			Style StyleLink = new Style();
			StyleLink.Font.Name = "Verdana";
			StyleLink.Font.Bold = true;
			StyleLink.Font.Underline = false;
			StyleLink.Font.Size = 8;
			StyleLink.ForeColor = Color.Black;

			// Nun beginnt der Teil, in dem wir unterscheiden, ob es sich um ein
			// Verzeichnis oder eine Datei handelt. Anhand dessen f�gen wir je eine
			// Zeile zur Tabelle hinzu.
			// Wenn nun das aktuelle Verzeichnis NICHT das Wurzelverzeichnis ist
			// (ungleich "/"), dann f�ge das "eine Verzeichnisebene h�her" Icon ein 
			// und verlinke es

			// *********************************************************
			// In diesem Fall handelt es sich um das Up-Verzeichnis
			// *********************************************************

			if (VerzeichnisPfad != "/")
			{
				Zeile = new TableRow();
				ZelleLink = new TableCell();
				Link = new HyperLink();
				ZelleIcon = new TableCell();
				ZelleGroesse = new TableCell();
				DateiIcon = new System.Web.UI.WebControls.Image();

				// wir erzeugen eine Zelle mit dem "eine Verzeichnisebene h�her" Icon
				// und justieren den Inhalt der Zelle zentriert
				DateiIcon.ImageUrl = "./Bilder/Ebene_hoeher.gif";
				ZelleIcon.Controls.Add(DateiIcon);
				ZelleIcon.HorizontalAlign = HorizontalAlign.Center;

				// f�ge einen Link hinzu, der eine Ebenen h�her zeigt
				Link.Text = "...";
				
				int letzterSlash = VerzeichnisPfad.LastIndexOf("/");
				Ort = VerzeichnisPfad.Substring(0,letzterSlash);
				if (Ort.Length == 0)
				{
					// Rootverzeichnis
					Ort = "/";
				}

				Link.NavigateUrl = "OFMS.aspx?Verzeichnis=" + Server.UrlEncode(Ort);
				Link.ApplyStyle(StyleLink);
				ZelleLink.Controls.Add(Link);

				// weiters werden die Dummyzellen
				// Download, Edit, Gr�sse, Erzeugt und Ver�ndert 
				// leer hinzugef�gt
				ZelleDownload = new TableCell();
				ZelleDownload.Text = "";
				ZelleEdit = new TableCell();
				ZelleEdit.Text = "";
				ZelleLoeschen = new TableCell();
				ZelleLoeschen.Text = "";
				ZelleGroesse = new TableCell();
				ZelleGroesse.Text = "";
				ZelleErzeugt = new TableCell();
				ZelleErzeugt.Text = "";
				ZelleVeraendert = new TableCell();
				ZelleVeraendert.Text = "";

				// f�ge die Zellen einer neuen Zeile hinzu
				Zeile.Cells.Add(ZelleIcon);
				Zeile.Cells.Add(ZelleLink);
				Zeile.Cells.Add(ZelleDownload);
				Zeile.Cells.Add(ZelleEdit);				
				Zeile.Cells.Add(ZelleLoeschen);
				Zeile.Cells.Add(ZelleGroesse);
				Zeile.Cells.Add(ZelleErzeugt);
				Zeile.Cells.Add(ZelleVeraendert);

				// und f�ge die Zeile der Tabelle hinzu, und zwar mit
				// dem Verzeichnisstyle
				Zeile.ApplyStyle(StyleVerzeichnisse);
				DateienUndVerzeichnisse.Rows.Add(Zeile);
			}

			// *********************************************************
			// In diesem Fall handelt es sich um Verzeichnisse
			// *********************************************************
			foreach(DirectoryInfo unterVerzeichnis in unterVerzeichnisse)
			{
				// erzeuge die ben�tigten Cellen und Controls
				Zeile = new TableRow();
				ZelleLink = new TableCell();
				Link = new HyperLink();
				ZelleIcon = new TableCell();
				DateiIcon = new System.Web.UI.WebControls.Image();
				ZelleGroesse = new TableCell();

				// f�ge den passenden Icon hinzu und zentriere ihn
				DateiIcon.ImageUrl = "./Bilder/Verzeichnis.gif";
				ZelleIcon.Controls.Add(DateiIcon);
				ZelleIcon.HorizontalAlign = HorizontalAlign.Center;

				// erzeuge den Link, welcher zum aktuellen Unterverzeichnis zeigt
				Link.Text = unterVerzeichnis.Name;
				Ort = VerzeichnisPfad;
				if (Ort.EndsWith("/"))
				{
					Ort += unterVerzeichnis.Name;
				}
				else
				{
					Ort += "/" + unterVerzeichnis.Name;
				}
				Link.NavigateUrl = "OFMS.aspx?Verzeichnis=" + Server.UrlEncode(Ort);
				Link.ApplyStyle(StyleLink);
				ZelleLink.Controls.Add(Link);

				// f�lle die Zelle mit der Groesse
				ZelleGroesse.Text = DateiGroesseFormat(VerzeichnisGroesse(unterVerzeichnis.FullName));
				ZelleGroesse.HorizontalAlign = HorizontalAlign.Right;

				// weiters werden die Dummyzellen
				// Download, Erzeugt und Ver�ndert leer
				// hinzugef�gt
				ZelleDownload = new TableCell();
				ZelleDownload.Text = "";
				ZelleEdit = new TableCell();
				ZelleEdit.Text = "";
				ZelleLoeschen = new TableCell();
				ZelleLoeschen.Text = "";
				ZelleErzeugt = new TableCell();
				ZelleErzeugt.Text = "";
				ZelleVeraendert = new TableCell();
				ZelleVeraendert.Text = "";

				// f�ge die Zellen einer neuen Zeile hinzu
				Zeile.Cells.Add(ZelleIcon);
				Zeile.Cells.Add(ZelleLink);
				Zeile.Cells.Add(ZelleDownload);
				Zeile.Cells.Add(ZelleEdit);
				Zeile.Cells.Add(ZelleLoeschen);
				Zeile.Cells.Add(ZelleGroesse);
				Zeile.Cells.Add(ZelleErzeugt);
				Zeile.Cells.Add(ZelleVeraendert);

				// f�ge die neue Zeile der Tabelle hinzu
				Zeile.ApplyStyle(StyleVerzeichnisse);
				DateienUndVerzeichnisse.Rows.Add(Zeile);
			}
			
			// *********************************************************
			// In diesem Fall handelt es sich um Dateien
			// *********************************************************
			foreach(FileInfo unterDatei in unterDateien)
			{
				// erzeuge die ben�tigten Cellen und Controls
				Zeile = new TableRow();
				ZelleLink = new TableCell();
				Link = new HyperLink();
				ZelleIcon = new TableCell();
				ZelleDownload = new TableCell();
				LinkDownload = new HyperLink();
				ZelleEdit = new TableCell();
				LinkEdit = new HyperLink();
				ZelleLoeschen = new TableCell();
				LinkLoeschen = new HyperLink();
				ZelleGroesse = new TableCell();
				ZelleErzeugt = new TableCell();
				ZelleVeraendert = new TableCell();
				DateiIcon = new System.Web.UI.WebControls.Image();

				// f�ge den passenden Icon hinzu und zentriere ihn
				DateiIcon.ImageUrl = "./Bilder/File.gif";
				ZelleIcon.Controls.Add(DateiIcon);
				ZelleIcon.HorizontalAlign = HorizontalAlign.Center;

				// erzeuge den Link, auf dieses File in einem neuen Fenster zeigt
				Link.Text = unterDatei.Name;
				Ort = VerzeichnisPfad;
				if (Ort.EndsWith("/"))
				{
					Ort += unterDatei.Name;
				}
				else
				{
					Ort += "/" + unterDatei.Name;
				}
				Link.NavigateUrl = Server.UrlEncode(Ort);
				Link.Target = "_blank";
				Link.ApplyStyle(StyleLink);
				ZelleLink.Controls.Add(Link);

				// erzeuge den Inhalt der Download-Zelle
				// als Image verwenden wir Download.gif
				// wir verweisen auf die Seite Download.aspx und �bergeben den
				// Parameter Dateiname mit dem Wert der Variable Ort
				// anschliessend f�gen wir den Hyperlink der Zelle hinzu
				LinkDownload.Text = "<img src=\"./Bilder/Download.gif\" border=\"0\" height=\"16\" width=\"16\" Alt=\"Datei herunterladen\">";
				LinkDownload.NavigateUrl = "Download.aspx?Dateiname=" + Server.UrlEncode(Ort);
				ZelleDownload.Controls.Add(LinkDownload);

				// erzeuge den Inhalt der Edit-Zelle
				// als Image verwenden wir Editor.gif
				// wir verweisen auf die Seite Editor.aspx und �bergeben den
				// Parameter Dateiname und erzeugen.
				LinkEdit.Text = "<img src=\"./Bilder/Editor.gif\" border=\"0\" height=\"16\" width=\"16\" Alt=\"Datei editieren\">";
				LinkEdit.NavigateUrl = "Editor.aspx?Dateiname=" + Server.UrlEncode(Ort);
				ZelleEdit.Controls.Add(LinkEdit);

				// erzeuge den Inhalt der Loeschen-Zelle
				// als Image verwenden wir Loeschen.gif
				LinkLoeschen.Text = "<img src=\"./Bilder/Loeschen.gif\" border=\"0\" height=\"16\" width=\"16\" Alt=\"Vorsicht: Datei l�schen!\">";
				LinkLoeschen.NavigateUrl = "Loeschen.aspx?Dateiname=" + Server.UrlEncode(Ort);
				ZelleLoeschen.Controls.Add(LinkLoeschen);

				// f�lle die Zelle mit der Groesse
				ZelleGroesse.Text = DateiGroesseFormat(unterDatei.Length);
				ZelleGroesse.HorizontalAlign = HorizontalAlign.Right;

				// f�lle die Zelle mit dem Erstellungsdatum und der letzten Ver�nderung
				// und richte sie nach rechts aus
				ZelleErzeugt.Text = String.Format("{0:dd.MM.yyyy hh:mm}", unterDatei.CreationTime);
				ZelleVeraendert.Text = String.Format("{0:dd.MM.yyyy hh:mm}", unterDatei.LastWriteTime);
				ZelleErzeugt.HorizontalAlign = HorizontalAlign.Right;
				ZelleVeraendert.HorizontalAlign = HorizontalAlign.Right;

				// f�ge die Zellen einer neuen Zeile hinzu
				Zeile.Cells.Add(ZelleIcon);
				Zeile.Cells.Add(ZelleLink);
				Zeile.Cells.Add(ZelleDownload);
				Zeile.Cells.Add(ZelleEdit);
				Zeile.Cells.Add(ZelleLoeschen);
				Zeile.Cells.Add(ZelleGroesse);
				Zeile.Cells.Add(ZelleErzeugt);
				Zeile.Cells.Add(ZelleVeraendert);

				// f�ge die neue Zeile der Tabelle hinzu
				Zeile.ApplyStyle(StyleDateien);
				DateienUndVerzeichnisse.Rows.Add(Zeile);
			}

		}


		protected long VerzeichnisGroesse(string Pfad)
		{
			// Hierbei handelt es sich um eine rekursive Prozedur
			// Es ist einfach, die Gr�sse aller Dateien eines
			// Verzeichnisses zusammenzuz�hlen (erstes foreach).
			// Beinhaltet ein Verzeichnis jedoch andere Verzeichnisse,
			// m�ssen wir zur Rekursion greifen. Im zweiten foreach
			// rufen wir f�r jedes Unterverzeichnis diese
			// Prozedur rekursiv auf. Somit k�nnen wir ohne viel
			// Aufwand Verzeichnisb�ume bis in beliebige Tiefe addieren.

			long Groesse = 0;
			DirectoryInfo VerzeichnisInfo = new DirectoryInfo(Pfad);

			foreach(FileInfo Datei in VerzeichnisInfo.GetFiles())
			{
				Groesse += Datei.Length;
			}

			foreach (DirectoryInfo Unterverzeichnis in VerzeichnisInfo.GetDirectories())
			{
				Groesse += VerzeichnisGroesse(Unterverzeichnis.FullName);
			}
			
			return Groesse;
			
		}


		protected string DateiGroesseFormat(long Groesse)
		{
			// als Wert f�r die Gr�sse einer Datei m�chten wir nicht immer Bytes angeben, da der 
			// Wert sonst zu sperrig werden kann. Wir entscheiden uns, den Wert je nach Gr�sse in 
			// Bytes, KiloBytes (k) und MegaBytes (MB) angzgeben.

			int Kilobyte = 1024;
			int Megabyte = 1024 * 1024;

			if (Groesse < Kilobyte)
			{
				// ohne Nachkommastellen und mit "Bytes"
				return String.Format("{0:N0} Bytes", Groesse);
			}
			else if (Groesse < Megabyte)
			{
				// mit 2 Nachkommastellen und mit "k"
				return String.Format("{0:N2} k", Groesse / Kilobyte);
			}
			else
			{
				// mit 2 Nachkommastellen und mit MB
				return String.Format("{0:N2} MB",Groesse / Megabyte);
			}

		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Upload.Click += new System.EventHandler(this.DateiUpload_Click);
			this.DateiNeu.Click += new System.EventHandler(this.DateiNeu_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void DateiUpload_Click(object sender, System.EventArgs e)
		{
			// es soll eine zuvor ausgew�hlte Datei hochgeladen werden
			// Dazu ben�tigen wir das aktuelle, virtuelle verzeichnis
			string aktuellesVerzeichnis = Request.Params["Verzeichnis"];
			if (aktuellesVerzeichnis == null || aktuellesVerzeichnis.Length == 0)
			{
				// Rootverzeichnis
				aktuellesVerzeichnis = Request.ApplicationPath.ToString();
			}
			// wenn eine Datei ausgew�hlt wurde ...
			if (DateiUpload.PostedFile != null && DateiUpload.PostedFile.FileName.Length > 0)
			{
				// bestimme das Zielverzeichnis ...
				string Zielverzeichnis = Server.MapPath(aktuellesVerzeichnis);

				try
				{
					// und den Dateiname, welcher anschliessend mit dem Zielverzeichnis
					// verschmolzen (Path.Combine) und gespeichert wird. Anschliessend
					// wird das aktuelle Verzeichnis angezeigt
					string Dateiname = Path.GetFileName(DateiUpload.PostedFile.FileName);
					DateiUpload.PostedFile.SaveAs(Path.Combine(Zielverzeichnis,Dateiname));
					Response.Redirect("OFMS.aspx?Verzeichnis=" + aktuellesVerzeichnis);
				}
				catch(Exception ex)
				{
					StatusMessage.Text = ex.Message;
					StatusMessage.Visible = true;
				}
			}

		}


		private void DateiNeu_Click(object sender, System.EventArgs e)
		{
			// Es wird eine neue Datei in aktuellen Verzeichnis erzeugt.
			// Wir entnehmen den Dateiname dem Input und das Verzeichnis
			// dem Querystring
         string Dateiname = DateiNameNeu.Text;
			string Verzeichnis = Request.Params["Verzeichnis"];
			
			// sollte das aktuelle Verzeichnis nicht im Querystring
			// definiert worden sein, handelt es sich um unser
			// Rootverzeichnis.
			if (Verzeichnis == null || Verzeichnis.Length == 0)
			{
				Verzeichnis = Request.ApplicationPath.ToString();
			}

			// nun erzeugen wir einen g�ltigen Dateinamen ...
			if (Dateiname != "" && Dateiname.Length > 0)
			{
				if (Verzeichnis.EndsWith("/"))
				{
					Dateiname = Verzeichnis + Dateiname;
				}
				else
				{
					Dateiname = Verzeichnis + "/" + Dateiname;
				}

				// und checken, ob er nicht schon existiert. Ansonsten
				// gen�gt uns ein Link auf die Editor.aspx Seite, mit dem
				// Parameter "erzeugen=true"
				if (File.Exists(Server.MapPath(Dateiname)))
				{
					StatusMessage.Text = "Datei bereits vorhanden!";
				}
				else
				{
					Response.Redirect("Editor.aspx?Dateiname=" + Dateiname + "&erzeugen=true");
				}
			}
			else
			{
				StatusMessage.Text = "Ung�ltiger Dateiname";
			}
		}
	}
}
