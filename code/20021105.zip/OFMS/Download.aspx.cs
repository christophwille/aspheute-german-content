using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace OFMS
{
	/// <summary>
	/// Summary description for Download.
	/// </summary>
	public class DownloadForm : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Die WebForm Download.aspx besitzt kein User Interface.
			// Beim Laden der Seite entnehmen wir als erstes den
			// Dateinamen (die zu l�schende Datei) dem Querystring. 
			string Dateiname = Server.MapPath(Request.Params["Dateiname"]);
			System.IO.FileInfo Datei = new System.IO.FileInfo(Dateiname);

			// Nun l�schen wir den Puffer ...
			Response.Clear();
			
			// f�gen den Header, welcher den Dateinamen f�r den "Speichern unter"-Dialog
			// spezifiziert, hinzu ...
			Response.AddHeader("Content-Disposition","attachment; filename=" + Datei.Name);
			
			// f�gen den Header, welcher die Dateigr��e bestimmt, hinzu. Somit kann
			// ein Download-Fortschritt angezeigt werden ...
			Response.AddHeader("Content-Length",Datei.Length.ToString());

			// und definieren, da� es sich um einen Stream handelt. Somit kann nicht
			// angesehen werden, sondern mu� downgeloadet werden.
			Response.ContentType = "application/octet-stream";

			// Nun versenden wir das File ...
			Response.WriteFile(Datei.FullName);

			// und stoppen die Ausf�hrung auf dieser Seite.
			Response.End();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ID = "DownloadForm";

		}
		#endregion
	}
}
