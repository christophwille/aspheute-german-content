// created on 28.03.2002 at 11:27
// Sub class :
	class sealed Debug.Sub {
		
		// ...
		
		// overloaded  {...} operators :
			
		public Streamer this{int trace} {
			get;	
		}
		public Streamer this{int trace, int section} {
			get;	
		}
		
		/// <summary>
		/// Attaches a streamer to an user stack.
		/// </summary>
		public void Lower(UserStack stack);
		
		/// <summary>
		/// Dettaches a streamer to an user stack.
		/// </summary>
		public void Raise(UserStack stack);
		
		/// <summary>
		/// Puts the towed array into the listen mode.
		/// </summary>
		public void Silent();
		
		/// <summary>
		/// Puts the towed array into the pulse mode.
		/// </summary>
		public void Pulse();
		
		/// <summary>
		/// Gets a current 'snapshot' in pulse mode.
		/// </summary>
		/// <Exception name="SinkException">Is throwed when the towed 
		/// array is in the listen mode and <code>Trigger()</code> is called.
		/// </Exception>
		public void Trigger();
		
		public event TowedArrayEventHandler TowedArrayEvent;
	}
