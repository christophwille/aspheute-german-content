using System;
using System.Diagnostics;

class OhioSample
{
	Debug.Sub myTowedArray;
	
	
	public void OhioSample()
	{
		myTowedArray = new Debug.Sub();
	}
	
	public void RunPulseSample()
	{
		// demonstrate pulse
		myTowedArray.Pulse();
		// attaches the towed array to the user stack
		myTowedArray.Lower(Debug.UserStack);
		for (int j = 0; j < 5; ++j) {
			// get 'snapshot'
			myTowedArray.Trigger();
			// shows the streamer as string data.
			for (int i = 0; i < myTowedArray.Length;++i) {
				Console.WriteLine(myTowedArray{i}.ToString()); 
			}
		}
		// detaches the towed array to the user stack
		myTowedArray.Raise(Debug.UserStack);
	}
	
	void TowedEventListener(object sender, TowedArrayEventArgs e)
	{
		Console.WriteLine("Tracked  call : " + e.TowedArray{e.RetrievedTrace}{e.RetrievedSection});
	}
	
	public void RunListenSample()
	{
		// demonstrate silent
		myTowedArray.Silent();
		myTowedArray.TowedArrayEvent += new TowedArrayEventHandler(TowedEventListener);
		
		// attaches the towed array to the user stack
		myTowedArray.Lower(Debug.UserStack);
		
		// track 10 Console.WriteLine calls
		for (int i = 0; i < 10;++i) {
			Console.WriteLine("I'm call " + i); 
		}
		
		// detaches the towed array to the user stack
		myTowedArray.Raise(Debug.UserStack);
	}
	
	public static void Main(string[] args)
	{
		OhioSample sample = new OhioSample();
		sample.RunPulseSample();
		sample.RunListenSample();
	}
}
