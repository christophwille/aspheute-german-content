using System;
using System.Net;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;

class MainClass
{
	public static void Main()
	{
		string strURL = "http://prognoza.hr/jadran_e.html";
		string strContent,strErrCode;
		DateTime dtGrabTime;
        bool bSuccess;
        
        ScrapPage MyScrapPage = new ScrapPage();
        MyScrapPage.ScrapIt(strURL, out strContent, out strErrCode,out dtGrabTime);
        
        if("" == strErrCode)
        {
            bSuccess = true;
        }
        else
        {
            bSuccess = false;
        }
        
        Write2DB MyWrite2DB = new Write2DB();
        MyWrite2DB.WriteIt(dtGrabTime, bSuccess, strContent,strErrCode);
        
	}
}

class ScrapPage
{
	public void ScrapIt(string strUrl, out string strContent, out string strErrCode,out DateTime dtGrabTime)
	{
        strErrCode ="";
        WebRequest WebReq = WebRequest.Create(strUrl);
      	WebResponse WebResp = WebReq.GetResponse();
    	StringBuilder strBuildContent = new StringBuilder(); 
		dtGrabTime = DateTime.Now;
		
      	try
        {
            StreamReader MyStrmR = new StreamReader(WebResp.GetResponseStream(), Encoding.UTF8);
             
            
                      
          	while (-1 != MyStrmR.Peek())
          	{
                strBuildContent.Append(MyStrmR.ReadLine());
          	}
        }
        catch (Exception e)
        {
        strErrCode = e.ToString();
        }
      	strContent = strBuildContent.ToString();
	}
}

class Write2DB
{
    public void WriteIt(DateTime dtGrabTime, bool bSuccess,string strContent,string strErrCode)
    {

string strConn ="Data Source=WEBDEVSRV01;Initial Catalog=ScrapApp;user id=sa;password=";
    string insertCmd = "insert into tContent (GrabTime, Success, Content, ErrCode) values (@GrabTime,@Success,@Content,@ErrCode)";
    
    SqlConnection MySqlConnection = new SqlConnection(strConn);
    SqlCommand MyCmd = new SqlCommand(insertCmd, MySqlConnection);

	MyCmd.Parameters.Add(new SqlParameter("@GrabTime", SqlDbType.DateTime, 8));
    MyCmd.Parameters["@GrabTime"].Value = dtGrabTime;
	MyCmd.Parameters.Add(new SqlParameter("@Success", SqlDbType.Bit, 1));
    MyCmd.Parameters["@Success"].Value = bSuccess;
	MyCmd.Parameters.Add(new SqlParameter("@Content", SqlDbType.NVarChar,4000));
    MyCmd.Parameters["@Content"].Value = strContent;
  	MyCmd.Parameters.Add(new SqlParameter("@ErrCode", SqlDbType.NVarChar, 255));
    MyCmd.Parameters["@ErrCode"].Value = strErrCode;
    MyCmd.Connection.Open();
    MyCmd.ExecuteNonQuery();
    MyCmd.Connection.Close();
    }
}
