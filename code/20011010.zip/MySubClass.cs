using System;
using InheritanceSamples;

public class MySubClass : MyBaseClass
{
	public override string SayHello()
	{
		return "Hello World from C#";
	}

	public long Compute()
	{
		return InternalAdd(3, 8);
	}
}

public class App
{
  static void Main()
  {
    MySubClass objSubClass = new MySubClass();
    Console.WriteLine(objSubClass.SayHello());
    Console.WriteLine(objSubClass.Add(5, 10));
    Console.WriteLine(objSubClass.Compute());

    MyBaseClass objBaseClass = new MyBaseClass();
    Console.WriteLine(objBaseClass.SayHello());
  }
}
