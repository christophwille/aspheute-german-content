Imports System

Namespace InheritanceSamples

Public Class MyBaseClass
	Public Overridable Function SayHello() As String
		Return "Hello World from VB"
	End Function

	Public Function Add(nA As Long, nB As Long) As Long
		Return (nA+nB)
	End Function

	Protected Function InternalAdd(nA As Long, nB As Long) As Long
		Return (nA+nB)
	End Function
End Class

End Namespace