using System;
using System.Drawing;

namespace AspHeute.ThumbsUp
{
	/// <summary>
	/// TODO - Add class summary
	/// </summary>
	/// <remarks>
	/// 	created by - Christoph Wille
	/// 	created on - 2/24/2002 12:10:19 PM
	/// </remarks>
	public class Thumbnail
	{
		/// <summary>
		/// Default constructor - initializes all fields to default values
		/// </summary>
		public Thumbnail()
		{
		}
		
		/// <summary>
		/// Callback method - not used in .NET 1.0, so default is clearly not to abort
		/// </summary>		
		public bool AbortThumbnailGeneration()
		{
			return false;
		}
		
		/// <summary>
		/// Pass file name, maintain aspect in scaling
		/// </summary>			
		public Image GetThumbnail(string strFilename, int nScalePercentage)
		{
			Image img2Scale = Image.FromFile(strFilename);
			Image imgThumb = GetThumbnail(img2Scale, nScalePercentage);
			img2Scale.Dispose();	// cleanup
			return imgThumb;
		}
		
		/// <summary>
		/// Filename, width and height are passed.
		/// </summary>			
		public Image GetThumbnail(string strFilename, int nWidth, int nHeight)
		{
			Image img2Scale = Image.FromFile(strFilename);
			Image imgThumb = GetThumbnail(img2Scale, nWidth, nHeight);
			img2Scale.Dispose();	// cleanup
			return imgThumb;
		}
		
		/// <summary>
		/// Image passed, as well as scaling percentage
		/// </summary>			
		public Image GetThumbnail(Image imgFullSize, int nScalePercentage)
		{
			if (nScalePercentage < 1 || nScalePercentage > 99)
				throw new ArgumentException("Scale percentage must be between 1 and 99");
			
			int nImageWidth = imgFullSize.Width;
			int nImageHeight = imgFullSize.Height;
			nImageWidth = (int)((double)nImageWidth * ((double)nScalePercentage/100.0));
			nImageHeight = (int)((double)nImageHeight * ((double)nScalePercentage/100.0));
			return GetThumbnail(imgFullSize, nImageWidth, nImageHeight);
		}
		
		/// <summary>
		/// This method does all the work in the end
		/// </summary>			
		public Image GetThumbnail(Image imgFullSize, int nWidth, int nHeight)
		{
			Image.GetThumbnailImageAbort cb = new Image.GetThumbnailImageAbort(AbortThumbnailGeneration);
			return imgFullSize.GetThumbnailImage(nWidth, nHeight, cb, IntPtr.Zero);
		}
		
		/// <summary>
		/// Get a thumbnail with one side set in pixel: width = false, height = true
		/// </summary>	
		public Image GetThumbnail(string strFilename, int nPixelSize, bool bPortrait)
		{
			Image img2Scale = Image.FromFile(strFilename);
			Image imgThumb = GetThumbnail(img2Scale, nPixelSize, bPortrait);
			img2Scale.Dispose();	// cleanup
			return imgThumb;			
		}
		
		/// <summary>
		/// Get a thumbnail with one side set in pixel: width = false, height = true
		/// </summary>	
		public Image GetThumbnail(Image imgFullSize, int nPixelSize, bool bPortrait)
		{
			int nImageWidth = imgFullSize.Width;
			int nImageHeight = imgFullSize.Height;
			int nScalePercentage = 0;
			if (bPortrait)
			{
				nScalePercentage = (int)(nPixelSize * 100.0 / (double)nImageHeight);
				nImageWidth = (int)((double)nImageWidth * ((double)nScalePercentage/100.0));
				nImageHeight = nPixelSize;
			}
			else
			{
				nScalePercentage = (int)(nPixelSize * 100.0 / (double)nImageWidth);	
				nImageHeight = (int)((double)nImageHeight * ((double)nScalePercentage/100.0));
				nImageWidth = nPixelSize;
			}
			return GetThumbnail(imgFullSize, nImageWidth, nImageHeight);
		}
	}
}
