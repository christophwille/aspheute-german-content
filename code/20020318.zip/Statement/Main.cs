using System;
using System.Net;

namespace Statement
{
	class MainApp
	{
		[STAThread]
		static void Main(string[] args)
		{
			WebRequest wrq = WebRequest.Create("http://www.aspheute.com/");
			using (WebResponse response = wrq.GetResponse())
			{
				// exception or not, response will always be disposed
			}
		}
	}
}
