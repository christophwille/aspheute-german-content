using System;
using NsOne = AspHeute.NamespaceOne;
using NsTwo = AspHeute.NamespaceTwo;

namespace Directive
{
	class MainApp
	{
		[STAThread]
		static void Main(string[] args)
		{
			NsOne.DemoClass oOne= new NsOne.DemoClass();
			oOne.SayHello();
			NsTwo.DemoClass oTwo= new NsTwo.DemoClass();
			oTwo.SayHello();
		}
	}
}

namespace AspHeute.NamespaceOne
{
	class DemoClass
	{
		public void SayHello()
		{
			Console.WriteLine("Hello, world! (A.O.D)");
		}
	}
}

namespace AspHeute.NamespaceTwo
{
	class DemoClass
	{
		public void SayHello()
		{
			Console.WriteLine("Hello, world! (A.T.D)");
		}
	}
}