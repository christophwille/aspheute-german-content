using System;
using DcOne = AspHeute.NamespaceOne.DemoClass;
using DcTwo = AspHeute.NamespaceTwo.DemoClass;

namespace Directive
{
	class MainApp
	{
		[STAThread]
		static void Main(string[] args)
		{
			DcOne oOne= new DcOne();
			oOne.SayHello();
			DcTwo oTwo= new DcTwo();
			oTwo.SayHello();
		}
	}
}

namespace AspHeute.NamespaceOne
{
	class DemoClass
	{
		public void SayHello()
		{
			Console.WriteLine("Hello, world! (A.O.D)");
		}
	}
}

namespace AspHeute.NamespaceTwo
{
	class DemoClass
	{
		public void SayHello()
		{
			Console.WriteLine("Hello, world! (A.T.D)");
		}
	}
}