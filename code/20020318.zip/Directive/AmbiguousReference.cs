using System;
using AspHeute.NamespaceOne;
using AspHeute.NamespaceTwo;

namespace Directive
{
	class MainApp
	{
		[STAThread]
		static void Main(string[] args)
		{
			// no using statements
			AspHeute.NamespaceOne.DemoClass oOne= new AspHeute.NamespaceOne.DemoClass();
			oOne.SayHello();
			AspHeute.NamespaceTwo.DemoClass oTwo= new AspHeute.NamespaceTwo.DemoClass();
			oTwo.SayHello();
			// no way with two namespaces that hold same class
			// error CS0104: 'DemoClass' is an ambiguous reference
			DemoClass oDemo = new DemoClass();
		}
	}
}

namespace AspHeute.NamespaceOne
{
	class DemoClass
	{
		public void SayHello()
		{
			Console.WriteLine("Hello, world! (A.O.D)");
		}
	}
}

namespace AspHeute.NamespaceTwo
{
	class DemoClass
	{
		public void SayHello()
		{
			Console.WriteLine("Hello, world! (A.T.D)");
		}
	}
}