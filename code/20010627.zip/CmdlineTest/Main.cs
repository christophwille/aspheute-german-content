// project created on 6/24/2001 at 6:59 PM
using System;
using System.Net;
using SimpleStateProxy;

class MainClass
{
	public static void Main(string[] args)
	{
		SimpleState state = new SimpleState();
		CookieContainer cc = new CookieContainer();
		state.CookieContainer = cc;
		
		state.MethodA("That is a simple test!");
		Console.WriteLine(state.MethodB());
	}
}
