using System;
using System.IO;

using System.Reflection;
using System.Text.RegularExpressions;

class MainClass
{
	public static void Main(string[] args)
	{
		// http://regexlib.com/REDetails.aspx?regexp_id=26
		string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
		
		// http://regexlib.com/REDetails.aspx?regexp_id=72
		// string strRegex = @"^(([^<>;()[\]\\.,;:@""]+(\.[^<>()[\]\\.,;:@""]+)*)|("".+""))@((([a-z]([-a-z0-9]*[a-z0-9])?)|(#[0-9]+)|(\[((([01]?[0-9]{0,2})|(2(([0-4][0-9])|(5[0-5]))))\.){3}(([01]?[0-9]{0,2})|(2(([0-4][0-9])|(5[0-5]))))\]))\.)*(([a-z]([-a-z0-9]*[a-z0-9])?)|(#[0-9]+)|(\[((([01]?[0-9]{0,2})|(2(([0-4][0-9])|(5[0-5]))))\.){3}(([01]?[0-9]{0,2})|(2(([0-4][0-9])|(5[0-5]))))\]))$";
		                                                                                        
		// zwar unnotwendig, aber man sollte checken, ob die RegEx überhaupt 
		// funktioniert bevor man kompiliert
		try
		{
			Regex re = new Regex(strRegex);
		}
		catch (ArgumentException ae)
		{
			Console.WriteLine("Regex creation error, reason: " + ae.Message);
			return;
		}
		
		RegexCompilationInfo  rci = new RegexCompilationInfo(strRegex,
			RegexOptions.Compiled, 
			"EmailValidationRegEx",  // Class name
			"DotNetHeute",           // Namespace
			true);                   // is public
		
		AssemblyName asmName = new AssemblyName();
		asmName.Name = "emailregex";

		RegexCompilationInfo[] rciArray = new RegexCompilationInfo[] { rci };
		
		try
		{
			Regex.CompileToAssembly(rciArray, asmName);
		}
		catch (ArgumentException ae)
		{
			Console.WriteLine("Error in compilation: " + ae.Message);
			return;
		}
		
		Console.WriteLine("emailregex.dll erfolgreich erzeugt");
	}
}
