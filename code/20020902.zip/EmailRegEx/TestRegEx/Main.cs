using System;
using DotNetHeute;

using System.Collections.Specialized;
using System.Text.RegularExpressions;

class MainClass
{
	public static void Main(string[] args)
	{
		EmailValidationRegEx re = new EmailValidationRegEx();
		
		StringCollection email2Validate = new StringCollection();
		email2Validate.Add("christophw@alphasierrapapa.com");
		email2Validate.Add("christophw@192.168.1.100");
		email2Validate.Add("christophw@com");
		email2Validate.Add("christophw@com.info");
		
		foreach(string strAddress2Validate in email2Validate) 
		{
			if (re.IsMatch(strAddress2Validate)) 
			{
				Console.WriteLine(strAddress2Validate + " *OK*");
			}
			else
			{
				Console.WriteLine(strAddress2Validate + " no email address");
			}
		}
		
	}
}
