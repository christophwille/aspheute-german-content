if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tMeta]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tMeta]
GO

CREATE TABLE [dbo].[tMeta] (
	[AutoID] [int] IDENTITY (1, 1) NOT NULL ,
	[fString] [varchar] (50) NULL ,
	[fDocument] [varchar] (100) NULL ,
	[fValue] [text] NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[tMeta] WITH NOCHECK ADD 
	CONSTRAINT [PK_tMeta] PRIMARY KEY  CLUSTERED 
	(
		[AutoID]
	)  ON [PRIMARY] 
GO

