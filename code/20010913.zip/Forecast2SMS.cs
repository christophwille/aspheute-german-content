using System;
using System.Net;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Collections;

class MainClass
{
	
	public static void Main(string[] args)
	{		
	string strTelNoTo ="PhoneNumber";
	string strUsername ="Username";
	string strPassword ="Password";
		
	SendWeatherData MySendWeatherData = new SendWeatherData();
	MySendWeatherData.Send(strUsername, strPassword, strTelNoTo);
	}
}

class SendWeatherData
{

	public void GetLatestWeatherReport(out string strRetData)
	{
	string strConn = "server=(local)\\NetSDK;database=ScrapAppImproved;Trusted_Connection=yes"; 
	string strSql =  "SELECT TOP 1 Title, Heading1, Heading2, Heading3, Heading4 FROM tContent WHERE Success=1 ORDER BY ForecastTimestamp DESC";
		
	SqlConnection RetrSqlConn = new SqlConnection(strConn);
	SqlCommand RetrSqlCmd = new SqlCommand(strSql, RetrSqlConn);  

  	RetrSqlConn.Open();
        SqlDataReader MySqlReader = RetrSqlCmd.ExecuteReader();
  
        MySqlReader.Read();
	strRetData = MySqlReader["Title"].ToString();
	strRetData += MySqlReader["Heading1"].ToString();
	strRetData += MySqlReader["Heading2"].ToString();
	strRetData += MySqlReader["Heading3"].ToString();
	strRetData += MySqlReader["Heading4"].ToString();
  	MySqlReader.Close(); 
  	RetrSqlConn.Close();
	}
	
	public void Send(string strUsername, string strPassword, string strTelNoTo)
	{
	int nSMSDataIdx =0;
	int nMaxLength;
	ArrayList arSMSData = new ArrayList();
	string strResponse, strRetData;
	SMSGateway SendSMS = new SMSGateway();
	SendSMS.Username = strUsername;
	SendSMS.Password = strPassword;
		
	GetLatestWeatherReport(out strRetData);
		
	if ("" != strRetData)
	{
		nMaxLength = strRetData.Length;
		for(int i=0;i < nMaxLength-157;i+=157)
		{
			arSMSData[nSMSDataIdx] = nSMSDataIdx.ToString() + " " + strRetData.Substring(i,157);
			nSMSDataIdx++;
		}
		
		for(int j=0;j < nSMSDataIdx;j++)
		{
			bool bResult = 	SendSMS.SendMessage(arSMSData[j].ToString(), 
		                               strTelNoTo, out strResponse);
		       
		    Console.WriteLine(arSMSData[j].ToString()+ "; Status " + bResult+ "\n\n");
		}
	
	}
	else
	{
		Console.WriteLine("No Data To Send");
	}
	
	}
	
}
class SMSGateway
{
	public string Username;
	public string Password;
		
	public bool SendMessage(string strMessage, string strTelNoTo, out string strResponse)
	{
	string strQuery, strPage;
			
	strQuery = "N=" + HttpUtility.UrlEncode(strTelNoTo) + "&UID=" + 
	HttpUtility.UrlEncode(Username) + "&PW=" + 
	HttpUtility.UrlEncode(Password) + "&M=|*UTF8|" + 
	HttpUtility.UrlEncode(strMessage);
			
	strPage = "http://clients.sms-wap.com/cgi/csend.cgi";

	try
        {
		WebRequest wrq = WebRequest.Create(strPage);
	 	wrq.Method = "POST";
	 	wrq.ContentType = "application/x-www-form-urlencoded";
			 	
	 	byte[] bPayload = Encoding.UTF8.GetBytes(strQuery.ToString());
	 	wrq.ContentLength = bPayload.Length;
	 	Stream reqStream = wrq.GetRequestStream();
		reqStream.Write(bPayload, 0, bPayload.Length);
		reqStream.Close();
			 	
	  	WebResponse wrp = wrq.GetResponse();
			
		StreamReader sr = new StreamReader(wrp.GetResponseStream(), Encoding.UTF8);
		StringBuilder strBuildContent = new StringBuilder();
	
  		while (-1 != sr.Peek())
		    strBuildContent.Append(sr.ReadLine());
	
	        strResponse = strBuildContent.ToString();
		
		if ("01" == strResponse) return true;
		 }
		
	 catch(Exception e)
	 {
	  	strResponse = e.ToString();
	  	return false;
	 }		
		return false;
   	 }
}
