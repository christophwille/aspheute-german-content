// project created on 9/10/2001 at 8:35 PM
using System;
using System.Text;
using System.Web;
using System.Net;
using System.IO;

	class MainClass
	{
	  public static void Main(string[] args)
	  {
		SMSGateway mySMS = new SMSGateway();
		mySMS.Username = "username_here";
		mySMS.Password = "password_here";
		
		string strResponse;
		bool bResult = mySMS.SendMessage("Melcome Sir Walcom [Water]", 
		                                 "4369929675231", 
		                                 out strResponse);
		Console.WriteLine("Sending SMS, status: {0}, response: {1}", bResult, strResponse);
	  }
	}

	class SMSGateway
	{
		public string Username;
		public string Password;
		
		public bool SendMessage(string strMessage, string strTelNoTo, out string strResponse)
		{
			string strQuery, strPage;
			
			strQuery = "N=" + HttpUtility.UrlEncode(strTelNoTo) + "&UID=" + 
				HttpUtility.UrlEncode(Username) + "&PW=" + 
				HttpUtility.UrlEncode(Password) + "&M=|*UTF8|" + 
				HttpUtility.UrlEncode(strMessage);
			
			strPage = "http://clients.sms-wap.com/cgi/csend.cgi";

			try
			 {
			 	WebRequest wrq = WebRequest.Create(strPage);
			 	wrq.Method = "POST";
			 	wrq.ContentType = "application/x-www-form-urlencoded";
			 	
			 	byte[] bPayload = Encoding.UTF8.GetBytes(strQuery.ToString());
			 	wrq.ContentLength = bPayload.Length;
			 	Stream reqStream = wrq.GetRequestStream();
				reqStream.Write(bPayload, 0, bPayload.Length);
				reqStream.Close();
			 	
			  	WebResponse wrp = wrq.GetResponse();
			
				StreamReader sr = new StreamReader(wrp.GetResponseStream(), Encoding.UTF8);
				StringBuilder strBuildContent = new StringBuilder();
				while (-1 != sr.Peek())
				    strBuildContent.Append(sr.ReadLine());
	
				strResponse = strBuildContent.ToString();
			 	if ("01" == strResponse) return true;
			 }
			 catch(Exception e)
			 {
			  	strResponse = e.ToString();
			  	return false;
			 }
			
			return false;
		}
	}

