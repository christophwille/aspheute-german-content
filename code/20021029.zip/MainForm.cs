using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Amazon.WebServices;
using System.Net;

namespace BookSearch
{
	/// <summary>
	/// Summary description for BookSearchForm.
	/// </summary>
	public class BookSearchForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.TextBox txtToken;
		private System.Windows.Forms.Label lblToken;
		private System.Windows.Forms.TextBox txtKeyword;
		private System.Windows.Forms.Label lblKeyword;
		private System.Windows.Forms.ListView lvFoundItems;
		private System.Windows.Forms.ColumnHeader colURL;
		private System.Windows.Forms.ColumnHeader colASIN;
		private System.Windows.Forms.ColumnHeader colProductName;
		private System.Windows.Forms.Label labelTotalRecords;
		private System.Windows.Forms.PictureBox picbox;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public BookSearchForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnSearch = new System.Windows.Forms.Button();
			this.txtToken = new System.Windows.Forms.TextBox();
			this.lblToken = new System.Windows.Forms.Label();
			this.txtKeyword = new System.Windows.Forms.TextBox();
			this.lblKeyword = new System.Windows.Forms.Label();
			this.lvFoundItems = new System.Windows.Forms.ListView();
			this.colURL = new System.Windows.Forms.ColumnHeader();
			this.colASIN = new System.Windows.Forms.ColumnHeader();
			this.colProductName = new System.Windows.Forms.ColumnHeader();
			this.labelTotalRecords = new System.Windows.Forms.Label();
			this.picbox = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// btnSearch
			// 
			this.btnSearch.Location = new System.Drawing.Point(248, 48);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new System.Drawing.Size(88, 24);
			this.btnSearch.TabIndex = 0;
			this.btnSearch.Text = "Search!";
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			// 
			// txtToken
			// 
			this.txtToken.Location = new System.Drawing.Point(72, 16);
			this.txtToken.Name = "txtToken";
			this.txtToken.Size = new System.Drawing.Size(160, 20);
			this.txtToken.TabIndex = 1;
			this.txtToken.Text = "xxxxxx";
			// 
			// lblToken
			// 
			this.lblToken.Location = new System.Drawing.Point(8, 16);
			this.lblToken.Name = "lblToken";
			this.lblToken.Size = new System.Drawing.Size(64, 16);
			this.lblToken.TabIndex = 2;
			this.lblToken.Text = "Token";
			// 
			// txtKeyword
			// 
			this.txtKeyword.Location = new System.Drawing.Point(72, 48);
			this.txtKeyword.Name = "txtKeyword";
			this.txtKeyword.Size = new System.Drawing.Size(160, 20);
			this.txtKeyword.TabIndex = 3;
			this.txtKeyword.Text = "keyword";
			// 
			// lblKeyword
			// 
			this.lblKeyword.Location = new System.Drawing.Point(8, 48);
			this.lblKeyword.Name = "lblKeyword";
			this.lblKeyword.Size = new System.Drawing.Size(56, 24);
			this.lblKeyword.TabIndex = 4;
			this.lblKeyword.Text = "Keyword";
			// 
			// lvFoundItems
			// 
			this.lvFoundItems.Activation = System.Windows.Forms.ItemActivation.OneClick;
			this.lvFoundItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						   this.colURL,
																						   this.colASIN,
																						   this.colProductName});
			this.lvFoundItems.FullRowSelect = true;
			this.lvFoundItems.GridLines = true;
			this.lvFoundItems.Location = new System.Drawing.Point(8, 88);
			this.lvFoundItems.Name = "lvFoundItems";
			this.lvFoundItems.Size = new System.Drawing.Size(536, 168);
			this.lvFoundItems.TabIndex = 5;
			this.lvFoundItems.View = System.Windows.Forms.View.Details;
			this.lvFoundItems.ItemActivate += new System.EventHandler(this.lvFoundItems_ItemActivate);
			// 
			// colURL
			// 
			this.colURL.Text = "URL";
			this.colURL.Width = 80;
			// 
			// colASIN
			// 
			this.colASIN.Text = "ASIN";
			this.colASIN.Width = 80;
			// 
			// colProductName
			// 
			this.colProductName.Text = "Product Name";
			this.colProductName.Width = 350;
			// 
			// labelTotalRecords
			// 
			this.labelTotalRecords.Location = new System.Drawing.Point(248, 16);
			this.labelTotalRecords.Name = "labelTotalRecords";
			this.labelTotalRecords.Size = new System.Drawing.Size(288, 23);
			this.labelTotalRecords.TabIndex = 6;
			this.labelTotalRecords.Text = "total records";
			// 
			// picbox
			// 
			this.picbox.Location = new System.Drawing.Point(8, 264);
			this.picbox.Name = "picbox";
			this.picbox.Size = new System.Drawing.Size(296, 264);
			this.picbox.TabIndex = 7;
			this.picbox.TabStop = false;
			// 
			// BookSearchForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(552, 533);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.picbox,
																		  this.labelTotalRecords,
																		  this.lvFoundItems,
																		  this.lblKeyword,
																		  this.txtKeyword,
																		  this.lblToken,
																		  this.txtToken,
																		  this.btnSearch});
			this.Name = "BookSearchForm";
			this.Text = "Search for book";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new BookSearchForm());
		}

		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			AmazonSearchService searchService = new AmazonSearchService();

			KeywordRequest keywordReq = new KeywordRequest();
			keywordReq.devtag = txtToken.Text;
			keywordReq.keyword = txtKeyword.Text;
			keywordReq.type = "lite";
			keywordReq.sort = "+salesrank";
			keywordReq.mode = "books";
			keywordReq.tag = "alphasierrapapa";

			ProductInfo pi = searchService.KeywordSearchRequest(keywordReq);

			lvFoundItems.BeginUpdate();
			lvFoundItems.Items.Clear();
			labelTotalRecords.Text = "Total records: " + pi.TotalResults.ToString();

			for (int i=0;i < pi.Details.Length; i++)
			{
				ListViewItem lvi = new ListViewItem();
				lvi.Text = pi.Details[i].Url;
				lvi.SubItems.Add(pi.Details[i].Asin);
				lvi.SubItems.Add(pi.Details[i].ProductName);
				lvi.SubItems.Add(pi.Details[i].ImageUrlMedium);
				lvFoundItems.Items.Add(lvi);
			}

			lvFoundItems.EndUpdate();
		}

		private void lvFoundItems_ItemActivate(object sender, System.EventArgs e)
		{
			if (lvFoundItems.SelectedItems.Count == 0) return;
			ListViewItem lvi = lvFoundItems.SelectedItems[0];
			string strImageUrl = lvi.SubItems[3].Text;
			if ("" == strImageUrl) return;

			WebRequest wrq = WebRequest.Create(strImageUrl);
			WebResponse wrp = wrq.GetResponse();

			Bitmap bmp = new Bitmap(wrp.GetResponseStream());
			picbox.Image = bmp;
			picbox.Refresh();
		}
	}
}
