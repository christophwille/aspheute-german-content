// Christoph Wille, christophw@alphasierrapapa.com
// 22.01.2001
// conversion rates from http://europa.eu.int/euro/html/home5.html?lang=5

using System;
using System.Collections;

namespace AlphaSierraPapa.Utilities
{
public class EuroConverter
{
  protected Hashtable m_MapCurrencySymbol2Factor;
  
  public EuroConverter()
  {
    m_MapCurrencySymbol2Factor = new Hashtable();
    m_MapCurrencySymbol2Factor.Add("ATS", 13.7603);	// Austria
	m_MapCurrencySymbol2Factor.Add("BEF", 40.3399);	// Belgium
	m_MapCurrencySymbol2Factor.Add("LUF", 40.3399);	// Luxemburg
	m_MapCurrencySymbol2Factor.Add("FIM", 5.94573);	// Finland
	m_MapCurrencySymbol2Factor.Add("FRF", 6.55957);	// France
	m_MapCurrencySymbol2Factor.Add("DEM", 1.95583);	// Germany
	m_MapCurrencySymbol2Factor.Add("IEP", 0.787564);   // Ireland
	m_MapCurrencySymbol2Factor.Add("ITL", 1936.27);	// Italy
	m_MapCurrencySymbol2Factor.Add("NLG", 2.20371);	// Netherlands
	m_MapCurrencySymbol2Factor.Add("PTE", 200.482);	// Portugal
	m_MapCurrencySymbol2Factor.Add("ESP", 166.386);	// Spain
	m_MapCurrencySymbol2Factor.Add("GRD", 340.750);	// Greece
  }
  
  public double GetExchangeRate(String strCurrencySymbol)
  {
  	if (m_MapCurrencySymbol2Factor.ContainsKey(strCurrencySymbol))
  	{
  		return (double)m_MapCurrencySymbol2Factor[strCurrencySymbol];
  	}
  	
  	throw new ArgumentException("Currency not defined!");
  	return -1;	// unreachable code; intentionally
  }
  
  public double ConvertToEuro(double dVal2Convert, string strCurrencyFrom) 
  {
	if (!m_MapCurrencySymbol2Factor.ContainsKey(strCurrencyFrom))
	{
		throw new ArgumentException("Lookup of currency symbol failed!");
	}
	
	double dRate = (double)m_MapCurrencySymbol2Factor[strCurrencyFrom];
	return Round((dVal2Convert / dRate));
  } 

  public double ConvertFromEuro(double dVal2Convert, string strCurrencyTo) 
  {
    if (!m_MapCurrencySymbol2Factor.ContainsKey(strCurrencyTo))
	{
		throw new ArgumentException("Lookup of currency symbol failed!");
	}
	
	double dRate = (double)m_MapCurrencySymbol2Factor[strCurrencyTo];
	return Round((dVal2Convert * dRate));
  }

  public double Triangulate(double dVal2Convert, string strCurrencyFrom, string strCurrencyTo) 
  {
	if (!m_MapCurrencySymbol2Factor.ContainsKey(strCurrencyFrom) ||
		!m_MapCurrencySymbol2Factor.ContainsKey(strCurrencyTo))
	{
		throw new ArgumentException("Lookup of currency symbol failed!");
	}

	double dRateFrom =(double)m_MapCurrencySymbol2Factor[strCurrencyFrom];
	double dRateTo = (double)m_MapCurrencySymbol2Factor[strCurrencyTo];
	
	// do the conversion
	double dHelper = dVal2Convert / dRateFrom;
	dHelper *= dRateTo;

	return Round(dHelper);
  }
  	
  // our EMU compliant rounding function
  protected double Round(double dVal2Round)
  {
	// first, strip off everything after third decimal
	double dVal2 = 0.0;
	dVal2Round *= 1000;
	dVal2 = Fix(dVal2Round);

	// now, round the result
	dVal2 /= 10;
    dVal2Round = Fix(dVal2 + (dVal2 > 0 ? 0.5 : -0.5));
	
	// we are done.
	return (dVal2Round/100);
  }
  
  protected double Fix(double dVarIn)
  {
  	if (Math.Sign(dVarIn) < 0)
  	{
  		// less than 0, negative values
  		return Math.Ceiling(dVarIn);
  	}
  	else
  	{
  		return Math.Floor(dVarIn);
  	}
  	return -1;	// unreachable code; intentionally
  }
}
}	// end of namespace AlphaSierraPapa.Utilities
