using System;
using System.Collections;

/// <summary>Implements ascending sort algorithm</summary>
public class AscendingComparer : IComparer
{
	public int Compare(object objA, object objB)
	{
		return String.Compare(objA.ToString(), objB.ToString());
	}
}

/// <summary>Implements descending sort algorithm</summary>
public class DescendingComparer : IComparer
{
	public int Compare(object objA, object objB)
	{
		return String.Compare(objB.ToString(), objA.ToString());
	}
}

/// <summary>Sample application implementing the comparers</summary>
class ComparerSampleMain
{
	public static void Main(string[] args)
	{
		// fill a sample array list
		ArrayList al = new ArrayList();
		ComparerSampleMain.FillArrayList(ref al);

		// print the unsorted list
		Console.WriteLine("-- Unsorted --");
		foreach(string strCurrent in al) {
			Console.WriteLine(strCurrent);
		}

		// sort ascending, then print
		al.Sort(new AscendingComparer());
		Console.WriteLine("\r\n-- Sorted ascending --");
		for (int i=0; i < al.Count; i++) {
			Console.WriteLine(al[i]); 
		}

		// finally, sort descending, then print
		al.Sort(new DescendingComparer());
		Console.WriteLine("\r\n-- Sorted descending --");
		foreach(string strCurrent in al) {
			Console.WriteLine(strCurrent);
		}
	}
	
	public static void FillArrayList(ref ArrayList al)
	{
		al.Add("C#");
		al.Add("VB.NET");
		al.Add("JScript.NET");
		al.Add("SharpDevelop");
		al.Add("Visual Studio.NET");
		al.Add(".NET Framework SDK");
	}
}
