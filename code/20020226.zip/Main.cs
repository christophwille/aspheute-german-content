using System;
using System.IO;
using System.Text;

class MainClass
{
	public static void Main(string[] args)
	{
		string strDir2Touch = Directory.GetCurrentDirectory();
		Touch myTouch = new Touch();
		myTouch.TouchDirectory(strDir2Touch);
		Console.WriteLine(myTouch.Errors);
	}
}

class Touch
{
	protected DateTime m_Touch2CurrentTime;
	protected StringBuilder m_strExceptionStack;
	
	public string Errors
	{
		get { return m_strExceptionStack.ToString(); }
	}
	
	public Touch()
	{
		m_Touch2CurrentTime = DateTime.Now;
		m_strExceptionStack = new StringBuilder();
	}
	
	public void TouchDirectory(string strDirectory)
	{
	  	DirectoryInfo diThis = null;
		diThis = new DirectoryInfo(strDirectory);
		
		DirectoryInfo[] subDirectories = diThis.GetDirectories();

		for (int i=0; i < subDirectories.Length; i++)
  		{
  		  // only the time setting is done in an exception block
  		  try
  		  {
  		  	subDirectories[i].CreationTime = m_Touch2CurrentTime;
  		  	subDirectories[i].LastAccessTime = m_Touch2CurrentTime;
  		  	subDirectories[i].LastWriteTime = m_Touch2CurrentTime;
  		  }
  		  catch(Exception e)
  		  {
  		  	m_strExceptionStack.Append(e.GetType());
  		  	m_strExceptionStack.Append(": ");
  		  	m_strExceptionStack.Append(subDirectories[i].FullName);
  		  	m_strExceptionStack.Append("\r\n");
  		  }
  		  
  		  TouchDirectory(subDirectories[i].FullName);
  		}

  		FileInfo[] theFiles = diThis.GetFiles();

		for (int i=0; i < theFiles.Length; i++)
		{
			try
	  		{
				theFiles[i].CreationTime = m_Touch2CurrentTime;
				theFiles[i].LastAccessTime = m_Touch2CurrentTime;
				theFiles[i].LastWriteTime  = m_Touch2CurrentTime; 	
	  		}
	  		catch(Exception e)
	  		{
  		  		m_strExceptionStack.Append(e.GetType());
	  			m_strExceptionStack.Append(": ");
  		  		m_strExceptionStack.Append(theFiles[i].FullName);
  		  		m_strExceptionStack.Append("\r\n");
	  		}
		}
	}
}
