using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Touch")]
[assembly: AssemblyDescription("Touches all files in current directory to current system time")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("AlphaSierraPapa")]
[assembly: AssemblyProduct("Touch")]
[assembly: AssemblyCopyright("Christoph Wille 2002")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.00.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
