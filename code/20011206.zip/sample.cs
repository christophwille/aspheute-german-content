using System;
using System.Runtime.InteropServices;

public class PerfTiming
{
 [DllImport("KERNEL32")]
 public static extern bool QueryPerformanceCounter(ref Int64 nPfCt);  

 [DllImport("KERNEL32")]
 public static extern bool QueryPerformanceFrequency(ref Int64 nPfFreq);

 protected Int64 m_i64Frequency;
 protected Int64 m_i64Start;

 public PerfTiming()
 {
  QueryPerformanceFrequency(ref m_i64Frequency);
  m_i64Start = 0;
 }

 public void Start()
 {
  QueryPerformanceCounter(ref m_i64Start);  
 }

 public double End()
 {
  Int64 i64End=0;
  QueryPerformanceCounter(ref i64End);
  return ((i64End - m_i64Start)/(double)m_i64Frequency);
 }
}


public class Test
{
public static void Main()
{
 PerfTiming pt = new PerfTiming();
 pt.Start();
 Console.WriteLine("Test");
 double dTimeTaken = pt.End();
 Console.WriteLine(dTimeTaken.ToString());
}
}