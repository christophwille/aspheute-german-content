using System;
using System.Messaging;
	
public class MQSend 
{
    public static void Main(String[] args) 
	{
		string mqPath = ".\\private$\\MyQueue2";
		if (!MessageQueue.Exists(mqPath))
		{
			MessageQueue.Create(mqPath);
		}
		
		MessageQueue mq = new MessageQueue(mqPath);
		mq.Send("whateverdata");
    }
}

