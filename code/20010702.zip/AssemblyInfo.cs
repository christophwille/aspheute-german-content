using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("mqsend")]
[assembly: AssemblyDescription("message queueing application")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("none")]
[assembly: AssemblyCopyright("Christoph Wille 2001")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("0.1.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
