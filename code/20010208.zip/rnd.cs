using System;

namespace NumberGen
{
	public class Randomize
	{
  	double dRndNum;

  	public int GenNum()
  	{
		Random objRandom = new Random();
		dRndNum = objRandom.NextDouble();
        return (int)(dRndNum * 10.0);
  	}
	}
}
