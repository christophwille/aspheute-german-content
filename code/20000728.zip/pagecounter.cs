using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

public class CTestBitmapFunctionality
{
	public static void Main()
	{
		Bitmap newBitmap = null;
		Graphics g = null ;

		try 
		{
		    Font fontCounter = new Font("Lucida Sans Unicode", 12);

		    // calculate size of the string.
		    newBitmap = new Bitmap(1,1,PixelFormat.Format32bppArgb);
		    g = Graphics.FromImage(newBitmap);
		    SizeF stringSize = g.MeasureString("Hello World", fontCounter);
		    int nWidth = (int)stringSize.Width;
		    int nHeight = (int)stringSize.Height;
		    g.Dispose();
		    newBitmap.Dispose();
			
		    newBitmap = new Bitmap(nWidth,nHeight,PixelFormat.Format32bppArgb);
		    g = Graphics.FromImage(newBitmap);
		    g.FillRectangle(new SolidBrush(Color.White), new Rectangle(0,0,nWidth,nHeight));

		    g.DrawString("Hello World", fontCounter, new SolidBrush(Color.Black), 0, 0);
			newBitmap.Save("c:\\test.png", ImageFormat.Png);
		} 
		catch (Exception e)
		{
		    Console.WriteLine(e.ToString());
		}
		finally 
		{
		    if (null != g) g.Dispose();
		    if (null != newBitmap) newBitmap.Dispose();
		}
	}
}


