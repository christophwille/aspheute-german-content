using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Command Line Consumer")]
[assembly: AssemblyDescription("Web Services Client Demo Application")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("AspHeute")]
[assembly: AssemblyCopyright("Christoph Wille 2001-2002")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("0.1.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
