// project created on 6/21/2001 at 4:05 PM
using System;
using AspHeuteProxy;

class MainClass
{
	public static void Main(string[] args)
	{
		DemoVBService myService = new DemoVBService();
		Console.WriteLine(myService.SayHello("Christoph"));
	}
}
