BITTE BEACHTEN !

1) Die Verzeichnisse MUESSEN geschuetzt werden (ueber Basic Authentication)

2) Passwort fuer YourDataBase = YourPassword

3) In Datei "login.asp" muss in JEDEM Fall ersetzt werden "YourDomain.com" (durch Ihre Domain)

