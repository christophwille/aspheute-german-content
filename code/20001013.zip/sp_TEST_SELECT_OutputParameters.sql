if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_TEST_SELECT_OUTPUTPARAMETERS]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_TEST_SELECT_OUTPUTPARAMETERS]
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

CREATE PROCEDURE sp_TEST_SELECT_OUTPUTPARAMETERS
   @paramOrderID INT,
   @CustomerID NCHAR(5) OUTPUT,
   @EmployeeID INT OUTPUT,
   @OrderDate DATETIME OUTPUT,
   @ShipName NVARCHAR(40) OUTPUT,
   @ShipCountry NVARCHAR(15) OUTPUT

AS

SELECT @CustomerID=CustomerID, @EmployeeID=EmployeeID,    
       @OrderDate=OrderDate,   @ShipName=ShipName, 
       @ShipCountry=ShipCountry     
       FROM Orders WHERE OrderID=@paramOrderID 



GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

