/* Variablen Definieren */
DECLARE @SQLStatement NVARCHAR(1024)
DECLARE @ParameterDefinition NVARCHAR(500)

DECLARE @OrderID INT
DECLARE @CustomerID NCHAR(5)
DECLARE @EmployeeID INT
DECLARE @OrderDate DATETIME
DECLARE @ShipName NVARCHAR(40)
DECLARE @ShipCountry NVARCHAR(15)

/* Auszufuehrendes SQL Statement mit Parametern */
SELECT @SQLStatement = N'SELECT @paramCustomerID=CustomerID, ' +
   '@paramEmployeeID=EmployeeID, @paramOrderDate=OrderDate, ' +
   '@paramShipName=ShipName, @paramShipCountry=ShipCountry ' +
   'FROM Northwind.dbo.Orders WHERE OrderID=@paramOrderID'

/* Parameterdefinition */
SELECT @ParameterDefinition = N'@paramOrderID INT, ' +
   '@paramCustomerID NCHAR(5) OUTPUT, @paramEmployeeID INT OUTPUT, ' +
   '@paramOrderDate DATETIME OUTPUT, @paramShipName NVARCHAR(40) OUTPUT, ' +
   '@paramShipCountry NVARCHAR(15) OUTPUT'

/* Werte der Inputparameter: */
SELECT @OrderID = 10555

/* Ausfuehren des parametrisierten SQL Kommandos 
   mit Hilfe der System Stored Procedure sp_executesql */
EXECUTE sp_executesql 
   @stmt             = @SQLStatement, 
   @params           = @ParameterDefinition, 
   @paramOrderID     = @OrderID,
   @paramCustomerID  = @CustomerID  OUTPUT, 
   @paramEmployeeID  = @EmployeeID  OUTPUT,
   @paramOrderDate   = @OrderDate   OUTPUT,
   @paramShipName    = @ShipName    OUTPUT,
   @paramShipCountry = @ShipCountry OUTPUT

/* Ausgeben der Rueckgabewerte */
SELECT @OrderID    AS 'OrderID',    @CustomerID  AS 'CustomerID',
       @EmployeeID AS 'EmployeeID', @OrderDate   AS 'OrderDate', 
       @ShipName   AS 'ShipName',   @ShipCountry AS 'ShipCountry'

