using System;
using Microsoft.Web.Services.Security;

namespace SamplePasswordProvider
{
	public class Simple : IPasswordProvider
	{
		public string GetPassword(UsernameToken token)
		{
			// Ensure the SOAP message sender passed a UsernameToken.
			if (null == token)
				throw new ArgumentNullException();

			string strUsername = token.Username;
			return strUsername;
		}
	}
}
