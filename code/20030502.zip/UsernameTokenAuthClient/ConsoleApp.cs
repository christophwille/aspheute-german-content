using System;

// necessary using statements
using Microsoft.Web.Services.Security;

namespace UsernameTokenAuthClient
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class ConsoleAppWsClient
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			localhost.Service1 svc = new localhost.Service1();
			
			// create new UsernameToken and add to Tokens collections
			UsernameToken ut = new UsernameToken("test", "test", PasswordOption.SendHashed);
			svc.RequestSoapContext.Security.Tokens.Add(ut);

			// call Web Service method
			string strRetVal = svc.UsernameTokenAuthSampleMethod();
			Console.WriteLine(strRetVal);
		}
	}
}
