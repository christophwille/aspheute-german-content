using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

// necessary namespace imports
using Microsoft.Web.Services;
using Microsoft.Web.Services.Security;
using System.Web.Services.Protocols;

namespace UsernameTokenAuth
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class Service1 : System.Web.Services.WebService
	{
		public Service1()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		public string UsernameTokenAuthSampleMethod()
		{
			UsernameToken utCurrent = Authenticate();
			return "Hello World, " + utCurrent.Username;
		}

		private UsernameToken Authenticate()
		{
			// We must check: 
			//   * SoapContext must exist
			//   * only one UsernameToken passed
			//   * password must be provided in UsernameToken

			// CHECK 1
			SoapContext sc = HttpSoapContext.RequestContext;
			if (null == sc)
			{
				throw new ApplicationException("Only SOAP requests allowed");
			}

			// CHECK 2
			UsernameToken utCurrent = null;
			foreach (SecurityToken st in sc.Security.Tokens)
			{
				if (st is UsernameToken)
				{
					if (null != utCurrent)
					{
						// a second token was passed - we cannot accept that
						throw new SoapException("Requests can have one token only!",
												SoapException.ClientFaultCode);
					}
					else
						utCurrent = (UsernameToken)st;
				}
			}
			if (null == utCurrent)
				throw new SoapException("UsernameToken is required", 
										SoapException.ClientFaultCode);

			// CHECK 3
			if (utCurrent.PasswordOption != PasswordOption.SendHashed)
				throw new SoapException("Invalid password type", 
										SoapException.ClientFaultCode);

			// everything fine if we got here
			return utCurrent;
		}
	}
}
