using System;
using System.Globalization;

class MainClass
{
	public static void Main(string[] args)
	{
		Console.WriteLine(Week.FromDateTime(new DateTime(2002, 1, 1))); // Tuesday
		Console.WriteLine(Week.FromDateTime(new DateTime(2002, 1, 6))); // Sunday, 1st week
		Console.WriteLine(Week.FromDateTime(new DateTime(2002, 1, 7))); // Monday, 2nd week
		Console.WriteLine(Week.FromDateTime(new DateTime(2002, 5, 20))); // Monday, 21st week
		Console.WriteLine(Week.FromDateTime(new DateTime(2002, 10, 29))); // Tuesday, 44th week
		
		Console.WriteLine(MainClass.InteractiveGetWeekOfYear(new DateTime(2002, 1, 6)));
		Console.WriteLine(MainClass.AbsoluteGetWeekOfYear(new DateTime(2002, 1, 6)));
	}
	
	public static int InteractiveGetWeekOfYear(DateTime dt)
	{
		Calendar cal = DateTimeFormatInfo.CurrentInfo.Calendar;
		
		int nWeek = cal.GetWeekOfYear(dt,
				DateTimeFormatInfo.CurrentInfo.CalendarWeekRule,
				DateTimeFormatInfo.CurrentInfo.FirstDayOfWeek);
		
		return nWeek;
	}
	
	public static int AbsoluteGetWeekOfYear(DateTime dt)
	{
		GregorianCalendar cal = new GregorianCalendar();
		
		int nWeek = cal.GetWeekOfYear(dt, 
						CalendarWeekRule.FirstDay,
						DayOfWeek.Monday);
		return nWeek;
	}
}

public class Week {
	public static int FromDateTime(DateTime dt) 
	{
		DateTime dtFirstOfYear = new DateTime(dt.Year, 1, 1);
		int dowFirst = (int)dtFirstOfYear.DayOfWeek;
		int dowDate = (int)dt.DayOfWeek;
		
		// fix american format of week
		if (0 == dowFirst) dowFirst = 7;
		if (0 == dowDate) dowDate = 7;
		
		int nWeek = dt.DayOfYear / 7;
		
		if (0 == nWeek) {
			nWeek++;
		}
		else if (dowDate <= dowFirst) {
			nWeek++;
		}
	
		return nWeek;
	}
}
