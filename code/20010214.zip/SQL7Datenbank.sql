if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Loesungen]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Loesungen]
GO

CREATE TABLE [dbo].[Loesungen] (
	[Loesung] [text] NULL ,
	[SupportID] [int] NOT NULL ,
	[ID] [int] IDENTITY (1, 1) NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Users]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Users]
GO

CREATE TABLE [dbo].[Users] (
	[Username] [char] (50) NOT NULL ,
	[Passwort] [char] (50) NOT NULL ,
	[ID] [int] IDENTITY (1, 1) NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Users] WITH NOCHECK ADD 
	CONSTRAINT [PK_Users] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

 CREATE  UNIQUE  INDEX [IX_Users] ON [dbo].[Users]([Username]) ON [PRIMARY]
GO