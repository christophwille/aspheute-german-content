using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit)] 
public struct SampleUnion
{
  [FieldOffset(0)] public bool Flag1;
  [FieldOffset(1)] public bool Flag2;
  [FieldOffset(2)] public bool Flag3;
  [FieldOffset(3)] public bool Flag4;
  [FieldOffset(0)] public long Composite;
}  

class Sample
{
public static void Main()
{
  SampleUnion su = new SampleUnion();
  su.Flag1 = false;
  su.Flag2 = true;
  su.Flag3 = false;
  su.Flag4 = true;
  DumpUnion(su);
  DumpUnion2(su.Composite);
}

public static void DumpUnion(SampleUnion su)
{
  Console.WriteLine("Flag1 " + su.Flag1.ToString());
  Console.WriteLine("Flag2 " + su.Flag2.ToString());
  Console.WriteLine("Flag3 " + su.Flag3.ToString());
  Console.WriteLine("Flag4 " + su.Flag4.ToString());
  Console.WriteLine("Composite " + su.Composite.ToString());
}

public static void DumpUnion2(long nUnionValue)
{
  SampleUnion su = new SampleUnion();
  su.Composite = nUnionValue;
  Console.WriteLine("Flag1 " + su.Flag1.ToString());
  Console.WriteLine("Flag2 " + su.Flag2.ToString());
  Console.WriteLine("Flag3 " + su.Flag3.ToString());
  Console.WriteLine("Flag4 " + su.Flag4.ToString());
  Console.WriteLine("Composite " + su.Composite.ToString());
}
}