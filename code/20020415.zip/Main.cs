using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

namespace GoogleSearch
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class GoogleSearchApp : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label labelKey;
		private System.Windows.Forms.TextBox txtKey;
		private System.Windows.Forms.Label labelSearchString;
		private System.Windows.Forms.TextBox txtSearchString;
		private System.Windows.Forms.Button btnStartSearch;
		private System.Windows.Forms.ListView lvResults;
		private System.Windows.Forms.ColumnHeader colTitle;
		private System.Windows.Forms.ColumnHeader colUrl;
		private System.Windows.Forms.Label labelEstimatedResults;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public GoogleSearchApp()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.labelKey = new System.Windows.Forms.Label();
			this.txtKey = new System.Windows.Forms.TextBox();
			this.labelSearchString = new System.Windows.Forms.Label();
			this.txtSearchString = new System.Windows.Forms.TextBox();
			this.btnStartSearch = new System.Windows.Forms.Button();
			this.lvResults = new System.Windows.Forms.ListView();
			this.colTitle = new System.Windows.Forms.ColumnHeader();
			this.colUrl = new System.Windows.Forms.ColumnHeader();
			this.labelEstimatedResults = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// labelKey
			// 
			this.labelKey.Location = new System.Drawing.Point(8, 16);
			this.labelKey.Name = "labelKey";
			this.labelKey.Size = new System.Drawing.Size(32, 16);
			this.labelKey.TabIndex = 0;
			this.labelKey.Text = "Key:";
			// 
			// txtKey
			// 
			this.txtKey.Location = new System.Drawing.Point(48, 16);
			this.txtKey.Name = "txtKey";
			this.txtKey.Size = new System.Drawing.Size(272, 20);
			this.txtKey.TabIndex = 1;
			this.txtKey.Text = "xxxxxxxxxxxx";
			// 
			// labelSearchString
			// 
			this.labelSearchString.Location = new System.Drawing.Point(8, 56);
			this.labelSearchString.Name = "labelSearchString";
			this.labelSearchString.Size = new System.Drawing.Size(80, 16);
			this.labelSearchString.TabIndex = 2;
			this.labelSearchString.Text = "Search string:";
			// 
			// txtSearchString
			// 
			this.txtSearchString.Location = new System.Drawing.Point(88, 56);
			this.txtSearchString.Name = "txtSearchString";
			this.txtSearchString.Size = new System.Drawing.Size(232, 20);
			this.txtSearchString.TabIndex = 3;
			this.txtSearchString.Text = "\"Web Service\" site:www.dotnetheute.com";
			// 
			// btnStartSearch
			// 
			this.btnStartSearch.Location = new System.Drawing.Point(328, 56);
			this.btnStartSearch.Name = "btnStartSearch";
			this.btnStartSearch.Size = new System.Drawing.Size(136, 24);
			this.btnStartSearch.TabIndex = 4;
			this.btnStartSearch.Text = "Start Search";
			this.btnStartSearch.Click += new System.EventHandler(this.btnStartSearch_Click);
			// 
			// lvResults
			// 
			this.lvResults.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.colTitle,
																						this.colUrl});
			this.lvResults.Location = new System.Drawing.Point(8, 88);
			this.lvResults.MultiSelect = false;
			this.lvResults.Name = "lvResults";
			this.lvResults.Size = new System.Drawing.Size(552, 240);
			this.lvResults.TabIndex = 5;
			this.lvResults.View = System.Windows.Forms.View.Details;
			this.lvResults.DoubleClick += new System.EventHandler(this.lvResults_DoubleClick);
			// 
			// colTitle
			// 
			this.colTitle.Text = "Titel";
			this.colTitle.Width = 240;
			// 
			// colUrl
			// 
			this.colUrl.Text = "URL";
			this.colUrl.Width = 180;
			// 
			// labelEstimatedResults
			// 
			this.labelEstimatedResults.Location = new System.Drawing.Point(8, 336);
			this.labelEstimatedResults.Name = "labelEstimatedResults";
			this.labelEstimatedResults.Size = new System.Drawing.Size(416, 24);
			this.labelEstimatedResults.TabIndex = 6;
			// 
			// GoogleSearchApp
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(576, 365);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.labelEstimatedResults,
																		  this.lvResults,
																		  this.btnStartSearch,
																		  this.txtSearchString,
																		  this.labelSearchString,
																		  this.txtKey,
																		  this.labelKey});
			this.Name = "GoogleSearchApp";
			this.Text = "Sample Google API Beta 2 Search Application";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new GoogleSearchApp());
		}


		private void btnStartSearch_Click(object sender, System.EventArgs e)
		{
			GoogleSearchService gss = new GoogleSearchService();
			GoogleSearchResult gsr = null;
			labelEstimatedResults.Text = "";

			// issue the search command
			try
			{
				gsr = gss.doGoogleSearch(txtKey.Text, // Key
					txtSearchString.Text,	// Search string
					0,		// start index
					10,		// max results
					false,	// filter
					"",		// restriction
					false,	// safe search
					"",		// lr
					"",		// ie
					"");	// or
			}
			catch (Exception ex)
			{
				// intention: give a friendly error message for invalid license key
				// note: this will also catch network connectivity problem on starting the search
				string strError = ex.Message;
				if (strError.StartsWith("Exception from service object: Invalid authorization key"))
				{
					strError = "License key for Google search is invalid";
				}
				MessageBox.Show(strError, "Error invoking Google Search Service");
				return;
			}

			// get the estimated number of results - important for paging
			int nEstimatedResultRow = gsr.estimatedTotalResultsCount;
			labelEstimatedResults.Text = "Estimated # of results: " + 
				nEstimatedResultRow.ToString();

			// get all results that were returned (10 maximum as per API)
			// BeginUpdate and EndUpdate are used to speed up drawing and minimize flickering
			lvResults.BeginUpdate();
			lvResults.Items.Clear();
			ResultElement[] arrResultset = gsr.resultElements;
			for (int i=0; i < arrResultset.Length; i++)
			{
				ListViewItem lvi = new ListViewItem();
				lvi.Text = arrResultset[i].title;
				lvi.SubItems.Add(arrResultset[i].URL);
				lvResults.Items.Add(lvi);
			}
			lvResults.EndUpdate();
		}

		private void lvResults_DoubleClick(object sender, System.EventArgs e)
		{
			if (0 == lvResults.SelectedItems.Count) return;
			ListViewItem lvi = lvResults.SelectedItems[0]; // we only start first one
			string strUrl = lvi.SubItems[1].Text;
			Process.Start(strUrl);
		}
	}
}
