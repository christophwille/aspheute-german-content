using System;
using System.Text;

public class SimpleSample
{
 public static void TakeParams1(params object[] list)
 {
   foreach (object obj in list)
   {
     Console.WriteLine(obj.ToString());
   }
 }
 
 public static void TakeParams2(params object[] list)
 {
   for (int i=0; i < list.GetLength(0); i++)
   {
     Console.WriteLine(list[i].ToString());
   }
 }

 public static void TakeParams3(string strSeparator, 
                                out string strBuild,
                                params object[] list)
 {
   StringBuilder strBuilder = new StringBuilder();
   for (int i=0; i < list.GetLength(0); i++)
   {
     strBuilder.Append(list[i].ToString() + strSeparator);
   }
   strBuild = strBuilder.ToString();
 }

 public static void Main()
 {
   TakeParams1(1, "Test", 3.455);
   TakeParams2(-200, "Hansi");

   string strOut = "";
   TakeParams3("-", out strOut, "param1", 900, "param3");
   Console.WriteLine(strOut);
 }
}