using System;

public class SimpleSample
{
 public void TakeParams(params object[] list)
 {
   foreach (object obj in list)
   {
     Console.WriteLine(obj.ToString());
   }
 }
 
 public static void Main()
 {
   SimpleSample ss = new SimpleSample();
   ss.TakeParams(1, "Test", 3.455);
 }
}